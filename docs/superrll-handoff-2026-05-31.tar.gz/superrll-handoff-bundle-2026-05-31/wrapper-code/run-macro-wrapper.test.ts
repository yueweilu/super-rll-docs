/**
 * Slice 13 C1 — unit tests for tests/wezctl/run-macro.sh wrapper.
 *
 * Tests the wrapper's path schema + argument validation + degraded-path
 * exit codes by spawning the actual bash script in a tmp $HOME / repo
 * relative layout. The wrapper has 4-artifact contract; in success path
 * all 4 must exist + non-empty (covered in C3 integration tier).
 *
 * Unit tier focus:
 *   1. invalid test-id (contains ../) → exit 10
 *   2. missing macro file → exit 10
 *   3. unsupported macro extension → exit 10
 *   4. dir schema recordings/<YYYY-MM-DD>/<test-id>/ is created
 *   5. ccl-debug.log absent in success path → exit 3 (degraded)
 */
import { describe, expect, it, beforeEach, afterEach } from 'vitest'
import { execFileSync, spawnSync } from 'child_process'
import { mkdtempSync, writeFileSync, rmSync, existsSync, mkdirSync } from 'fs'
import { tmpdir } from 'os'
import { join, resolve } from 'path'

const REPO_ROOT = resolve(__dirname, '../..')
const WRAPPER = join(REPO_ROOT, 'tests/wezctl/run-macro.sh')

function run(args: string[], extraEnv: Record<string, string> = {}): {
  status: number | null
  stdout: string
  stderr: string
} {
  const result = spawnSync('bash', [WRAPPER, ...args], {
    encoding: 'utf-8',
    env: { ...process.env, ...extraEnv },
  })
  return {
    status: result.status,
    stdout: result.stdout ?? '',
    stderr: result.stderr ?? '',
  }
}

describe('run-macro.sh — argument validation', () => {
  it('exits 10 when test-id contains ../ (path traversal)', () => {
    const r = run(['../escape', '/tmp/whatever.json'])
    expect(r.status).toBe(10)
    expect(r.stderr).toMatch(/forbidden|test-id/)
  })

  it('exits 10 when macro file does not exist', () => {
    const r = run(['T0-test', '/tmp/no-such-macro-99999.json'])
    expect(r.status).toBe(10)
    expect(r.stderr).toMatch(/not found/)
  })

  it('exits 10 when macro extension is unsupported', () => {
    const tmp = mkdtempSync(join(tmpdir(), 'rmw-ext-'))
    const macroPath = join(tmp, 'macro.txt')
    writeFileSync(macroPath, '#fake')
    const r = run(['T0-ext', macroPath])
    expect(r.status).toBe(10)
    expect(r.stderr).toMatch(/unsupported|extension/)
    rmSync(tmp, { recursive: true, force: true })
  })

  it('exits 10 when called without arguments', () => {
    const r = run([])
    expect(r.status).toBe(10)
    expect(r.stderr).toMatch(/usage/)
  })
})

// Returns "YYYY-MM-DD" in local TZ (matches bash `date +%Y-%m-%d`).
function todayLocal(): string {
  const n = new Date()
  return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}-${String(n.getDate()).padStart(2, '0')}`
}

describe('run-macro.sh — recording dir schema + timeline + cleanup', () => {
  it('creates recordings/<YYYY-MM-DD>/<test-id>/ even on macro failure', () => {
    const tmp = mkdtempSync(join(tmpdir(), 'rmw-dir-'))
    const macroPath = join(tmp, 'fail.sh')
    writeFileSync(macroPath, '#!/usr/bin/env bash\nexit 5\n')

    const testId = `unit-dir-${Date.now()}`
    const expectedDir = join(REPO_ROOT, 'tests/wezctl/recordings', todayLocal(), testId)

    const r = run([testId, macroPath])
    expect(r.status).toBe(5)
    expect(existsSync(expectedDir)).toBe(true)
    expect(existsSync(join(expectedDir, 'run.json'))).toBe(true)

    rmSync(tmp, { recursive: true, force: true })
    rmSync(expectedDir, { recursive: true, force: true })
  })

  it('always writes timeline.txt with ISO 8601 timestamped entries', () => {
    const tmp = mkdtempSync(join(tmpdir(), 'rmw-tl-'))
    const macroPath = join(tmp, 'fail.sh')
    writeFileSync(macroPath, '#!/usr/bin/env bash\nexit 7\n')

    const testId = `unit-tl-${Date.now()}`
    const expectedDir = join(REPO_ROOT, 'tests/wezctl/recordings', todayLocal(), testId)

    run([testId, macroPath])
    const tlPath = join(expectedDir, 'timeline.txt')
    expect(existsSync(tlPath)).toBe(true)

    const { readFileSync } = require('fs') as typeof import('fs')
    const lines = readFileSync(tlPath, 'utf-8').trim().split('\n')
    expect(lines.length).toBeGreaterThanOrEqual(2)
    const isoRe = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z /
    for (const ln of lines) {
      expect(ln).toMatch(isoRe)
    }
    expect(lines.some(l => l.includes('wrapper-start'))).toBe(true)
    expect(lines.some(l => l.includes('cleanup-start'))).toBe(true)

    rmSync(tmp, { recursive: true, force: true })
    rmSync(expectedDir, { recursive: true, force: true })
  })

  it('runs cleanup trap on EXIT (timeline includes cleanup-end)', () => {
    const tmp = mkdtempSync(join(tmpdir(), 'rmw-cl-'))
    const macroPath = join(tmp, 'ok.sh')
    writeFileSync(macroPath, '#!/usr/bin/env bash\nexit 0\n')

    const testId = `unit-cl-${Date.now()}`
    const expectedDir = join(REPO_ROOT, 'tests/wezctl/recordings', todayLocal(), testId)

    run([testId, macroPath])
    const { readFileSync } = require('fs') as typeof import('fs')
    const tl = readFileSync(join(expectedDir, 'timeline.txt'), 'utf-8')
    expect(tl).toMatch(/cleanup-start/)
    expect(tl).toMatch(/cleanup-end/)

    rmSync(tmp, { recursive: true, force: true })
    rmSync(expectedDir, { recursive: true, force: true })
  })

  it('sh-branch passthrough does not enforce pane.cast contract', () => {
    const tmp = mkdtempSync(join(tmpdir(), 'rmw-sh-ok-'))
    const macroPath = join(tmp, 'noop.sh')
    writeFileSync(macroPath, '#!/usr/bin/env bash\necho hello\nexit 0\n')

    const testId = `unit-sh-ok-${Date.now()}`
    const expectedDir = join(REPO_ROOT, 'tests/wezctl/recordings', todayLocal(), testId)
    const r = run([testId, macroPath])

    expect(r.status).toBe(0)
    expect(existsSync(join(expectedDir, 'run.json'))).toBe(true)

    rmSync(tmp, { recursive: true, force: true })
    rmSync(expectedDir, { recursive: true, force: true })
  })
})

/**
 * JSON-branch degraded paths via stub ralph-lisa.
 *
 * The wrapper invokes `ralph-lisa skill wezterm-test --macro <path> --json
 * --keep-pane > run.json` for JSON macros. We stub ralph-lisa by placing a
 * fake script earlier in PATH that writes a controlled run.json. This lets
 * unit tier verify the exit-code matrix without spawning real wezterm.
 */
describe('run-macro.sh — JSON-branch degraded paths (stub ralph-lisa)', () => {
  function runWithStubRalphLisa(args: string[], stubRunJson: string, extraSetup?: (recDir: string) => void): {
    status: number | null
    stdout: string
    stderr: string
    expectedDir: string
  } {
    const stubDir = mkdtempSync(join(tmpdir(), 'rmw-stub-'))
    const stubPath = join(stubDir, 'ralph-lisa')
    // Stub: when called with `skill wezterm-test ...`, emit the canned
    // run.json to stdout (which the wrapper redirects into run.json).
    // For other arg shapes (e.g., `gate --warn`), pass through to real
    // ralph-lisa so the wrapper's internal log_ts / etc. still work.
    // The stub is a bash script. When invoked as `skill wezterm-test ...`,
    // it prints the canned run.json JSON to stdout (which the wrapper
    // redirects into run.json). For unrelated invocations, exit 0.
    const escapedJson = stubRunJson.replace(/'/g, "'\\''")
    writeFileSync(
      stubPath,
      `#!/usr/bin/env bash
if [ "$1" = "skill" ] && [ "$2" = "wezterm-test" ]; then
  printf '%s\\n' '${escapedJson}'
  exit 0
fi
exit 0
`,
    )
    execFileSync('chmod', ['+x', stubPath])

    const testId = `unit-json-${Date.now()}`
    const expectedDir = join(REPO_ROOT, 'tests/wezctl/recordings', todayLocal(), testId)

    if (extraSetup) extraSetup(expectedDir)

    const result = spawnSync('bash', [WRAPPER, testId, args[0]], {
      encoding: 'utf-8',
      env: { ...process.env, PATH: `${stubDir}:${process.env.PATH}` },
    })

    rmSync(stubDir, { recursive: true, force: true })

    return {
      status: result.status,
      stdout: result.stdout ?? '',
      stderr: result.stderr ?? '',
      expectedDir,
    }
  }

  function makeJsonMacro(): string {
    const tmp = mkdtempSync(join(tmpdir(), 'rmw-jmac-'))
    const macroPath = join(tmp, 'm.json')
    writeFileSync(macroPath, '{"steps":[]}')
    return macroPath
  }

  it('exits 6 on JSON success when pane-raw.txt is empty (no pane discovered)', () => {
    // Stub run.json has ok=true but no rawL1 → no pane_id → PANE_RAW empty.
    const macro = makeJsonMacro()
    const runJsonText = JSON.stringify({ ok: true, steps: [], rawL1: '' })
    const r = runWithStubRalphLisa([macro], runJsonText)
    expect(r.status).toBe(6)
    expect(r.stderr).toMatch(/pane-raw\.txt missing or empty/)
    rmSync(r.expectedDir, { recursive: true, force: true })
    rmSync(require('path').dirname(macro), { recursive: true, force: true })
  })

  it('exits 5 on JSON success when run.json has ok:false', () => {
    const macro = makeJsonMacro()
    const runJsonText = JSON.stringify({ ok: false, steps: [], rawL1: '=== pane 999 ===' })
    const r = runWithStubRalphLisa([macro], runJsonText)
    expect(r.status).toBe(5)
    expect(r.stderr).toMatch(/'ok: true'/)
    rmSync(r.expectedDir, { recursive: true, force: true })
    rmSync(require('path').dirname(macro), { recursive: true, force: true })
  })

  it('exits 4 on JSON success when pane.cast is empty', () => {
    const macro = makeJsonMacro()
    // Stub returns ok:true + rawL1 with a pane id, but we don't pre-create pane.cast.
    // wezctl read may fail (pane 999 doesn't exist) → PANE_RAW filled with [ERR],
    // but the wrapper writes "[ERR] wezctl read failed" → PANE_RAW non-empty.
    // pane.cast is never written (macro didn't run for real) → empty → exit 4.
    const runJsonText = JSON.stringify({ ok: true, steps: [], rawL1: '=== pane 999 ===' })
    // The wrapper writes pane-raw.txt via wezctl read. For pane 999 (fake), wezctl
    // returns no output → pane-raw.txt is empty → wrapper exits 6 BEFORE pane.cast
    // check. To test exit 4, pre-create pane-raw.txt with content but leave pane.cast empty.
    const r = runWithStubRalphLisa([macro], runJsonText, (recDir) => {
      require('fs').mkdirSync(recDir, { recursive: true })
      require('fs').writeFileSync(join(recDir, 'pane-raw.txt'), 'mock pane content\n')
    })
    expect(r.status).toBe(4)
    expect(r.stderr).toMatch(/pane\.cast/)
    rmSync(r.expectedDir, { recursive: true, force: true })
    rmSync(require('path').dirname(macro), { recursive: true, force: true })
  })

  it('exits 3 on JSON success when ccl-debug.log is empty', () => {
    const macro = makeJsonMacro()
    const runJsonText = JSON.stringify({ ok: true, steps: [], rawL1: '=== pane 999 ===' })
    const r = runWithStubRalphLisa([macro], runJsonText, (recDir) => {
      const fs = require('fs')
      fs.mkdirSync(recDir, { recursive: true })
      fs.writeFileSync(join(recDir, 'pane-raw.txt'), 'mock pane\n')
      fs.writeFileSync(join(recDir, 'pane.cast'), 'mock cast\n')
      // ccl-debug.log left empty (or absent) → expect exit 3
    })
    expect(r.status).toBe(3)
    expect(r.stderr).toMatch(/ccl-debug\.log/)
    rmSync(r.expectedDir, { recursive: true, force: true })
    rmSync(require('path').dirname(macro), { recursive: true, force: true })
  })
})
