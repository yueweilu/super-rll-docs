import { describe, it } from "node:test";
import * as assert from "node:assert";
import { execFileSync } from "node:child_process";

// Adjust CLI_PATH to your application's CLI entry point
const CLI_PATH = process.env.CLI_PATH || "./dist/cli.js";

function run(...args: string[]): { stdout: string; exitCode: number } {
  try {
    const stdout = execFileSync(process.execPath, [CLI_PATH, ...args], {
      encoding: "utf-8",
      timeout: 10000,
    });
    return { stdout, exitCode: 0 };
  } catch (e: any) {
    return { stdout: (e.stdout || "") + (e.stderr || ""), exitCode: e.status || 1 };
  }
}

describe("CLI Smoke Tests", () => {
  it("--help exits 0 and shows usage", () => {
    const r = run("--help");
    assert.strictEqual(r.exitCode, 0);
    assert.ok(r.stdout.length > 0);
  });

  it("--version exits 0", () => {
    const r = run("--version");
    assert.strictEqual(r.exitCode, 0);
  });

  it("unknown command exits non-zero", () => {
    const r = run("nonexistent-command");
    assert.notStrictEqual(r.exitCode, 0);
  });
});
