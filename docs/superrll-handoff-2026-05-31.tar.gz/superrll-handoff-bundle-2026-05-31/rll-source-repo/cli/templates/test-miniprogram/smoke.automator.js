/**
 * Miniprogram Smoke Test — miniprogram-automator
 *
 * Prerequisites:
 *   npm install miniprogram-automator --save-dev
 *   微信开发者工具 → 设置 → 安全 → 开启服务端口
 *
 * Run:
 *   node tests/miniprogram/smoke.automator.js
 *
 * Environment:
 *   MINIPROGRAM_PATH — 小程序项目路径（默认 .）
 *   DEVTOOLS_PATH — 开发者工具 CLI 路径（macOS 默认）
 */

const automator = require("miniprogram-automator");

const PROJECT_PATH = process.env.MINIPROGRAM_PATH || ".";
const DEVTOOLS_PATH =
  process.env.DEVTOOLS_PATH ||
  "/Applications/wechatwebdevtools.app/Contents/MacOS/cli";

async function run() {
  let miniProgram;
  try {
    miniProgram = await automator.launch({
      projectPath: PROJECT_PATH,
      cliPath: DEVTOOLS_PATH,
    });

    // Test 1: 首页加载
    const homePage = await miniProgram.currentPage();
    console.log(`Current page: ${homePage.path}`);
    if (!homePage.path) throw new Error("Homepage did not load");
    console.log("PASS: Homepage loaded");

    // Test 2: 页面有内容
    await homePage.waitFor(2000);
    console.log("PASS: Page rendered");

    // Test 3: 导航到其他页面（按需修改路径）
    // const page = await miniProgram.navigateTo("/pages/mine/mine");
    // console.log(`Navigated to: ${page.path}`);
    // console.log("PASS: Navigation works");

    console.log("\nAll smoke tests passed.");
    process.exit(0);
  } catch (err) {
    console.error("FAIL:", err.message);
    process.exit(1);
  } finally {
    if (miniProgram) await miniProgram.close();
  }
}

run();
