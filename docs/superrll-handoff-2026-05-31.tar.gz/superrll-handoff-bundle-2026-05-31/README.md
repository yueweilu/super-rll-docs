# SuperRLL Handoff Bundle (2026-05-31)

**Source session**: CCL repo, slices 10-13 (tonight)
**Total size**: 1.9 MB
**Primary doc**: `docs/superrll-handoff-2026-05-31.md` — 13 categorized issues across RLL state machine + test-harness

---

## TL;DR for SuperRLL session

打开 `docs/superrll-handoff-2026-05-31.md` 看 13 个具体问题 (A1-A6 RLL, B1-B8 wezterm-test, D1-D4 evidence convention). 每个问题:
- 现象 (Symptom)
- 影响范围 (Scope)
- 修复建议 (Repair recommendation)

下面的 `evidence/` 子目录是这些问题的**实际证据**, SuperRLL 可以 cross-reference.

---

## 目录结构

```
superrll-handoff-bundle-2026-05-31/      (2.3 MB total)
├── README.md (this file)
├── docs/                                  (11 KB)
│   └── superrll-handoff-2026-05-31.md  ← 主交接文档 (PRIMARY)
├── wrapper-code/  ← Slice 13 CCL-side 实现 (32 KB, 含 B5/B6/B7/B8 workaround)
│   ├── run-macro.sh           — 一键 wrapper
│   ├── replay.sh              — ANSI cast 视觉回放 (D1 convention)
│   ├── T0-smoke-version.macro.json  — 示例 macro (3-step + 4 artifact pattern)
│   └── run-macro-wrapper.test.ts    — 12 unit tests (含 4 stub-ralph-lisa 测试)
├── rll-source-dist/  ← ralph-lisa 已编译 dist (220 KB, npm 当前装的版本)
│   ├── policy.js          ← A3/A4 policy 误判, 改这里
│   ├── policy.d.ts
│   ├── wezterm-test-skill.js  ← B1/B2/B3 skill 改这里 (无 ANSI capture / pane lifecycle / wait-for input/output 区分)
│   ├── complexity-judge.js + complexity-verify.js  ← A2 freshness 锁
│   ├── doc-task-detector.js  ← A5 phase discipline 检测
│   ├── ralph-attest-parser.js + lisa-attest-parser.js  ← §149 attest
│   ├── test-results-claim-verifier.js + test-execution-log.js  ← §137 log-cite
│   └── state.js + task-state.js + task-capability.js + phase-state.js
├── rll-source-repo/  ← rll repo (TS 源码, 256 KB)
│   └── cli/
│       ├── src/      ← TypeScript 源码 (build 出上面的 dist)
│       ├── skills/   ← wezterm-test, playwright-test 等 skill
│       ├── bin/      ← ralph-lisa CLI 入口
│       ├── templates/ ← gate / preset / claude-commands
│       └── package.json
└── evidence/                              (1.8 MB)
    ├── consensus-events.jsonl     — 4 slice round counts (证 A6 多 round 浪费)
    ├── lisa-review-trail-tail-300.md  — Lisa 最近 NEEDS_WORK 链 (证 A3/A5 policy 误判 + phase discipline)
    ├── plan-md-slice-12-13-section.md  — PLAN.md 关键 section snapshot
    ├── test-execution-log.jsonl       — §137 log-cite 验证日志
    ├── slice-10/  — 3p-tool-lazy-load (6 rounds)
    ├── slice-11/  — ccl-customization-loaders (7 rounds)
    ├── slice-12/  — enable-feature-gates-batch (5 rounds)
    └── slice-13/  — wezterm-test-recording-infra (8 rounds)
        ├── auto-tdd-plan-*.json
        ├── *.json (complexity-judge)
        └── recording-T0-smoke-version/  ← 真 e2e 录制 (6 文件)
            ├── run.json          (skill output, "ok": true)
            ├── pane-raw.txt      (ASCII pane snapshot)
            ├── pane.cast         (ANSI-preserving, D1 primary evidence)
            ├── ccl-debug.log     (ccl --debug --debug-file 输出)
            ├── timeline.txt      (ISO 8601 step transitions)
            └── screenshot.png    (best-effort full-screen, 见 B7 限制)
```

---

## 问题 → 证据 映射

| 主文档章节 | 关键问题 | 证据位置 |
|----------|---------|---------|
| **A1** PLAN.md backtick 污染 auto-tdd | slice 11/12/13 都踩 | `evidence/slice-{11,12,13}/auto-tdd-plan-*.json` (修复前后 diff 可见) |
| **A2** complexity-judge freshness 强 hash 锁 | 每个 slice 重跑 3-5 次 | `evidence/slice-*/<slug>.json` 看 input_hash 频繁变化 |
| **A3** §137/§149/§155 policy regex 误判 | slice 11 R2/R4 + slice 12 R3 + slice 13 R4-R7 多次 | `evidence/lisa-review-trail-tail-300.md` |
| **A4** §151 visual-evidence 误触发 | 几乎每个 slice 都得 `RL_VISUAL_EVIDENCE_OFF=1` | `evidence/lisa-review-trail-tail-300.md` |
| **A5** R0/R1 phase discipline 易踩坑 | slice 10/11/12 R1 都踩 (landed code before PLAN PASS) | `evidence/slice-{10,11,12,13}/` review trail |
| **A6** CONSENSUS 后 cascade race | slice 11 R5→R7 cascade fail | `evidence/consensus-events.jsonl` |
| **B1** wezterm-test JSON macro step 不文档化 | wait-stable 不支持 | `wrapper-code/T0-smoke-version.macro.json` (用 wait-for) |
| **B2** --keep-pane 没真保 pane | post-exit pane 被 kill | `wrapper-code/run-macro.sh` (pane 提取改用 rawL1) |
| **B3** wait-for 匹配 input 而非 output | `DONE-VERSION` 误匹配 | `wrapper-code/T0-smoke-version.macro.json` (用 `(CCL)` output marker) |
| **B4** wezterm window_id ≠ macOS CGWindowID | screencapture -l 总 fail | `wrapper-code/run-macro.sh` (full-screen 不带 -l) |
| **B5** spawn 子 pane env 不继承 | $CCL_TEST_DEBUG_LOG 解析空 | `wrapper-code/run-macro.sh` (sed 预处理 macro JSON) |
| **B6** macOS Screen Recording 权限 | 须用户手动授权 | 见主文档 B6 + B7 |
| **B7** spawned pane 不在 active tab | screenshot 拍不到 ccl 输出 | `evidence/slice-13/recording-T0-smoke-version/screenshot.png` (实证) |
| **B8** wezterm GUI mux-only 模式 | open -a WezTerm 才有 GUI | `wrapper-code/run-macro.sh:62-69` |
| **D1** pane.cast = primary evidence | 用户接受的 canonical 做法 | `evidence/slice-13/recording-T0-smoke-version/pane.cast` |
| **D2-D4** screenshot/debug-log/run.json | evidence convention 已建立 | `wrapper-code/run-macro.sh` + 实录 |

---

## 跑 slice 数据 (证 A6)

```
$ cat evidence/consensus-events.jsonl | tail -4
slice 10 (3p-tool-lazy-load):           6 rounds
slice 11 (ccl-customization-loaders):   7 rounds
slice 12 (enable-feature-gates-batch):  5 rounds
slice 13 (wezterm-test-recording-infra): 8 rounds (1.5h)
```

均 round 6.5. 主因前 3 个 round 几乎都是修 A1-A5 类自身问题, 不是真实代码 work. SuperRLL 改进后预期降到 3-4 round.

---

## SuperRLL 优先级建议 (来自主文档 §C)

- **P0 阻塞性**: A1 + A2 + A6 (PLAN backtick + judge freshness + CONSENSUS cascade race) — 几乎每个 slice 都踩
- **P1 体验**: A3 + A4 + A5 (policy regex + visual-evidence + phase discipline) — 减少 `RL_*_OFF=1` 修辞
- **P2 harness**: B1 + B3 + B5 (wezterm-test 文档 + wait-for 区分 input/output + env 继承)
- **P3 env**: B2 + B4 + B6 (pane 持久 + native window id + Screen Recording 流程化)

---

## 验证主文档每个问题

主文档每个问题都有「证据出处」section. SuperRLL 可以:
1. 打开 `docs/superrll-handoff-2026-05-31.md`
2. 找到一个具体问题 (e.g., A1)
3. 对照 `evidence/` 子目录找实际证据
4. 设计修复 PR

bundle 自包含, 不需要回 CCL 仓库.
