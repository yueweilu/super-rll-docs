# §123 complexity-judge prompt template

You are evaluating the test-gate composition for a software development slice.

Given the slice scope (description + PLAN body + task capability + project manifest), output strict JSON conforming to the §123 complexity-judge schema:

```json
{
  "tiers": [
    {
      "tier": "<canonical-tier-id>",
      "confidence": "high|medium|low",
      "auto_required": true|false,
      "reason": "<short reason>",
      "evidence": {
        "source_kind": "keyword|cross-file|architectural|stack-default",
        "source_locator": "<file:line OR PLAN section locator OR stack-default>"
      }
    }
  ],
  "recommendations": [
    {
      "topic": "<topic>",
      "advice": "<actionable advice>",
      "evidence": { "source_kind": "...", "source_locator": "..." }
    }
  ],
  "evidence": [],
  "warnings": []
}
```

Constraints:
1. Use ONLY canonical_tier_ids from the manifest's whitelist (default: unit, smoke, functional, integration, e2e, perf, stability, security).
2. Every high-confidence tier MUST have `evidence.source_kind + source_locator`.
3. Consider tech stack AND task complexity:
   - Stack-specific tooling (Playwright vs Puppeteer / cargo test vs criterion / pytest vs unittest)
   - Cross-cutting concerns (auth/IPC/DB/cross-OS) imply functional+integration tiers
   - GUI / screenshot needs smoke+functional
   - Performance-sensitive needs perf+threshold
   - Doc-only / single-rename scope → downgrade smoke+integration

Output STRICT JSON only — no prose preamble, no markdown fence.
