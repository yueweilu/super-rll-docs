export type JudgeMode = 'llm' | 'heuristic' | 'off';
export interface ProviderInvocation {
    prompt: string;
    model_id: string;
}
export interface ProviderResponse {
    tiers: SuggestedTier[];
    recommendations: Recommendation[];
    evidence: EvidenceItem[];
    warnings: string[];
}
export interface SuggestedTier {
    tier: string;
    confidence: 'high' | 'medium' | 'low';
    auto_required: boolean;
    reason: string;
    evidence?: {
        source_kind: string;
        source_locator: string;
    };
}
export interface Recommendation {
    topic: string;
    advice: string;
    evidence?: {
        source_kind: string;
        source_locator: string;
    };
}
export interface EvidenceItem {
    tier?: string;
    source_kind: string;
    source_locator: string;
}
export type Provider = (invocation: ProviderInvocation) => Promise<ProviderResponse>;
export interface JudgeArgs {
    slice: string;
    mode: JudgeMode;
    planBody: string;
    taskCapability: Record<string, unknown>;
    manifest: Record<string, unknown>;
    gitDiffSummary?: string;
    provider?: Provider;
    modelId?: string;
    promptTemplatePath?: string;
    heuristicsOverridePath?: string;
    stateRoot?: string;
    /** §128 R3 Lisa R1 B3: `--extended` flag → output extension block */
    extended?: boolean;
}
/**
 * §128 R3 — extension block for `--extended` mode (Q7 路径 C backwards-compat).
 * Nested inside JudgeOutput; legacy consumers ignore.
 */
export interface ComplexityExtension {
    schema_version: 1;
    task_complexity_class: 'simple' | 'standard' | 'complex' | 'expert';
    complexity_confidence: 'high' | 'medium' | 'low';
    complexity_dimensions: {
        scope_breadth: string;
        external_data_fetch: string;
        domain_expertise_required: string;
        audit_stakes: string;
        iteration_volume_expected: string;
        knowledge_freshness_dependency: string;
    };
    complexity_evidence: string[];
}
export interface JudgeOutput {
    schema_version: 1;
    model_id: string;
    prompt_template_hash: string;
    input_hash: string;
    mode: JudgeMode;
    tiers: SuggestedTier[];
    recommendations: Recommendation[];
    evidence: EvidenceItem[];
    warnings: string[];
    /** §128 R3 Q7 路径 C: present only when --extended flag set */
    extension?: ComplexityExtension;
}
/**
 * Compute deterministic input_hash via deep canonical serialization. Excludes
 * timestamps/abs paths (caller's responsibility — bundle inputs must already
 * be normalized).
 *
 * Per Lisa R8 B9 lock: nested fields (manifest.canonical_tier_ids,
 * taskCapability.requested_combos) MUST contribute to the hash.
 *
 * Exported per Lisa R8 B10 lock: Rule 9 / verify uses the SAME helper to
 * recompute current hash; no duplicated hash logic in plan.ts.
 */
export declare function computeInputHash(args: {
    slice: string;
    planBody: string;
    taskCapability: Record<string, unknown> | unknown;
    manifest: Record<string, unknown> | unknown;
    gitDiffSummary?: string;
}): string;
export declare function extractPlanSectionBody(planContent: string, slice: string): string | null;
export declare function loadComplexityInputBundle(cwd: string, slice: string): {
    planBody: string;
    taskCapability: Record<string, unknown>;
    manifest: Record<string, unknown>;
};
/**
 * Main complexity-judge entry. Returns artifact (cached if hit).
 */
export declare function complexityJudge(args: JudgeArgs): Promise<JudgeOutput>;
/**
 * Cli sub-cmd dispatch: `ralph-lisa task complexity-judge ...`
 */
export declare function cmdComplexityJudge(args: string[], cwd?: string): Promise<number>;
