"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.capabilityPath = capabilityPath;
exports.ledgerPath = ledgerPath;
exports.activeMarkerPath = activeMarkerPath;
exports.isCapabilityActive = isCapabilityActive;
exports.loadCapability = loadCapability;
exports.saveCapability = saveCapability;
exports.appendLedger = appendLedger;
exports.loadRejectedTiersFromLedger = loadRejectedTiersFromLedger;
exports.validateDowngradeConsent = validateDowngradeConsent;
exports.buildDraft = buildDraft;
exports.assessCapability = assessCapability;
exports.ackUser = ackUser;
exports.ackInstall = ackInstall;
exports.ackDowngrade = ackDowngrade;
exports.cmdTask = cmdTask;
/**
 * §122 task-capability — task-level (not slice-level) test-harness capability
 * negotiation artifact + ack helpers.
 *
 * Per user U1 lock 2026-05-13:
 *   "用户启动一次任务很可能包含多个 slice; 首次计划要确认门禁的测试组合
 *    能不能被当前 test-harness 支持; 不支持就要提要求部署赌赢的测试框架;
 *    否则就降级测试要求; 这本质上是计划的一部分; 不要每次进."
 *
 * Schema (`.dual-agent/task-harness-capability.json`):
 *   {
 *     "task_id": "<slug>",
 *     "task_name": "<human>",
 *     "created_at": "<ISO8601>",
 *     "acked": false,
 *     "requested_combos": [
 *       { "tier": "...", "preset": "...", "supported": true|false,
 *         "install_plan": <obj|null>, "downgrade_consent": <obj|null> }
 *     ],
 *     "user_ack": null | { "method": "cli|wecom|terminal", "ack_at": "<ISO>",
 *                          "signature": "<token>" }
 *   }
 *
 * Ledger (`.dual-agent/task-install-consent.jsonl`, append-only):
 *   { "task_id", "action": "ack-install|ack-downgrade|ack-user", "tier"?,
 *     "wecom_token"?, "user_signature"?, "consent"?, "status"?, "at": "<ISO>" }
 *
 * Per Lisa B3 lock: ack-install ONLY appends to ledger; real install
 * execution (brew/apt/docker pull) deferred to §123+.
 */
const node_fs_1 = require("node:fs");
const path = __importStar(require("node:path"));
const state_js_1 = require("./state.js");
const CAPABILITY_FILE = 'task-harness-capability.json';
const LEDGER_FILE = 'task-install-consent.jsonl';
/**
 * Sticky marker file written by `task new`. Per Lisa R3.2 B21 lock: once
 * present, the project has opted into §122. Subsequent submit-time gate
 * runs in strict mode by default (missing artifact → block) without needing
 * RL_TASK_CAPABILITY_GATE=block env override. Marker is NOT auto-deleted
 * when artifact is removed — that's the whole point (prevent
 * delete-the-artifact bypass).
 */
const ACTIVE_MARKER_FILE = '.task-capability-active';
function capabilityPath(stateRoot) {
    const dir = stateRoot ?? (0, state_js_1.stateDir)();
    return path.join(dir, CAPABILITY_FILE);
}
function ledgerPath(stateRoot) {
    const dir = stateRoot ?? (0, state_js_1.stateDir)();
    return path.join(dir, LEDGER_FILE);
}
function activeMarkerPath(stateRoot) {
    const dir = stateRoot ?? (0, state_js_1.stateDir)();
    return path.join(dir, ACTIVE_MARKER_FILE);
}
/**
 * Returns true if this project has opted into §122 (marker file present).
 * Used by policy.ts to auto-promote `auto` mode → strict for opted-in
 * projects without requiring env var.
 */
function isCapabilityActive(stateRoot) {
    return (0, node_fs_1.existsSync)(activeMarkerPath(stateRoot));
}
function loadCapability(stateRoot) {
    const p = capabilityPath(stateRoot);
    if (!(0, node_fs_1.existsSync)(p))
        return null;
    try {
        return JSON.parse((0, node_fs_1.readFileSync)(p, 'utf8'));
    }
    catch {
        return null;
    }
}
function saveCapability(cap, stateRoot) {
    const p = capabilityPath(stateRoot);
    (0, node_fs_1.mkdirSync)(path.dirname(p), { recursive: true });
    (0, node_fs_1.writeFileSync)(p, JSON.stringify(cap, null, 2) + '\n', 'utf8');
}
function appendLedger(entry, stateRoot) {
    const p = ledgerPath(stateRoot);
    (0, node_fs_1.mkdirSync)(path.dirname(p), { recursive: true });
    (0, node_fs_1.appendFileSync)(p, JSON.stringify(entry) + '\n', 'utf8');
}
/**
 * §157 — the explicitly-rejected tier list for a task, read from the
 * ack-downgrade ledger. Filters `task-install-consent.jsonl` by
 * `task_id === taskId && action === 'ack-downgrade'`, returns the deduped
 * string `tier` list. Fail-soft: missing file → `[]`; a malformed JSONL line
 * OR a row with a non-string `tier` is skipped — one bad append-only row
 * cannot poison the valid rows (Lisa §157 R1).
 */
function loadRejectedTiersFromLedger(taskId, stateRoot) {
    const p = ledgerPath(stateRoot);
    if (!(0, node_fs_1.existsSync)(p))
        return [];
    const tiers = new Set();
    for (const line of (0, node_fs_1.readFileSync)(p, 'utf8').split('\n')) {
        const trimmed = line.trim();
        if (!trimmed)
            continue;
        let entry;
        try {
            entry = JSON.parse(trimmed);
        }
        catch {
            continue; // malformed JSONL line — skip
        }
        if (entry.task_id !== taskId || entry.action !== 'ack-downgrade')
            continue;
        if (typeof entry.tier === 'string' && entry.tier.length > 0)
            tiers.add(entry.tier);
    }
    return [...tiers];
}
/**
 * Validate a downgrade consent string. Per Lisa B3 + §122 PLAN:
 *   - ≥ 10 characters
 *   - contains the word "downgrade" (case-insensitive)
 *   - contains an ISO date (YYYY-MM-DD)
 */
function validateDowngradeConsent(consent) {
    if (consent.length < 10)
        return { ok: false, reason: 'consent must be ≥10 characters' };
    if (!/downgrade/i.test(consent))
        return { ok: false, reason: 'consent must contain "downgrade" keyword' };
    if (!/\d{4}-\d{2}-\d{2}/.test(consent))
        return { ok: false, reason: 'consent must contain ISO date (YYYY-MM-DD)' };
    return { ok: true };
}
/**
 * Build a fresh draft capability artifact for `task new <slug>`.
 */
function buildDraft(slug, name) {
    return {
        task_id: slug,
        task_name: name ?? slug,
        created_at: new Date().toISOString(),
        acked: false,
        requested_combos: [],
        user_ack: null,
    };
}
/**
 * `task capability assess` — populate requested_combos from detected stack +
 * preset. Currently treats all preset tiers as supported (no testharness
 * probing in §122). Returns the assess output JSON.
 */
function assessCapability(stateRoot, cwd) {
    const cap = loadCapability(stateRoot);
    if (!cap)
        throw new Error('no capability artifact; run `ralph-lisa task new <slug>` first');
    // Detect stack + load preset
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const sd = require('./preset/stack-detect.js');
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const loader = require('./preset/preset-loader.js');
    const detected = sd.detectStack(cwd);
    const stackKey = detected?.stack ?? 'cli';
    const presetKeyByStack = {
        cli: 'cli-cmd',
        web: 'web-ui',
        server: 'server-api',
        desktop: 'desktop-app',
        mobile: 'mobile-app',
    };
    const presetKey = presetKeyByStack[stackKey] ?? 'cli-cmd';
    let preset = null;
    try {
        preset = loader.loadPresetByName(presetKey);
    }
    catch {
        preset = null;
    }
    const requiredTiers = preset?.requiredTiers ?? [];
    const optionalTiers = preset?.optionalTiers ?? [];
    const allTiers = [...requiredTiers, ...optionalTiers];
    // For §122: all preset tiers treated as supported (no probing). Future slice
    // can add real testharness probes (e.g. spawn `npx playwright --version`).
    cap.requested_combos = allTiers.map((tier) => ({
        tier,
        preset: presetKey,
        supported: true,
        install_plan: null,
        downgrade_consent: null,
    }));
    saveCapability(cap, stateRoot);
    return cap;
}
/**
 * `task capability ack-user --signature <token>` — flip acked=true.
 * Lisa B7 + B16 lock: ack must be auditable + non-silent.
 */
function ackUser(stateRoot, signature, method = 'cli') {
    const cap = loadCapability(stateRoot);
    if (!cap)
        throw new Error('no capability artifact');
    const ackAt = new Date().toISOString();
    cap.acked = true;
    cap.user_ack = { method, ack_at: ackAt, signature };
    saveCapability(cap, stateRoot);
    appendLedger({
        task_id: cap.task_id,
        action: 'ack-user',
        user_signature: signature,
        method,
        at: ackAt,
    }, stateRoot);
    return cap;
}
/**
 * `task capability ack-install --tier X --wecom-token Y` — append ledger
 * pending-install entry. Per Lisa B3 lock: NO real install execution this slice.
 */
function ackInstall(stateRoot, tier, wecomToken, commands = []) {
    const cap = loadCapability(stateRoot);
    if (!cap)
        throw new Error('no capability artifact');
    const combo = cap.requested_combos.find((c) => c.tier === tier);
    if (combo) {
        combo.install_plan = { commands, wecom_token: wecomToken, status: 'pending' };
    }
    else {
        cap.requested_combos.push({
            tier,
            preset: '',
            supported: false,
            install_plan: { commands, wecom_token: wecomToken, status: 'pending' },
            downgrade_consent: null,
        });
    }
    saveCapability(cap, stateRoot);
    appendLedger({
        task_id: cap.task_id,
        action: 'ack-install',
        tier,
        wecom_token: wecomToken,
        status: 'pending',
        at: new Date().toISOString(),
    }, stateRoot);
    return cap;
}
/**
 * `task capability ack-downgrade --tier X --consent "..."` — flip
 * downgrade_consent for tier; consent string must pass validateDowngradeConsent.
 */
function ackDowngrade(stateRoot, tier, consent) {
    const validation = validateDowngradeConsent(consent);
    if (!validation.ok) {
        throw new Error(`invalid consent: ${validation.reason}`);
    }
    const cap = loadCapability(stateRoot);
    if (!cap)
        throw new Error('no capability artifact');
    const ackedAt = new Date().toISOString();
    const combo = cap.requested_combos.find((c) => c.tier === tier);
    if (combo) {
        combo.downgrade_consent = { consent, acked_at: ackedAt };
    }
    else {
        cap.requested_combos.push({
            tier,
            preset: '',
            supported: false,
            install_plan: null,
            downgrade_consent: { consent, acked_at: ackedAt },
        });
    }
    saveCapability(cap, stateRoot);
    appendLedger({
        task_id: cap.task_id,
        action: 'ack-downgrade',
        tier,
        consent,
        at: ackedAt,
    }, stateRoot);
    return cap;
}
/**
 * CLI dispatch entry for `task` sub-command. Returns exit code.
 */
function cmdTask(args, opts = {}) {
    const cwd = opts.cwd ?? process.cwd();
    const sub = args[0];
    if (!sub || sub === '--help' || sub === '-h') {
        printTaskHelp();
        return sub ? 0 : 2;
    }
    if (sub === 'new') {
        const slug = args[1];
        if (!slug || slug === '--help') {
            process.stdout.write('Usage: ralph-lisa task new <slug>\n');
            process.stdout.write('  Creates a draft capability artifact (acked=false) and fires plan-keeper + progress-tracker hooks.\n');
            return slug ? 0 : 2;
        }
        return cmdTaskNew(slug, cwd);
    }
    if (sub === 'capability') {
        return cmdTaskCapability(args.slice(1), cwd);
    }
    // §123 Layer 1 LLM-primary judgement (async)
    if (sub === 'complexity-judge') {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const { cmdComplexityJudge } = require('./complexity-judge.js');
        return cmdComplexityJudge(args.slice(1), cwd);
    }
    // §123 Layer 2 deterministic hard gate (async)
    if (sub === 'complexity-verify') {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const { cmdComplexityVerify } = require('./complexity-verify.js');
        return cmdComplexityVerify(args.slice(1), cwd);
    }
    process.stderr.write(`ralph-lisa task: unknown subcommand '${sub}'\n`);
    printTaskHelp();
    return 2;
}
function printTaskHelp() {
    process.stdout.write('Usage: ralph-lisa task <subcommand>\n');
    process.stdout.write('\n');
    process.stdout.write('Subcommands:\n');
    process.stdout.write('  task new <slug>                           Create a new task (draft capability artifact)\n');
    process.stdout.write('  task complexity-judge --slice <slug>      §123 Layer 1 LLM-primary judgement artifact\n');
    process.stdout.write('  task complexity-verify --slice <slug>     §123 Layer 2 deterministic hard gate\n');
    process.stdout.write('  task capability assess                    Detect stack/preset and populate combos\n');
    process.stdout.write('  task capability ack-install --tier <X>    Append pending-install ledger entry (no real install)\n');
    process.stdout.write('  task capability ack-downgrade --tier <X>  Explicit downgrade with user consent string\n');
    process.stdout.write('  task capability ack-user --signature <T>  Flip acked=true; required before R2 [CODE] (Lisa B7 lock)\n');
    process.stdout.write('  task capability show                      Print current capability artifact JSON\n');
}
function cmdTaskNew(slug, cwd) {
    const stateRoot = path.join(cwd, '.dual-agent');
    (0, node_fs_1.mkdirSync)(stateRoot, { recursive: true });
    const draft = buildDraft(slug);
    saveCapability(draft, stateRoot);
    // §122 R3.2 B21 lock: sticky marker so policy enforces strict mode on
    // subsequent submits even if artifact is later deleted.
    try {
        (0, node_fs_1.writeFileSync)(activeMarkerPath(stateRoot), `task_id=${slug}\ncreated_at=${new Date().toISOString()}\n`, 'utf8');
    }
    catch (e) {
        process.stderr.write(`task new: marker write warning: ${e.message}\n`);
    }
    // Fire task-launch hooks (plan-keeper baseline + progress-tracker).
    // Best-effort: hook failures must NOT block task new (per B2 self-deadlock fix).
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const { runTaskLaunchHooks } = require('./commands.js');
        runTaskLaunchHooks(slug, cwd);
    }
    catch (e) {
        process.stderr.write(`task new: hook warning: ${e.message}\n`);
    }
    process.stdout.write(`task new: created draft '${slug}' at ${capabilityPath(stateRoot)}\n`);
    return 0;
}
function cmdTaskCapability(args, cwd) {
    const sub = args[0];
    const stateRoot = path.join(cwd, '.dual-agent');
    if (!sub || sub === '--help' || sub === '-h') {
        process.stdout.write('Usage: ralph-lisa task capability <assess|ack-install|ack-downgrade|ack-user|show>\n');
        return sub ? 0 : 2;
    }
    if (sub === 'assess') {
        try {
            const cap = assessCapability(stateRoot, cwd);
            process.stdout.write(JSON.stringify({ task_id: cap.task_id, tiers: cap.requested_combos }, null, 2) + '\n');
            return 0;
        }
        catch (e) {
            process.stderr.write(`task capability assess: ${e.message}\n`);
            return 1;
        }
    }
    if (sub === 'ack-install') {
        const tier = getFlag(args, '--tier');
        const wecomToken = getFlag(args, '--wecom-token') ?? '';
        if (!tier) {
            process.stderr.write('task capability ack-install: --tier required\n');
            return 2;
        }
        try {
            ackInstall(stateRoot, tier, wecomToken);
            process.stdout.write(`task capability ack-install: tier=${tier} appended to ledger (status=pending; no real install)\n`);
            return 0;
        }
        catch (e) {
            process.stderr.write(`task capability ack-install: ${e.message}\n`);
            return 1;
        }
    }
    if (sub === 'ack-downgrade') {
        const tier = getFlag(args, '--tier');
        const consent = getFlag(args, '--consent');
        if (!tier) {
            process.stderr.write('task capability ack-downgrade: --tier required\n');
            return 2;
        }
        if (!consent) {
            process.stderr.write('task capability ack-downgrade: --consent required\n');
            return 2;
        }
        try {
            ackDowngrade(stateRoot, tier, consent);
            process.stdout.write(`task capability ack-downgrade: tier=${tier} consent accepted\n`);
            return 0;
        }
        catch (e) {
            process.stderr.write(`task capability ack-downgrade: ${e.message}\n`);
            return 1;
        }
    }
    if (sub === 'ack-user') {
        const signature = getFlag(args, '--signature');
        if (!signature) {
            process.stderr.write('task capability ack-user: --signature required\n');
            return 2;
        }
        try {
            ackUser(stateRoot, signature);
            process.stdout.write(`task capability ack-user: acked=true; signature recorded\n`);
            return 0;
        }
        catch (e) {
            process.stderr.write(`task capability ack-user: ${e.message}\n`);
            return 1;
        }
    }
    if (sub === 'show') {
        const cap = loadCapability(stateRoot);
        if (!cap) {
            process.stderr.write('no capability artifact; run `ralph-lisa task new <slug>` first\n');
            return 1;
        }
        process.stdout.write(JSON.stringify(cap, null, 2) + '\n');
        return 0;
    }
    process.stderr.write(`task capability: unknown subcommand '${sub}'\n`);
    return 2;
}
function getFlag(args, flag) {
    const idx = args.indexOf(flag);
    if (idx < 0)
        return undefined;
    return args[idx + 1];
}
