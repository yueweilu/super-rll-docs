#!/usr/bin/env bash
# wezterm-test recording wrapper — produces 4 artifacts per macro run:
#   recordings/<YYYY-MM-DD>/<test-id>/{run.json, pane-raw.txt, screenshot.png, ccl-debug.log}
#
# Headed by default (wezterm pane visible). Uses --keep-pane on failure for
# manual post-mortem. Exit codes:
#   0  — all 4 artifacts produced + non-empty
#   1  — macro execution failed (propagated from inner skill)
#   2  — screencapture failed in success path
#   3  — ccl-debug.log missing or empty in success path
#   10 — usage error / bad arguments
#
# Usage: bash tests/wezctl/run-macro.sh <test-id> <macro-path>
set -u

TEST_ID="${1:-}"
MACRO="${2:-}"

# Argument validation. test-id must be safe for filesystem (no .. / no /).
if [ -z "$TEST_ID" ] || [ -z "$MACRO" ]; then
  echo "usage: bash run-macro.sh <test-id> <macro-path>" >&2
  exit 10
fi
if echo "$TEST_ID" | grep -qE '(^\.|/|\.\.)'; then
  echo "[ERR] test-id contains forbidden chars (../ or leading dot or slash): $TEST_ID" >&2
  exit 10
fi
if [ ! -f "$MACRO" ]; then
  echo "[ERR] macro file not found: $MACRO" >&2
  exit 10
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
WEZCTL="$HERE/wezctl"
REPO_ROOT="$(cd "$HERE/../.." && pwd)"
DATE_DIR="$(date +%Y-%m-%d)"
REC_DIR="$REPO_ROOT/tests/wezctl/recordings/$DATE_DIR/$TEST_ID"
mkdir -p "$REC_DIR"

# Headed-mode prerequisite: ensure wezterm GUI is running so screencapture
# can see the spawned pane. The mux-server (wezterm-mux-server) hosts panes
# but has no GUI representation; without `open -a WezTerm`, the spawned pane
# exists in mux but is invisible to screencapture.
if ! pgrep -x "wezterm-gui" >/dev/null 2>&1; then
  if command -v open >/dev/null && [ -d "/Applications/WezTerm.app" ]; then
    open -a WezTerm
    # Give the GUI 2s to come up + connect to the mux.
    sleep 2
  fi
fi

# Export deterministic paths so the macro can pass them to ccl / screencapture.
# Substituted into the macro JSON before passing to the skill, since wezterm
# spawn does NOT inherit caller env.
export CCL_TEST_DEBUG_LOG="$REC_DIR/ccl-debug.log"
export CCL_TEST_SCREENSHOT="$REC_DIR/screenshot.png"
export CCL_TEST_PANE_CAST="$REC_DIR/pane.cast"

RUN_JSON="$REC_DIR/run.json"
PANE_RAW="$REC_DIR/pane-raw.txt"
SCREENSHOT="$REC_DIR/screenshot.png"
DEBUG_LOG="$REC_DIR/ccl-debug.log"
PANE_CAST_PATH="$REC_DIR/pane.cast"
TIMELINE="$REC_DIR/timeline.txt"

# Timeline: write ISO-8601 timestamped step transitions for audit / time
# correlation between artifacts. Each line: `<iso-ts> <step>`.
log_ts() {
  printf '%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" >> "$TIMELINE"
}
: > "$TIMELINE"
log_ts "wrapper-start test_id=$TEST_ID macro=$MACRO"

# Pane cleanup tracking. Append every pane_id we discover (from skill output)
# so we can kill them all in the EXIT trap, even if the wrapper aborts.
SPAWNED_PANES=""
cleanup_panes() {
  log_ts "cleanup-start spawned_panes=$SPAWNED_PANES"
  for P in $SPAWNED_PANES; do
    "$WEZCTL" kill "$P" 2>/dev/null || true
  done
  log_ts "cleanup-end"
}
trap cleanup_panes EXIT

# Detect macro type by extension.
MACRO_EXT="${MACRO##*.}"
MACRO_EXIT=0

case "$MACRO_EXT" in
  json)
    # Use ralph-lisa skill wezterm-test for JSON macros.
    if ! command -v ralph-lisa >/dev/null; then
      echo "[ERR] ralph-lisa CLI not installed (needed for JSON macros)" >&2
      exit 10
    fi
    # Pre-process macro: substitute env var literals ($CCL_TEST_DEBUG_LOG /
    # $CCL_TEST_SCREENSHOT) with the resolved absolute paths. wezterm spawn
    # does NOT inherit caller env, so the macro JSON must contain absolute
    # paths before the skill spawns the pane.
    #
    # The macro itself is responsible for timing the screencapture (e.g., after
    # the expected output appears via wait-for) — much more deterministic than
    # a wrapper-side sleep guess.
    PROCESSED_MACRO="$REC_DIR/macro.processed.json"
    sed -e "s|\$CCL_TEST_DEBUG_LOG|$CCL_TEST_DEBUG_LOG|g" \
        -e "s|\$CCL_TEST_SCREENSHOT|$CCL_TEST_SCREENSHOT|g" \
        -e "s|\$CCL_TEST_PANE_CAST|$CCL_TEST_PANE_CAST|g" \
        "$MACRO" > "$PROCESSED_MACRO"
    log_ts "macro-start type=json"
    ralph-lisa skill wezterm-test --macro "$PROCESSED_MACRO" --json --keep-pane > "$RUN_JSON" 2>&1 || MACRO_EXIT=$?
    log_ts "macro-end exit=$MACRO_EXIT"
    # Track all pane_ids the skill spawned (from `=== pane N ===` markers in rawL1).
    SPAWNED_PANES="$(grep -oE '=== pane [0-9]+ ===' "$RUN_JSON" 2>/dev/null | grep -oE '[0-9]+' | sort -u | tr '\n' ' ')"
    ;;
  sh)
    # Bash macro: capture stdout to run.log, synthesize minimal run.json.
    bash "$MACRO" 2>&1 | tee "$REC_DIR/run.log"
    MACRO_EXIT="${PIPESTATUS[0]}"
    printf '{"exit_code":%d,"mode":"bash","macro":"%s"}\n' "$MACRO_EXIT" "$MACRO" > "$RUN_JSON"
    ;;
  *)
    echo "[ERR] unsupported macro extension: .$MACRO_EXT (must be .json or .sh)" >&2
    exit 10
    ;;
esac

# Find the spawned pane. For JSON macros, the wezterm-test-skill reports the
# pane id inside `rawL1` like "=== pane <N> ===" — extract that. No fallback
# to arbitrary wezctl pane: if the skill did not spawn a pane, validation
# fails loudly via exit 6 instead of silently capturing a stray pane.
PANE_ID=""
if [ "$MACRO_EXT" = "json" ]; then
  PANE_ID="$(grep -oE '=== pane [0-9]+ ===' "$RUN_JSON" 2>/dev/null | head -1 | grep -oE '[0-9]+' || true)"
fi

if [ -n "$PANE_ID" ]; then
  # Plain-text pane content (ASCII fallback). pane.cast is written by the
  # macro itself (step `wezterm cli get-text --escapes` inside the pane) —
  # the wrapper does NOT overwrite it. If the macro skipped that step,
  # pane.cast may be missing; success-path validation will then exit 4.
  "$WEZCTL" read "$PANE_ID" > "$PANE_RAW" 2>/dev/null || echo "[ERR] wezctl read failed" > "$PANE_RAW"
fi
# When PANE_ID is empty, do NOT create / truncate PANE_RAW. Success-path
# validation will exit 6 if the file is missing or empty.

# NOTE: screenshot.png is already captured during macro execution by the
# background screencapture in the json branch above (see SHOT_PID). Capturing
# post-skill would only show the desktop state after the spawned pane is
# killed, defeating the purpose. For .sh macros (manual bash), there's no
# clear "during" moment, so capture happens here as best effort.
if [ ! -s "$SCREENSHOT" ] && command -v screencapture >/dev/null; then
  screencapture -x -t png "$SCREENSHOT" 2>/dev/null || true
fi

# Validate required-artifact contract in success path (macro exited 0).
# Required: run.json + pane-raw.txt + pane.cast + ccl-debug.log (4 files).
# Best-effort: screenshot.png (depends on wezterm GUI active tab — see
# docs/superrll-handoff-2026-05-31.md B7/B8). Wrapper does NOT fail when
# screenshot is missing; pane.cast is the primary visual evidence.
if [ "$MACRO_EXIT" -eq 0 ]; then
  # JSON-macro success path enforces the 4-REQUIRED-artifact contract.
  # .sh macros are escape hatches (e.g., for shell-only smokes); they don't
  # produce run.json/pane.cast/debug.log automatically. Skip the per-artifact
  # checks for .sh — the caller is responsible for whatever artifacts they want.
  if [ "$MACRO_EXT" = "json" ]; then
    # Verify skill schema: `ok: true` is the success indicator (NOT exit_code).
    if ! grep -qE '"ok"[[:space:]]*:[[:space:]]*true' "$RUN_JSON" 2>/dev/null; then
      echo "[FAIL] run.json missing 'ok: true' (skill reports macro failed at step level)" >&2
      log_ts "fail-run-json-ok-missing"
      exit 5
    fi
    # pane-raw.txt MUST be non-empty (4 REQUIRED contract). If pane discovery
    # failed (no SPAWNED_PANES), pane-raw was created empty by the fallback —
    # that violates the contract.
    if [ ! -s "$PANE_RAW" ]; then
      echo "[FAIL] pane-raw.txt missing or empty (pane discovery failed; skill must spawn a pane)" >&2
      log_ts "fail-pane-raw-empty"
      exit 6
    fi
    if [ ! -s "$PANE_CAST_PATH" ]; then
      echo "[FAIL] pane.cast missing or empty (macro should run wezterm cli get-text --escapes > \$CCL_TEST_PANE_CAST)" >&2
      log_ts "fail-pane-cast-empty"
      exit 4
    fi
    if [ ! -s "$DEBUG_LOG" ]; then
      echo "[FAIL] ccl-debug.log missing or empty (macro should run ccl with --debug --debug-file \$CCL_TEST_DEBUG_LOG)" >&2
      log_ts "fail-debug-log-empty"
      exit 3
    fi
    if [ ! -s "$SCREENSHOT" ]; then
      echo "[INFO] screenshot.png missing/empty — best-effort only; pane.cast is primary evidence" >&2
      log_ts "info-screenshot-best-effort"
    fi
    log_ts "wrapper-success 4-required-artifacts-non-empty"
    echo "[OK] 4 required artifacts produced in $REC_DIR (pane.cast = primary visual evidence)"
  else
    log_ts "wrapper-success sh-macro-passthrough"
    echo "[OK] .sh macro completed (no artifact contract enforced for sh branch)"
  fi
  exit 0
fi

# Macro failed — keep partial artifacts, propagate exit code.
echo "[FAIL] macro exited $MACRO_EXIT; partial artifacts kept at $REC_DIR" >&2
exit "$MACRO_EXIT"
