/** Probe for a binary on PATH — returns the resolved path, or null if absent. Injectable for tests. */
export type WhichProbe = (bin: string) => string | null;
/**
 * §187 P3: fail fast with an actionable message when the `wezterm` binary is
 * absent — instead of the cryptic late `DefaultWezTermRunner.spawnPane`
 * `status=null` failure. `whichFn` defaults to a real PATH probe.
 */
export declare function assertWezTermAvailable(whichFn?: WhichProbe): void;
export type MacroStep = {
    type: 'spawn';
    name: string;
    cwd?: string;
} | {
    type: 'send';
    target: string;
    text: string;
} | {
    type: 'wait-for';
    target: string;
    text: string;
    timeout_ms?: number;
} | {
    type: 'assert-contains';
    target: string;
    text: string;
} | {
    type: 'assert-not-contains';
    target: string;
    text: string;
} | {
    type: 'kill';
    target: string;
};
export interface Macro {
    name: string;
    steps: MacroStep[];
}
export interface WezTermRunner {
    spawnPane(opts: {
        cwd?: string;
    }): number;
    sendText(paneId: number, text: string): void;
    getText(paneId: number): string;
    killPane(paneId: number): void;
}
export interface StepResult {
    idx: number;
    type: string;
    pass: boolean;
    reason?: string;
    elapsed_ms?: number;
}
export interface RunResult {
    ok: boolean;
    steps: StepResult[];
    error?: string;
    failedStep?: {
        idx: number;
        type: string;
        reason: string;
    };
    /** §190-followup — the driven pane(s)' RAW text, captured before teardown. */
    rawL1?: string;
}
/**
 * Parse a macro JSON string. JSON ONLY — YAML EXPLICITLY rejected per
 * Lisa R1 B3 (js-yaml dev-only in cli/package.json). Throws on:
 *   - non-JSON content (incl. YAML — `name: foo` style fails JSON.parse)
 *   - missing `steps` field
 *   - unknown step type
 */
export declare function parseMacro(content: string, path?: string): Macro;
/**
 * Run a parsed macro against a WezTermRunner. Cleans up every spawned pane
 * via try/finally regardless of step outcome (Lisa R3 cleanup-invariant pin).
 */
export declare function runMacro(macro: Macro, runner: WezTermRunner, opts?: {
    keepPane?: boolean;
}): RunResult;
/** §190-followup — the `DefaultWezTermRunner` spawn seam (default: nodeSpawnSync). */
export type WzSpawnFn = (cmd: string, argv: string[], opts: {
    encoding: 'utf8';
    input?: string;
}) => {
    status: number | null;
    stdout: string;
    stderr: string;
};
/**
 * Default WezTermRunner: shells `wezterm cli --prefer-mux spawn --new-window`
 * + send-text / get-text / kill-pane. Local thin wrapper (no cli-e2e import).
 */
export declare class DefaultWezTermRunner implements WezTermRunner {
    private readonly whichFn?;
    /** §190-followup — injectable spawn seam (tests record argv; prod uses nodeSpawnSync). */
    private readonly spawn;
    /**
     * §187 P3: optional injected which-probe for the wezterm preflight.
     * §190-followup: optional `spawnFn` seam. Accepts BOTH the legacy positional
     * `whichFn` (a function) AND the options object — back-compat for §187 C8.
     */
    constructor(arg?: WhichProbe | {
        whichFn?: WhichProbe;
        spawnFn?: WzSpawnFn;
    });
    spawnPane(opts: {
        cwd?: string;
    }): number;
    sendText(paneId: number, text: string): void;
    getText(paneId: number): string;
    killPane(paneId: number): void;
}
/**
 * CLI entrypoint: `ralph-lisa skill wezterm-test --macro <path> [--json] [--keep-pane]`
 * Returns exit code (0 ok / 1 fail / 2 usage error).
 */
export declare function cmdWeztermTestSkill(args: string[], deps?: {
    runner?: WezTermRunner;
}): number;
/**
 * §190 P2 — capture the wezterm macro RUN RESULT (steps + per-step pane
 * snippets + failure reasons) into L1-debug. Resolves the run-id/root from the
 * RL_TEST_LOG_* handoff (or self-generates). Best-effort.
 *
 * NOTE: this is run-result-level capture. Capturing the driven pane's FULL raw
 * scrollback needs DefaultWezTermRunner instrumentation → §190-followup
 * `harness-runner-raw-capture`.
 */
export declare function captureWezTermL1(opts: {
    paneText: string;
    runId?: string;
    logRoot?: string;
}): void;
