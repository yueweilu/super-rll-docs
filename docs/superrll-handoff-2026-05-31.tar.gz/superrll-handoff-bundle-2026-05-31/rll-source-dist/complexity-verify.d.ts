import { type JudgeOutput } from './complexity-judge.js';
export interface VerifyArgs {
    judge: JudgeOutput;
    planTable: Array<{
        tier: string;
        required: boolean;
    }>;
    manifest: {
        canonical_tier_ids: string[];
        default_baseline: string[];
    };
    currentInputHash: string;
    rejectedTiers?: string[];
    planBody?: string;
}
export interface VerifyError {
    rule: string;
    detail: string;
}
export interface VerifyWarning {
    rule: string;
    detail: string;
}
export interface VerifyResult {
    ok: boolean;
    exitCode: number;
    errors: VerifyError[];
    warnings: VerifyWarning[];
}
export declare function complexityVerify(args: VerifyArgs): VerifyResult;
/**
 * §123 Layer 3 helper — compare Ralph's judge artifact vs Lisa's rerun.
 * Tier-class blocking rule per Lisa R2 #3:
 *   - high-conf tier in rerun missing from Ralph accept+reject → block
 *   - medium/low divergence → audit warning (NOT block)
 *   - rerun_unavailable → no block; verify gate authoritative
 */
export interface LisaRerunCompareArgs {
    ralph: JudgeOutput;
    lisa: JudgeOutput | null;
    lisaRerunStatus?: 'ok' | 'unavailable';
    ralphAcceptedTiers: string[];
    ralphRejectedTiers: string[];
}
export interface LisaRerunCompareResult {
    block: boolean;
    rerun_unavailable: boolean;
    narrows: Array<{
        rule: string;
        severity: 'narrow' | 'warning';
        detail: string;
    }>;
    warnings: Array<{
        rule: string;
        detail: string;
    }>;
}
export declare function compareLisaRerun(args: LisaRerunCompareArgs): LisaRerunCompareResult;
/**
 * Cli sub-cmd dispatch: `ralph-lisa task complexity-verify ...`
 */
export declare function cmdComplexityVerify(args: string[], cwd?: string): Promise<number>;
