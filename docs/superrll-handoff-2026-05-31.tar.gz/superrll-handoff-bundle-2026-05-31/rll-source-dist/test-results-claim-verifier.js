"use strict";
/**
 * §137 lite — parse test result claims from submit body; verify against execution log.
 *
 * Per Lisa R1 B1: extracts exit_code AND parsed counts (passed/failed/total).
 * Per Lisa R4 B5: returns {verified, unverified} — both populated; positive proof.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTestResultClaims = parseTestResultClaims;
exports.verifyTestResultsClaims = verifyTestResultsClaims;
const test_execution_log_js_1 = require("./test-execution-log.js");
/**
 * Parse Test Results section claims from submit body. Looks for:
 *   - "Exit code: N" → exit_code
 *   - "N/M passed" → passed=N, total=M
 *   - "N tests / M passed" → total=N, passed=M
 *   - "N failed" → failed
 * Attached to nearest backticked command above each numeric claim.
 */
function parseTestResultClaims(body) {
    const sectionMatch = body.match(/[Tt]est [Rr]esults[^\n]*\n([\s\S]*?)(?=\n##\s|\n\n[A-Z]|\n\n\*\*[A-Z]|$)/);
    if (!sectionMatch)
        return [];
    const section = sectionMatch[1] ?? '';
    const lines = section.split('\n');
    const claims = [];
    let currentCmd = '';
    for (const line of lines) {
        const cmdMatch = line.match(/`([^`]+)`/);
        if (cmdMatch)
            currentCmd = cmdMatch[1];
        const exitMatch = line.match(/[Ee]xit code:?\s*(\d+)/);
        const ratioMatch = line.match(/(\d+)\s*\/\s*(\d+)\s*pass/i);
        const totalPassedMatch = line.match(/(\d+)\s*tests?\s*\/\s*(\d+)\s*pass/i);
        const failedMatch = line.match(/(\d+)\s*fail/i);
        if (exitMatch || ratioMatch || totalPassedMatch || failedMatch) {
            const claim = { cmd: currentCmd || '?' };
            if (exitMatch)
                claim.exit_code = Number(exitMatch[1]);
            if (ratioMatch) {
                claim.passed = Number(ratioMatch[1]);
                claim.total = Number(ratioMatch[2]);
            }
            if (totalPassedMatch) {
                claim.total = Number(totalPassedMatch[1]);
                claim.passed = Number(totalPassedMatch[2]);
            }
            if (failedMatch)
                claim.failed = Number(failedMatch[1]);
            claims.push(claim);
        }
    }
    return claims;
}
function verifyTestResultsClaims(claims, opts) {
    const verified = [];
    const unverified = [];
    const log = (0, test_execution_log_js_1.readTestExecutionLog)({ stateRoot: opts.stateRoot });
    const cutoff = Date.now() - opts.maxAgeMin * 60 * 1000;
    // Filter log to recent entries
    const recent = log.filter((e) => {
        const ts = new Date(e.started_at).getTime();
        return Number.isFinite(ts) && ts >= cutoff;
    });
    for (const claim of claims) {
        // Match by cmd substring (allow loose match — log cmd may have extra args)
        const candidates = recent.filter((e) => e.cmd.includes(claim.cmd) || claim.cmd.includes(e.cmd));
        let matched = false;
        for (const c of candidates) {
            // Check exit_code if claimed
            if (claim.exit_code !== undefined && c.exit_code !== claim.exit_code)
                continue;
            // Check counts if claimed — log entry must have count fields too
            if (claim.passed !== undefined) {
                if (c.passed === undefined || c.passed !== claim.passed)
                    continue;
            }
            if (claim.total !== undefined) {
                if (c.total === undefined || c.total !== claim.total)
                    continue;
            }
            if (claim.failed !== undefined) {
                if (c.failed === undefined || c.failed !== claim.failed)
                    continue;
            }
            matched = true;
            break;
        }
        if (matched)
            verified.push(claim);
        else
            unverified.push(claim);
    }
    return { verified, unverified };
}
