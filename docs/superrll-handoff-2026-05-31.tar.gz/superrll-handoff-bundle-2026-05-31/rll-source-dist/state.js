"use strict";
/**
 * State management for Ralph-Lisa Loop.
 * Manages .dual-agent/ directory and all state files.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.VALID_TAGS = exports.ARCHIVE_DIR = exports.STATE_DIR = void 0;
exports.isValidTag = isValidTag;
exports.findProjectRoot = findProjectRoot;
exports.resetProjectRootCache = resetProjectRootCache;
exports._setTmuxStateDirOverride = _setTmuxStateDirOverride;
exports.getTmuxStateDir = getTmuxStateDir;
exports.resolveStateDir = resolveStateDir;
exports.stateDir = stateDir;
exports.checkSession = checkSession;
exports.readFile = readFile;
exports.writeFile = writeFile;
exports.appendFile = appendFile;
exports.getTurn = getTurn;
exports.setTurn = setTurn;
exports.getRound = getRound;
exports.setRound = setRound;
exports.getStep = getStep;
exports.setStep = setStep;
exports.extractTag = extractTag;
exports.extractSummary = extractSummary;
exports.timestamp = timestamp;
exports.timeShort = timeShort;
exports.appendHistory = appendHistory;
exports.updateLastAction = updateLastAction;
const fs = __importStar(require("node:fs"));
const path = __importStar(require("node:path"));
const node_child_process_1 = require("node:child_process");
exports.STATE_DIR = ".dual-agent";
exports.ARCHIVE_DIR = ".dual-agent-archive";
exports.VALID_TAGS = "PLAN|RESEARCH|CODE|FIX|PASS|NEEDS_WORK|CHALLENGE|DISCUSS|QUESTION|CONSENSUS|CLARIFY|NEEDS_USER_ACK";
const TAG_RE = new RegExp(`^\\[(${exports.VALID_TAGS})\\]`);
/**
 * §128 R3 Lisa R4 B8 pure-seam: validate a tag name against an allowed set.
 * `validTags` parameter defaults to the production VALID_TAGS; can be overridden
 * for tests (regression guard against accidental tag removal).
 */
function isValidTag(tag, validTags = exports.VALID_TAGS) {
    return validTags.split('|').includes(tag);
}
/**
 * Walk up from startDir to find the nearest directory containing .dual-agent/.
 * Similar to how git finds .git/ from any subdirectory.
 * Result is cached per process invocation for efficiency.
 */
/**
 * Cache keyed by resolved startDir to avoid returning wrong root
 * when called with different directories in the same process.
 */
let _cachedStartDir;
let _cachedProjectRoot;
/**
 * §11.S R3 Lisa narrow #2 partial: defensive cwd probe — `process.cwd()` can
 * throw `ENOENT` (uv_cwd) when the current working directory was deleted while
 * the process is still running (happens in test runs that rmSync their tmpdir
 * after a chdir, or in sandboxed runners). Treat that as "no inferable startDir"
 * and return null (== no project root found) rather than crashing the cli.
 */
function safeCwd() {
    try {
        return process.cwd();
    }
    catch (e) {
        const code = e?.code;
        if (code === "ENOENT" || code === "EACCES")
            return null;
        throw e;
    }
}
function findProjectRoot(startDir) {
    const cwdOrNull = startDir ?? safeCwd();
    if (cwdOrNull === null)
        return null;
    const resolved = path.resolve(cwdOrNull);
    // Cache hit: same startDir as last call
    if (_cachedStartDir === resolved && _cachedProjectRoot !== undefined) {
        if (_cachedProjectRoot === null)
            return null;
        // Validate cached root still exists
        if (fs.existsSync(path.join(_cachedProjectRoot, exports.STATE_DIR))) {
            return _cachedProjectRoot;
        }
        // Invalidate stale cache
        _cachedStartDir = undefined;
        _cachedProjectRoot = undefined;
    }
    let dir = resolved;
    while (true) {
        if (fs.existsSync(path.join(dir, exports.STATE_DIR))) {
            _cachedStartDir = resolved;
            _cachedProjectRoot = dir;
            return dir;
        }
        const parent = path.dirname(dir);
        if (parent === dir)
            break; // reached filesystem root
        dir = parent;
    }
    _cachedStartDir = resolved;
    _cachedProjectRoot = null;
    return null;
}
/**
 * Reset the cached project root. Used in tests.
 */
function resetProjectRootCache() {
    _cachedStartDir = undefined;
    _cachedProjectRoot = undefined;
}
/**
 * Test-only override for getTmuxStateDir(). When set to a string, that value
 * is returned instead of querying tmux. Set to undefined to restore real behavior.
 */
let _tmuxStateDirOverride;
function _setTmuxStateDirOverride(value) {
    _tmuxStateDirOverride = value;
}
/**
 * Try to read RL_STATE_DIR from tmux session environment.
 * Returns null if not in tmux or env var not set.
 */
function getTmuxStateDir() {
    // Test override takes precedence
    if (_tmuxStateDirOverride !== undefined)
        return _tmuxStateDirOverride;
    try {
        const tmuxEnv = process.env.TMUX;
        if (!tmuxEnv)
            return null;
        const result = (0, node_child_process_1.execSync)("tmux show-environment RL_STATE_DIR 2>/dev/null", {
            encoding: "utf-8",
            stdio: ["pipe", "pipe", "pipe"],
            timeout: 3000,
        }).trim();
        // Format: "RL_STATE_DIR=/path" or "-RL_STATE_DIR" (unset)
        if (result.startsWith("RL_STATE_DIR=")) {
            return result.slice("RL_STATE_DIR=".length);
        }
        return null;
    }
    catch {
        return null;
    }
}
/**
 * Resolve state directory with priority (Proposal §3.10):
 *   1. tmux show-environment RL_STATE_DIR  (authoritative in auto mode)
 *   2. $RL_STATE_DIR environment variable  (manual mode / override)
 *   3. findProjectRoot() upward search     (fallback)
 *
 * Returns { dir, source } for diagnostics.
 */
function resolveStateDir() {
    // 1. tmux env (authoritative in auto mode)
    const tmuxDir = getTmuxStateDir();
    if (tmuxDir)
        return { dir: tmuxDir, source: "tmux" };
    // 2. Shell env var
    const envDir = process.env.RL_STATE_DIR;
    if (envDir)
        return { dir: envDir, source: "env" };
    // 3. Fallback: upward search
    const root = findProjectRoot();
    return { dir: path.join(root || process.cwd(), exports.STATE_DIR), source: "auto-detect" };
}
/**
 * Get the .dual-agent/ state directory path.
 * When projectDir is explicitly given, uses that path directly.
 * When omitted, uses priority resolution: tmux env → shell env → upward search.
 */
function stateDir(projectDir) {
    if (projectDir !== undefined) {
        return path.join(projectDir, exports.STATE_DIR);
    }
    return resolveStateDir().dir;
}
/**
 * Check that a session exists. Searches upward from CWD when no explicit dir given.
 */
function checkSession(projectDir) {
    const dir = projectDir !== undefined ? stateDir(projectDir) : stateDir();
    if (!fs.existsSync(dir)) {
        console.error('Error: Session not initialized. Run: ralph-lisa init "task description"');
        process.exit(1);
    }
}
function readFile(filePath) {
    try {
        return fs.readFileSync(filePath, "utf-8").trim();
    }
    catch {
        return "";
    }
}
function writeFile(filePath, content) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, content, "utf-8");
}
function appendFile(filePath, content) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.appendFileSync(filePath, content, "utf-8");
}
function getTurn(projectDir) {
    return readFile(path.join(stateDir(projectDir), "turn.txt")) || "ralph";
}
function setTurn(turn, projectDir) {
    writeFile(path.join(stateDir(projectDir), "turn.txt"), turn);
}
function getRound(projectDir) {
    return readFile(path.join(stateDir(projectDir), "round.txt")) || "?";
}
function setRound(round, projectDir) {
    writeFile(path.join(stateDir(projectDir), "round.txt"), String(round));
}
function getStep(projectDir) {
    return readFile(path.join(stateDir(projectDir), "step.txt")) || "?";
}
function setStep(step, projectDir) {
    writeFile(path.join(stateDir(projectDir), "step.txt"), step);
}
function extractTag(content) {
    const firstLine = content.split("\n")[0] || "";
    const match = firstLine.match(TAG_RE);
    return match ? match[1] : "";
}
function extractSummary(content) {
    const firstLine = content.split("\n")[0] || "";
    return firstLine.replace(TAG_RE, "").trim();
}
function timestamp() {
    // §204 B1 — write UTC ISO (with Z suffix) so history.md timestamps round-trip
    // unambiguously. Loader at cli/src/event-shipper.ts:134-158 + backfill at
    // cli/src/user-behavior-backfill.ts tolerate BOTH legacy "YYYY-MM-DD HH:MM:SS"
    // (interpreted as local) and new "YYYY-MM-DDTHH:MM:SSZ" via the hasTz check.
    // Format kept human-readable (space separator) but with Z suffix for ISO compliance.
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}Z`;
}
function timeShort() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
function appendHistory(role, content, projectDir) {
    const tag = extractTag(content);
    const summary = extractSummary(content);
    const round = getRound(projectDir);
    const step = getStep(projectDir);
    const ts = timestamp();
    const entry = `
---

## [${role}] [${tag}] Round ${round} | Step: ${step}
**Time**: ${ts}
**Summary**: ${summary}

${content}

`;
    appendFile(path.join(stateDir(projectDir), "history.md"), entry);
}
function updateLastAction(role, content, projectDir) {
    const tag = extractTag(content);
    const summary = extractSummary(content);
    const ts = timeShort();
    writeFile(path.join(stateDir(projectDir), "last_action.txt"), `[${tag}] ${summary} (by ${role}, ${ts})`);
}
