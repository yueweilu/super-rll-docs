/**
 * Policy layer for Ralph-Lisa Loop.
 * Checks submissions for required content (warn or block mode).
 *
 * Modes (RL_POLICY_MODE env):
 *   block - print warnings AND exit(1) if violations found (DEFAULT since §133 2026-05-16)
 *   warn  - print warnings, don't block (explicit dev mode escape)
 *   off   - no checks
 *
 * §133 (2026-05-16): default flipped from warn to block per
 * docs/gate-bypass-diagnostic-2026-05-16.md G4. Invalid env value
 * falls back to 'block' (NOT silently warn).
 */
export type PolicyMode = "off" | "warn" | "block";
export interface PolicyViolation {
    rule: string;
    message: string;
    /** §194 — `block` (default semantic) or `warn`. Optional + back-compat. */
    severity?: 'warn' | 'block';
}
/**
 * §133 (2026-05-16): default mode flipped from 'warn' to 'block'.
 * Dev escape: `RL_POLICY_MODE=warn ralph-lisa ...` for interactive dev mode.
 * Invalid env value → falls back to 'block' (not silently 'warn').
 */
export declare function getPolicyMode(): PolicyMode;
/**
 * Check Ralph's submission for policy violations.
 */
export interface CheckRalphCtx {
    stateRoot?: string;
    repoRoot?: string;
    step?: string;
    /**
     * §188: explicit UI-slice override for the §151 visual-evidence check. When
     * set, the check uses it instead of the `stateDir()`-derived detection (which
     * is not test-controllable inside the RLL tmux session — `resolveStateDir`
     * prefers the tmux state dir over `RL_STATE_DIR`).
     */
    isUiSlice?: boolean;
}
export declare function checkRalph(tag: string, content: string, ctx?: CheckRalphCtx): PolicyViolation[];
/**
 * Check Lisa's submission for policy violations.
 */
/** §201 ctx for `checkLisa` submit-time cross-check (Lisa R1 narrow lock — Phase A).
 * Optional; absent → cross-check skipped (back-compat for callers without context). */
export interface CheckLisaCtx {
    stateRoot?: string;
    step?: string;
    repoRoot?: string;
}
export declare function checkLisa(tag: string, content: string, ctx?: CheckLisaCtx): PolicyViolation[];
export declare function checkNeedsWorkResponse(ralphTag: string, lastLisaTag: string): PolicyViolation[];
/**
 * §102 auto-TDD context — additive policy context loaded from .dual-agent state.
 * Optional; backward-compatible callers pass no ctx and get pre-§102 behavior.
 */
export interface AutoTddPolicyContext {
    step?: string;
    stateDir?: string;
    /** §188: forwarded to checkRalph's CheckRalphCtx.isUiSlice — §151 UI-slice test override. */
    isUiSlice?: boolean;
    tddMode?: "auto" | "always" | "off";
    persistedPlan?: unknown;
    hasPriorTestsOnlyRound?: boolean;
    /**
     * §122 (Lisa R1.1 B2 + R1.2 B8 + R3 B19+B20 lock): task-capability artifact
     * contents loaded by caller. When provided, policy enforces the 6-cell phase
     * × acked matrix at submit-time:
     *   - [CODE]/[CONSENSUS] tag + capability missing → BLOCKED `task-capability-missing` (B19)
     *   - [CODE]/[CONSENSUS] tag + acked=false → BLOCKED `task-capability-unacked`
     *   - [CODE]/[CONSENSUS] tag + acked=true + any unsupported combo with no
     *     install_plan/downgrade_consent → BLOCKED `unsupported-tier-no-consent`
     *   - All other tag/state combinations: no §122 violation fires (bootstrap
     *     path for `task new` execution + [PLAN]/[FIX] rounds).
     *
     * All §122 violations bypass RL_POLICY_MODE (B20 lock — mechanical
     * enforcement, never downgraded to warn).
     */
    taskCapability?: {
        acked: boolean;
        requested_combos?: Array<{
            tier: string;
            supported: boolean;
            install_plan: unknown;
            downgrade_consent: unknown;
        }>;
    };
    /**
     * §122 R3 B19 lock: distinguishes submit-time invocations (where missing
     * capability artifact MUST block [CODE]/[CONSENSUS]) from unit-test
     * invocations (where absent taskCapability is fine — pre-§122 backwards
     * compatibility). cmdSubmitRalph / cmdSubmitLisa set this to true; direct
     * unit-test callers omit it for compat.
     */
    submitTime?: boolean;
    /**
     * §122 R3.2 B21 lock: when true, the project has opted into §122 via
     * `task new` (sticky marker `.dual-agent/.task-capability-active` present).
     * Auto-promotes `RL_TASK_CAPABILITY_GATE=auto` → strict mode for this
     * project without requiring env var. Prevents delete-the-artifact bypass.
     * cmdSubmitRalph populates this from `isCapabilityActive(stateDir)`.
     */
    taskCapabilityActive?: boolean;
    /**
     * §123 R3 lock: slice slug for R1 [PLAN] checks. When set, policy fires
     * §123 violations (complexity-judge-missing / -verify-failed /
     * mode-off-without-user-ack / lisa-rerun-high-confidence-missing /
     * expected-tier-not-in-required).
     */
    slice?: string;
    /**
     * §123 R3 lock: pre-computed complexity-verify result. When provided,
     * policy fires `complexity-verify-failed` if `!ok`. Caller (cmdSubmitRalph
     * or test) runs verify and passes result.
     */
    complexityVerifyResult?: {
        ok: boolean;
        exitCode?: number;
        errors?: Array<{
            rule: string;
        }>;
    };
    /**
     * §123 R3 lock: marker that this slice is code-bearing (per §122 task
     * capability assessment). When true + mode=off + !userAckedOffMode →
     * fires `mode-off-without-user-ack`.
     */
    codeBearing?: boolean;
    /**
     * §123 R3 lock: user has explicitly acked `off` mode for this slice.
     */
    userAckedOffMode?: boolean;
    /**
     * §123 R3 lock: Lisa's rerun of complexity-judge produced these tiers.
     */
    lisaRerunFound?: Array<{
        tier: string;
        confidence: 'high' | 'medium' | 'low';
    }>;
    ralphAcceptedTiers?: string[];
    ralphRejectedTiers?: string[];
    /**
     * §123 R3 lock: expected_required from manifest L1+L2+L3+L4_high vs actual
     * Required column in 5-col table.
     */
    expectedRequired?: string[];
    actualRequired?: string[];
}
/**
 * Run policy checks based on mode.
 * Returns { proceed, violations } so callers can format output clearly (IMP-4).
 *
 * §102 (Lisa R8 B1 lock): when `ctx` is provided with `tddMode` etc, additionally
 * invoke `validateAutoTddProtocol` to enforce auto-TDD requirements (Estimate,
 * tests-only marker, test table or escape). Backward-compatible: omitting `ctx`
 * keeps pre-§102 behavior.
 */
export declare function runPolicyCheck(role: "ralph" | "lisa", tag: string, content: string, ctx?: AutoTddPolicyContext): {
    proceed: boolean;
    violations: PolicyViolation[];
};
import type { Preset, Tier } from "./preset/schema.js";
export interface TierEvidence {
    cmd: string;
    result: string;
}
/**
 * §92 C5: parse `## Test Results` section for per-tier evidence blocks.
 * Format: `- <tier>: <cmd> → <result>` (per §90 design doc + Lisa R3 contract).
 * Returns object with one entry per tier present; missing tiers absent (not null entry).
 */
export declare function parseTierEvidence(submissionBody: string): Partial<Record<Tier, TierEvidence>>;
export interface ValidateTierCoverageOpts {
    presetEnabled: boolean;
    requireAll: boolean;
}
export interface TierCoverageResult {
    valid: boolean;
    reason?: string;
    missingTiers?: Tier[];
}
/**
 * §92 C6: validate per-tier evidence covers preset.requiredTiers.
 *   - presetEnabled=false → bypass entirely (returns valid=true; per Q2 Lisa lock — true no-op)
 *   - requireAll=true (strict-enforcing default) → every requiredTier must have non-empty cmd+result
 *   - requireAll=false (warn-only) → still checks but caller handles warning vs blocking
 */
export declare function validateTierCoverage(evidence: Partial<Record<Tier, TierEvidence>>, preset: Preset, opts: ValidateTierCoverageOpts): TierCoverageResult;
/**
 * §128 R3 — `clarify-not-completed` policy gate.
 * Reads §123 complexity-judge .extension to determine complexity_class:
 *   - simple/standard → escape pass
 *   - complex/expert → must have clarify-locked-<step>.json + (committed OR skip_clarify)
 *
 * Returns { proceed, reason?, warning? }.
 */
export declare function checkClarifyGate(ctx: {
    cwd?: string;
    /** Lisa R9 B18: engine TurnCoordinator passes resolved state root (honors stateDirOverride). */
    stateRoot?: string;
    step: string;
    tag?: string;
}): {
    proceed: boolean;
    reason?: string;
    warning?: string;
    warnings?: string[];
};
/**
 * §128 R3 — Lisa narrow negative-scope guard.
 * Given a Lisa narrow text, checks if it would expand R0 negative_scope.
 * Returns suggested_tag: 'NEEDS_USER_ACK' if scope expansion detected, else 'NEEDS_WORK'.
 *
 * Heuristic: tokenized keyword overlap with negative_scope items. Conservative bias.
 * LLM-semantic match (Lisa rerun) is the upgrade path; for R3 ship, heuristic suffices.
 */
export declare function checkLisaNarrowScopeExpansion(ctx: {
    cwd?: string;
    /** Lisa R9 B18: engine path passes resolved state root */
    stateRoot?: string;
    step: string;
    narrowText: string;
}): {
    suggested_tag: 'NEEDS_WORK' | 'NEEDS_USER_ACK';
    scope_expansion_detected: boolean;
    matched_negative_scope_item?: string;
};
/**
 * §128 R3 — scope-expansion-pending-not-acked policy gate.
 * If .dual-agent/scope-expansion-pending.json exists, block Ralph submit until ack.
 */
export declare function checkScopeExpansionPending(opts?: string | {
    cwd?: string;
    stateRoot?: string;
}): {
    proceed: boolean;
    reason?: string;
};
/**
 * §129 — checkDocOracleSpecRequired.
 * Doc-task [PLAN]/[FIX] body must contain a parseable doc-oracle-spec table with ≥1 Required ✓ row.
 * Non-doc-task bypasses.
 */
export declare function checkDocOracleSpecRequired(ctx: {
    tag: string;
    isDocTask: boolean;
    body: string;
}): Promise<{
    proceed: boolean;
    reason?: string;
}>;
