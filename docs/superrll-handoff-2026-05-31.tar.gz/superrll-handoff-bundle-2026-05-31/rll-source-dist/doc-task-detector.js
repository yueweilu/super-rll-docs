"use strict";
/**
 * §129 doc-task detector — Hybrid: --shape override > Ralph PLAN explicit > heuristic > default.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.detectDocTask = detectDocTask;
const EXPLICIT_RE = /\bTask\s*(?:type|kind)\s*:\s*doc-task\b/i;
const EXPLICIT_CODE_RE = /\bTask\s*(?:type|kind)\s*:\s*code-task\b/i;
const DOC_OUTPUT_RE = /(?:Deliverable|Output|Writes?|Produces?)\s*:\s*[^.]*?\.(?:md|markdown)\b/i;
const STRONG_CONTENT = /\b(?:docs?\/|README|handbook|guide|manual|specification|whitepaper|design[\s-]*doc|运营规划|手册)\b/i;
const STRONG_CONTENT_MD_FILE = /\b\w+\.md\b/i;
function detectDocTask(input) {
    if (input.shape === 'code') {
        return { is_doc_task: false, confidence: 'high', signal: 'shape-override' };
    }
    if (input.shape === 'doc') {
        return { is_doc_task: true, confidence: 'high', signal: 'shape-override' };
    }
    if (input.shape === 'mixed') {
        return { is_doc_task: true, confidence: 'medium', signal: 'shape-override-mixed' };
    }
    const body = input.planBody || '';
    // §141 R5 follow-up: explicit negative override prevents heuristic false-positives
    // for code-bearing slices that happen to mention docs/ paths in their submit body.
    if (EXPLICIT_CODE_RE.test(body)) {
        return { is_doc_task: false, confidence: 'high', signal: 'plan-explicit-code-task' };
    }
    if (EXPLICIT_RE.test(body)) {
        return { is_doc_task: true, confidence: 'high', signal: 'plan-explicit-declaration' };
    }
    if (DOC_OUTPUT_RE.test(body) || (STRONG_CONTENT.test(body) && STRONG_CONTENT_MD_FILE.test(body))) {
        return { is_doc_task: true, confidence: 'medium', signal: 'heuristic-md-output' };
    }
    if (STRONG_CONTENT.test(body)) {
        return { is_doc_task: true, confidence: 'medium', signal: 'heuristic-content' };
    }
    return { is_doc_task: false, confidence: 'low', signal: 'no-signal' };
}
