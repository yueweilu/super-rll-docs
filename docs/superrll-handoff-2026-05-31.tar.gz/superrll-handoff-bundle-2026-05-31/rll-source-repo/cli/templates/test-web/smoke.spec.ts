import { test, expect } from "@playwright/test";

test.describe("Smoke Tests @smoke", () => {
  test("homepage loads successfully", async ({ page }) => {
    await page.goto("/");
    await expect(page).toHaveTitle(/.+/);
    expect(page.url()).toBeTruthy();
  });

  test("main navigation is visible", async ({ page }) => {
    await page.goto("/");
    // Adjust selector to match your app's navigation
    const nav = page.locator("nav, header, [role='navigation']");
    await expect(nav.first()).toBeVisible();
  });

  test("no console errors on homepage", async ({ page }) => {
    const errors: string[] = [];
    page.on("console", (msg) => {
      if (msg.type() === "error") errors.push(msg.text());
    });
    await page.goto("/");
    await page.waitForLoadState("networkidle");
    expect(errors).toHaveLength(0);
  });
});
