# SuperRLL Handoff: RLL + Test-Harness 自身问题清单

**生成日期**: 2026-05-31  
**Session**: ccl slice 10-13 (3p-tool-lazy-load / ccl-customization-loaders / enable-feature-gates-batch / wezterm-test-recording-infra)  
**Author**: Ralph (本 session 推进者)  
**目的**: 给 SuperRLL session 修复 RLL/test-harness 自身的设计缺陷

---

## 类 A: RLL 状态机 / artifact 同步问题

### A1. PLAN.md 表格 backtick 污染 auto-tdd-plan

**现象**: PLAN.md C-row 表格写 `` `npx vitest ...` `` 加反引号 (markdown code), RLL 自动 parser 写进 `auto-tdd-plan-<slice>.json` 时**保留**反引号. §70 cascade 跑 cmd 时, shell 把反引号当 command substitution, exec 失败 exit 127.

**已遇到 3 次**: slice 11 R5, slice 12 (R5 才 catch), slice 13 R2 (预防性修).

**修复建议**: RLL parser 写 auto-tdd-plan json 时 strip 反引号. OR PLAN.md 模板规定 C-row cmd 列**不用 backtick**.

### A2. complexity-judge freshness 强 hash 锁

**现象**: PLAN.md 任何文字修改 → input_hash 重算 → complexity-verify 报 freshness-stale → 必须重跑 complexity-judge → 但 mock judge **覆盖**整个 tiers 数组. 每次 PLAN.md 改一句, 都要重新粘贴 16 行 unit/integration tier evidence.

**已遇到 5+ 次**: slice 11 R2/R3, slice 12 R2/R4, slice 13 R2/R3.

**修复建议**: 
- 选项1: complexity-verify freshness threshold 加宽 (容忍 PLAN.md 小幅文字编辑)
- 选项2: judge artifact 支持 partial update (只重算 hash 不覆盖 tiers)
- 选项3: 提供 `ralph-lisa task complexity-judge --preserve-tiers` 选项

### A3. submit policy §137 / §149 / §155 regex 误判

**现象**:
- "Test Results" 章节内**任何** `cmd="..."` 都被当成 log-cite 声明, 跟 test-execution-log.jsonl 比对; 但比对要求 cmd substring + passed/total/exit_code 精确匹配 → 写「complexity-verify exit_code=0」会 fail (log 里 complexity-verify 没 passed/total 字段)
- "Test Results" 章节解析用 lookahead `\n##\s` 终结, 若上面有 `## Test-Results` H2 (有连字符), 章节 body 长度 = 0 → 误判 "no Skip line"
- Backtick 包的 cmd 在 prose 中会被当声明 (e.g., 提到 "the previous `npx vitest ...` run" → 误抓为新声明)

**已遇到 4+ 次**: slice 11 R2 (`Test Results: 10/10`), slice 12 R3 (`.dual-agent/test-execution-log.jsonl` 在 backtick), slice 13 R2 (visual-evidence § warning).

**修复建议**:
- log-cite 声明应**只在 Test-Results: 单行 attest 块**里解析, 不解析 prose
- "Test Results" section 检测应优先匹配 `^### Test Results` heading (而非 contains)
- backtick-in-prose 应被 ignore (不当声明)

### A4. visual-evidence §151 误触发

**现象**: 任何 slice body 含 "screenshot" / "playwright" / "ui" 关键词 → §151 触发 visual-evidence-missing. 但 slice 13 是**做** screenshot 工具不是**使用** screenshot, 误判. 每次得 `RL_VISUAL_EVIDENCE_OFF=1` 才能过.

**已遇到**: slice 10 (vitest 提到 visual regression 关键词), slice 11/12 (无 UI 关联但提及), slice 13 (本身就在做 screenshot).

**修复建议**: §151 检测应区分 "the slice **uses** visual evidence" vs "the slice **discusses** visual concepts". 加 frontmatter 选项 `slice-type: tooling-not-ui`.

### A5. R0/R1 phase discipline 易踩坑

**现象**: 用户问问题 + AI 上下文里有 already-landed code → AI 写 R1 [PLAN] 时容易把已 land 代码列进 "改动文件" + 报 test results — Lisa 必 NEEDS_WORK. 每个新 slice 都踩 1 次.

**已遇到**: slice 10 R1, slice 11 R1, slice 12 R1, slice 13 R1 (本身就因为 user prompt 主动加 task R1 → 此次 PLAN-only 成功避).

**修复建议**: `ralph-lisa next-step` 默认进入 "PLAN-only mode", 屏蔽 [CODE] submission 直到 R1 PASS.

### A6. mutual CONSENSUS 后 cascade auto-load 时序 race

**现象**: Lisa CONSENSUS → §70 cascade 自动跑 auto-tdd-plan cmds → 如果 auto-tdd-plan cmds 有 backtick (见 A1) → cascade fail → loopback turn 回 Ralph → 用户看到 "slice 已 CONSENSUS 但又回到 Ralph 干" 困惑.

**已遇到**: slice 11 R5 → R7 (cascade fail + 修 backtick + 再 CONSENSUS).

**修复建议**: CONSENSUS 前先 validate auto-tdd-plan cmds (no backtick + 真可 shell exec). 在 submit 时 block.

---

## 类 B: Test-Harness (wezterm-test) 问题

### B1. wezterm-test JSON macro step type 不文档化

**现象**: 我用 `wait-stable` step type → parse error "unknown step type". 文档 `.claude/skills/wezctl.md` 只讲 `wezctl` bash CLI, 没列 JSON macro 支持的 step type. 我猜了一通才找到列表 ("Valid: spawn, send, wait-for, assert-contains, assert-not-contains, kill").

**修复建议**: wezterm-test-skill 加 `--macro-schema` 输出 JSON schema; 文档列全 step types.

### B2. wezterm-test --keep-pane 不保 pane 给 post-test 用

**现象**: macro 跑完 + skill 退出, 即使加 `--keep-pane`, `wezterm cli list` 查不到 spawned pane (765). 不能 post-test screenshot 或 read.

**修复建议**: --keep-pane 应该 GUARANTEE pane 在 test process 退出后仍可访问. 或加 --keep-pane-until-stdin 让 caller 显式释放.

### B3. wait-for 误匹配 input 而非 output

**现象**: 我 send `... && echo DONE-VERSION\r` + wait-for "DONE-VERSION" → 8ms 就 matched. 因为 wezterm pane 即时回显输入命令文本, wait-for 抓到的是输入 echo 不是命令真输出. 假阳性.

**修复建议**: wait-for 提供 `--ignore-input-echo` 选项, 或区分 "what user typed" vs "what command output".

### B4. wezterm 的 window_id ≠ macOS CGWindowID

**现象**: `wezterm cli list` 返 `window_id: 0`, 这是 wezterm 内部 id. 直接传给 `screencapture -l 0` → "could not create image from window". 需要 macOS 原生 CGWindowID (用 osascript 拿).

**修复建议**: wezterm cli 加 `--include-native-window-id` 字段; 或文档显式标记 "window_id != macOS window id".

### B5. wezterm 子 pane env 不继承父 wrapper 的 export

**现象**: wrapper export `CCL_TEST_DEBUG_LOG`, 然后 `ralph-lisa skill wezterm-test --macro ...` 跑. wezterm spawn 出的子 pane**不继承** wrapper export 的 env. macro 里 `$CCL_TEST_DEBUG_LOG` 在子 pane 解析为空 → `--debug-file ""` → ccl ENOENT crash.

**workaround (slice 13 用)**: wrapper 跑 sed substitution 处理 macro JSON, 把 `$CCL_TEST_DEBUG_LOG` 字面替换为绝对路径再喂给 skill.

**修复建议**: wezterm-test-skill 加 `--env KEY=VAL` 参数; 或 spawn pane 时继承调用 process env.

### B6. macOS Screen Recording 权限阻塞 screencapture

**现象**: Bash sandbox / Claude Code 父进程**无** Screen Recording 权限 → `screencapture` 退 1 "could not create image from display". 需用户手动到 System Settings 勾选权限 + 重启父进程.

**影响范围**: 任何依赖 screencapture 的 wezterm visual-evidence 测试.

**修复建议 (RLL side)**: docs 加 "macOS prerequisite" section 显式提示用户预先授权; 或 wezterm-test-skill 自带 native screenshot 能力 (绕过 screencapture)

### B7. spawned pane 不在 active tab → 截屏拍不到

**现象**: wezterm-test-skill spawn 的 pane 进入 mux server, 即使 wezterm GUI 启动了, 当前 active tab 仍是用户主会话, **不是 spawned pane**. screencapture 抓的是整屏可见内容 → 看到 wezterm 窗口但**显示别的 tab**. 用户无法肉眼看到测试中的 ccl 输出.

**Workaround**: pane.cast (ANSI-preserving text dump) 替代 screenshot 作为主证据. 不依赖窗口前台/active tab. 用 `tests/wezctl/replay.sh <cast>` 在新 pane 里 cat 渲染查看. **此为本 slice 采用的 canonical 做法**.

**修复建议 (skill side)**: skill spawn pane 时 auto-activate 那个 pane 到 foreground tab. 加 `--activate-spawned-pane` 选项. 或者更彻底: skill 自带 `--ansi-cast <path>` 选项, 内部用 `wezterm cli get-text --escapes` 拿 ANSI 写到指定路径, 不依赖外部 screencapture.

### B8. wezterm GUI 未启动时 mux-only 模式无 GUI 表示

**现象**: `wezterm-mux-server` 后台跑 (用户用 daemon 模式), `wezterm cli spawn` 创 pane 进 mux, 但**没 GUI 窗口**渲染. 此时 screencapture 拍不到. wrapper 需先 `open -a WezTerm` 启 GUI 才能视觉化 (但即使启了, 见 B7).

**Workaround (本 slice)**: wrapper 启动时 `pgrep -x wezterm-gui` 检查 + `open -a WezTerm` 强启. 不可靠 (依赖 macOS app 启动延迟 + B7 active-tab 问题).

**修复建议**: skill 或 wrapper 文档明确「headed mode 要求 wezterm-gui 进程在线 + spawned pane 必须 active」. 或者完全放弃 GUI 截屏路径, 走 ANSI cast.

---

## 类 D: 本 slice 采纳的 evidence convention (供后续 sub-slice 参考)

### D1. pane.cast = primary visual evidence

`tests/wezctl/recordings/<date>/<test-id>/pane.cast` 由 macro 内 `wezterm cli get-text --escapes --pane-id "$WEZTERM_PANE" > $CCL_TEST_PANE_CAST` 命令产, 含 pane 完整内容 (ASCII or ANSI-styled).

**Lisa 审查时**: 直接读 pane.cast 文本 → grep 期望输出 (如 `(CCL)`, `MCP`, fizzbuzz 结果) → 这是测试通过的实锤.

**人肉视觉化时**: `bash tests/wezctl/replay.sh <cast-path>` → 开新 wezterm pane → cat 渲染 → 视觉 reproduce 原始终端状态.

### D2. screenshot.png = supplementary (best-effort)

如 macOS Screen Recording 权限 + wezterm GUI active tab 切对了, screenshot.png 是真桌面截屏. 否则可能截到无关内容 (B7).

### D3. ccl-debug.log = ccl 内部 trace

macro 用 `--debug --debug-file "$CCL_TEST_DEBUG_LOG"` 让 ccl 直写 deterministic 路径.

### D4. run.json = macro 步骤 pass/fail

skill 输出, 每步 idx/type/pass/elapsed_ms.

---

## 类 C: 设计建议 / SuperRLL Sprint 优先级

### C1 (P0, 阻塞性): 修 A1+A2+A6 (PLAN backtick + judge freshness + CONSENSUS cascade race)

理由: 每个 slice 都踩, 浪费 1-2 round, 用户体验差.

### C2 (P1, 体验): 修 A3+A4+A5 (policy regex 误判 + visual-evidence 过度触发 + phase discipline)

理由: 减少 round 数, 减少 `RL_*_OFF=1` 修辞使用.

### C3 (P2, harness): 修 B1+B3+B5 (wezterm-test 文档 + wait-for input/output 区分 + env 继承)

理由: 测试基础设施完善度.

### C4 (P3, env): 修 B2+B4+B6 (wezterm pane 持久 + native window id + Screen Recording 流程化)

理由: 平台/OS 集成深度.

---

## 待补充 (本 session 后续可能发现)

slice 13 C3 完成 + slice 14 启动后, 可能发现更多. 本 doc live update.

---

## 数据出处 (复现)

- session log: jsonl `~/.claude/projects/-Users-yic-rj-Myprojects-ccl/`
- slice 10 history: `git log --grep="3p-tool-lazy-load"`
- slice 11 history: `git log --grep="ccl-customization-loaders"`
- slice 12 history: `git log --grep="enable-feature-gates-batch"`
- slice 13 history: `.dual-agent/` review.md, work.md (current state)
