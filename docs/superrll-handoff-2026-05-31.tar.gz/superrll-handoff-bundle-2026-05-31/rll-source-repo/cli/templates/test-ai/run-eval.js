#!/usr/bin/env node
/**
 * AI Eval Runner — reads cases.json, runs model-under-test, checks criteria.
 *
 * Usage: node run-eval.js [--cases cases.json] [--command "your-model-cli"]
 *
 * The command receives input via stdin and should output the response to stdout.
 * If no --command is given, it uses the MODEL_COMMAND env var.
 *
 * Output: JSON to stdout with { cases: [...], total, passed, failed }
 */

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const args = process.argv.slice(2);
const casesFile = args.includes("--cases")
  ? args[args.indexOf("--cases") + 1]
  : path.join(__dirname, "cases.json");

const modelCommand = args.includes("--command")
  ? args[args.indexOf("--command") + 1]
  : process.env.MODEL_COMMAND || null;

if (!modelCommand) {
  console.error("No model command specified. Use --command or MODEL_COMMAND env var.");
  console.error('Example: node run-eval.js --command "echo"');
  process.exit(1);
}

const cases = JSON.parse(fs.readFileSync(casesFile, "utf-8"));
const results = [];

for (const testCase of cases) {
  let output = "";
  let passed = true;
  const reasons = [];

  try {
    output = execSync(modelCommand, {
      input: testCase.input,
      encoding: "utf-8",
      timeout: 30000,
      stdio: ["pipe", "pipe", "pipe"],
    }).trim();
  } catch (e) {
    output = (e.stdout || "").trim();
    passed = false;
    reasons.push("command failed");
  }

  const lowerOutput = output.toLowerCase();

  // Check mustContain
  if (testCase.mustContain) {
    const found = testCase.mustContain.some((kw) => lowerOutput.includes(kw.toLowerCase()));
    if (!found) {
      passed = false;
      reasons.push(`missing: one of [${testCase.mustContain.join(", ")}]`);
    }
  }

  // Check mustNotContain
  if (testCase.mustNotContain) {
    for (const kw of testCase.mustNotContain) {
      if (lowerOutput.includes(kw.toLowerCase())) {
        passed = false;
        reasons.push(`contains forbidden: "${kw}"`);
      }
    }
  }

  // Check maxLength
  if (testCase.maxLength && output.length > testCase.maxLength) {
    passed = false;
    reasons.push(`too long: ${output.length} > ${testCase.maxLength}`);
  }

  const criteria = (testCase.mustContain ? 1 : 0) + (testCase.mustNotContain ? testCase.mustNotContain.length : 0) + (testCase.maxLength ? 1 : 0);
  const criteriaMatched = criteria - reasons.length;

  results.push({
    name: testCase.name,
    passed,
    criteria,
    criteriaMatched,
    ...(reasons.length > 0 ? { reason: reasons.join("; ") } : {}),
  });
}

const total = results.length;
const passed = results.filter((r) => r.passed).length;
const failed = total - passed;

console.log(JSON.stringify({ cases: results, total, passed, failed }, null, 2));
process.exit(failed > 0 ? 1 : 0);
