"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.computeInputHash = computeInputHash;
exports.extractPlanSectionBody = extractPlanSectionBody;
exports.loadComplexityInputBundle = loadComplexityInputBundle;
exports.complexityJudge = complexityJudge;
exports.cmdComplexityJudge = cmdComplexityJudge;
/**
 * §123 Layer 1 — complexity-judge (LLM-primary judgement artifact).
 *
 * Per PLAN.md §123:3540: LLM is the judgement *artifact*, NOT the gate.
 * complexity-verify (Layer 2) owns the gate.
 *
 * Modes:
 *   - `llm` (default): real provider (mockable in tests)
 *   - `heuristic`: deterministic dictionary fallback
 *   - `off`: legacy/explicit; returns empty stub; can't satisfy §123 for
 *     code-bearing slice without user ack
 *
 * Cache: `(mode, model_id, prompt_template_hash, input_hash)` tuple. Cached
 * artifact at `.dual-agent/complexity-judge/<slice>.json`. On cache HIT,
 * read + return without recompute (per Lisa R6 B8 lock).
 *
 * Cache-hit instrumentation (test-only): when
 * `process.env.RL_COMPLEXITY_JUDGE_MOCK_COUNTER` is set, increment a counter
 * file on each FULL compute (cache miss). Tests verify counter stays unchanged
 * on cache hit.
 *
 * input_hash normalization (Lisa R2 #4): SHA256 over the explicit bundle
 * `{task_description, plan_body, task_capability, manifest, git_diff_summary?}`.
 * Excludes: timestamps, abs paths, model API keys, ran_at.
 */
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const node_crypto_1 = require("node:crypto");
const HEURISTICS_DEFAULT_PATH_RELATIVE = '../templates/complexity-heuristics.json';
const PROMPT_TEMPLATE_PATH_RELATIVE = '../templates/complexity-judge-prompt.md';
const BUILT_IN_HEURISTICS = {
    schema_version: 1,
    signals: [
        { pattern: 'API|endpoint|route', type: 'regex', add_tier: 'integration', confidence: 'high' },
        { pattern: 'Linux|Windows|macOS', type: 'multi-keyword-≥2', add_tier: 'e2e', confidence: 'high' },
        { pattern: 'GUI|screenshot|render', type: 'regex', add_tier: 'smoke', confidence: 'high' },
        { pattern: 'IPC|socket|pipe|daemon|watcher', type: 'regex', add_tier: 'integration', confidence: 'high' },
        { pattern: 'migration|schema|DB', type: 'regex', add_tier: 'integration', confidence: 'high' },
        { pattern: 'auth|token|secret|credential', type: 'regex', add_tier: 'security', confidence: 'high' },
        { pattern: 'latency|memory|throughput', type: 'regex', add_tier: 'perf', confidence: 'medium' },
    ],
};
function sha256Hex(s) {
    return (0, node_crypto_1.createHash)('sha256').update(s).digest('hex');
}
/**
 * Deep canonical JSON serialization — recursively sorts object keys at every
 * level. Per Lisa R8 B9 lock: the prior `JSON.stringify(b, Object.keys(b).sort())`
 * was a bug — the 2nd arg to JSON.stringify is a REPLACER ARRAY acting as
 * property whitelist on ALL nested objects, dropping nested fields.
 */
function canonicalStringify(value) {
    if (value === null || value === undefined)
        return 'null';
    if (typeof value !== 'object')
        return JSON.stringify(value);
    if (Array.isArray(value)) {
        return '[' + value.map(canonicalStringify).join(',') + ']';
    }
    const keys = Object.keys(value).sort();
    return '{' + keys.map((k) => JSON.stringify(k) + ':' + canonicalStringify(value[k])).join(',') + '}';
}
/**
 * Compute deterministic input_hash via deep canonical serialization. Excludes
 * timestamps/abs paths (caller's responsibility — bundle inputs must already
 * be normalized).
 *
 * Per Lisa R8 B9 lock: nested fields (manifest.canonical_tier_ids,
 * taskCapability.requested_combos) MUST contribute to the hash.
 *
 * Exported per Lisa R8 B10 lock: Rule 9 / verify uses the SAME helper to
 * recompute current hash; no duplicated hash logic in plan.ts.
 */
function computeInputHash(args) {
    const bundle = {
        task_description: args.slice,
        plan_body: args.planBody,
        task_capability: args.taskCapability,
        manifest: args.manifest,
        git_diff_summary: args.gitDiffSummary ?? '',
    };
    return sha256Hex(canonicalStringify(bundle));
}
function extractPlanSectionBody(planContent, slice) {
    if (!planContent || !slice)
        return null;
    const lines = planContent.split('\n');
    const escaped = slice.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const headingRe = new RegExp(`^##\\s+§?\\d*\\.?\\s*${escaped}\\b|^##\\s+.*\`${escaped}\``);
    let start = -1;
    for (let i = 0; i < lines.length; i++) {
        if (headingRe.test(lines[i] ?? '')) {
            start = i;
            break;
        }
    }
    if (start < 0)
        return null;
    let end = lines.length;
    for (let i = start + 1; i < lines.length; i++) {
        if (/^## /.test(lines[i] ?? '')) {
            end = i;
            break;
        }
    }
    return lines.slice(start, end).join('\n');
}
function loadComplexityInputBundle(cwd, slice) {
    const stateRoot = (0, node_path_1.join)(cwd, '.dual-agent');
    const planPath = (0, node_path_1.join)(cwd, '.rll', 'PLAN.md');
    const planContent = (0, node_fs_1.existsSync)(planPath) ? (0, node_fs_1.readFileSync)(planPath, 'utf8') : '';
    const planSection = extractPlanSectionBody(planContent, slice);
    const taskPath = (0, node_path_1.join)(stateRoot, 'task.md');
    const planBody = planSection ?? ((0, node_fs_1.existsSync)(taskPath) ? (0, node_fs_1.readFileSync)(taskPath, 'utf8') : '');
    let taskCapability = {};
    const capPath = (0, node_path_1.join)(stateRoot, 'task-harness-capability.json');
    if ((0, node_fs_1.existsSync)(capPath)) {
        try {
            taskCapability = JSON.parse((0, node_fs_1.readFileSync)(capPath, 'utf8'));
        }
        catch { /* tolerate */ }
    }
    let manifest = {};
    const manifestPath = (0, node_path_1.join)(cwd, 'gate-manifest.json');
    if ((0, node_fs_1.existsSync)(manifestPath)) {
        try {
            manifest = JSON.parse((0, node_fs_1.readFileSync)(manifestPath, 'utf8'));
        }
        catch { /* tolerate */ }
    }
    return { planBody, taskCapability, manifest };
}
function loadPromptTemplate(customPath) {
    // Bundled template — try resolved relative path; fallback to inline minimal template
    const candidates = [];
    if (customPath)
        candidates.push(customPath);
    try {
        candidates.push((0, node_path_1.join)(__dirname, PROMPT_TEMPLATE_PATH_RELATIVE));
    }
    catch { /* __dirname may not be available */ }
    for (const p of candidates) {
        if ((0, node_fs_1.existsSync)(p)) {
            const content = (0, node_fs_1.readFileSync)(p, 'utf8');
            return { content, hash: sha256Hex(content) };
        }
    }
    // Minimal inline fallback so cli isn't broken if template file missing during dev
    const content = 'Analyze the slice scope and suggest required tiers from the canonical whitelist.';
    return { content, hash: sha256Hex(content) };
}
function loadHeuristics(overridePath) {
    if (overridePath) {
        if (!(0, node_fs_1.existsSync)(overridePath)) {
            throw new Error(`complexity-judge: heuristics override invalid (path not found): ${overridePath}`);
        }
        try {
            const parsed = JSON.parse((0, node_fs_1.readFileSync)(overridePath, 'utf8'));
            if (parsed.schema_version !== 1 || !Array.isArray(parsed.signals)) {
                throw new Error('invalid schema');
            }
            return parsed;
        }
        catch (e) {
            throw new Error(`complexity-judge: heuristics override invalid: ${e.message}`);
        }
    }
    return BUILT_IN_HEURISTICS;
}
/**
 * Strip fenced code blocks (```...```) + inline backtick spans from text before
 * heuristic matching. This avoids false-positives where the PLAN body
 * documents the heuristic dictionary itself (containing "auth/token/secret/...")
 * inside code blocks — those keywords are documentation, not scope signals.
 */
function stripCodeContext(text) {
    // Strip fenced ```...``` (multi-line)
    let stripped = text.replace(/```[\s\S]*?```/g, '');
    // Strip inline `...` spans
    stripped = stripped.replace(/`[^`\n]*`/g, '');
    return stripped;
}
function runHeuristic(planBody, heuristics) {
    const tiers = [];
    const seen = new Set();
    // Strip code blocks before matching to avoid documentation false-positives
    const scanText = stripCodeContext(planBody);
    for (const sig of heuristics.signals) {
        let matched = false;
        if (sig.type === 'regex') {
            const re = new RegExp(sig.pattern, 'i');
            matched = re.test(scanText);
        }
        else if (sig.type === 'multi-keyword-≥2') {
            const keywords = sig.pattern.split('|');
            let count = 0;
            for (const k of keywords) {
                if (new RegExp(`\\b${k}\\b`, 'i').test(scanText))
                    count++;
            }
            matched = count >= 2;
        }
        if (matched && !seen.has(sig.add_tier)) {
            seen.add(sig.add_tier);
            tiers.push({
                tier: sig.add_tier,
                confidence: sig.confidence,
                auto_required: sig.confidence === 'high',
                reason: `heuristic signal: pattern=${sig.pattern} type=${sig.type}`,
                evidence: { source_kind: 'heuristic-regex', source_locator: `pattern=${sig.pattern}` },
            });
        }
    }
    return { tiers, warnings: tiers.length === 0 ? ['no heuristic signals matched scope body'] : [] };
}
function cachePath(stateRoot, slice) {
    return (0, node_path_1.join)(stateRoot, 'complexity-judge', `${slice}.json`);
}
function readCache(p) {
    if (!(0, node_fs_1.existsSync)(p))
        return null;
    try {
        return JSON.parse((0, node_fs_1.readFileSync)(p, 'utf8'));
    }
    catch {
        return null;
    }
}
function writeCache(p, output) {
    (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(p), { recursive: true });
    (0, node_fs_1.writeFileSync)(p, JSON.stringify(output, null, 2));
}
function incrementMockCounter() {
    const counterPath = process.env.RL_COMPLEXITY_JUDGE_MOCK_COUNTER;
    if (!counterPath)
        return;
    let cur = 0;
    if ((0, node_fs_1.existsSync)(counterPath)) {
        try {
            cur = parseInt((0, node_fs_1.readFileSync)(counterPath, 'utf8').trim(), 10) || 0;
        }
        catch { /* ignore */ }
    }
    (0, node_fs_1.writeFileSync)(counterPath, String(cur + 1));
}
/**
 * Main complexity-judge entry. Returns artifact (cached if hit).
 */
async function complexityJudge(args) {
    const stateRoot = args.stateRoot ?? (0, node_path_1.join)(process.cwd(), '.dual-agent');
    const mode = args.mode;
    const modelId = args.modelId ?? (mode === 'llm' ? 'claude-opus-4-7' : mode === 'heuristic' ? 'heuristic-v1' : 'off-v0');
    const { hash: promptTemplateHash } = loadPromptTemplate(args.promptTemplatePath);
    const inputHash = computeInputHash(args);
    // Cache lookup — Lisa R1 B3: cache key 加 extended_flag 维度 (Q7 路径 C)
    const cp = cachePath(stateRoot, args.slice);
    const cached = readCache(cp);
    const wantExtended = args.extended === true;
    const cachedHasExtension = !!cached?.extension;
    if (cached &&
        cached.mode === mode &&
        cached.model_id === modelId &&
        cached.prompt_template_hash === promptTemplateHash &&
        cached.input_hash === inputHash &&
        cachedHasExtension === wantExtended // ← Lisa R1 B3 cache-order isolation
    ) {
        // Cache hit — no counter increment, no rewrite
        return cached;
    }
    // Cache miss → compute
    incrementMockCounter();
    let providerResponse;
    if (mode === 'off') {
        providerResponse = { tiers: [], recommendations: [], evidence: [], warnings: ['mode=off; no judgement produced'] };
    }
    else if (mode === 'heuristic') {
        const heur = loadHeuristics(args.heuristicsOverridePath);
        const result = runHeuristic(args.planBody, heur);
        providerResponse = { tiers: result.tiers, recommendations: [], evidence: [], warnings: result.warnings };
    }
    else {
        // mode === 'llm'
        if (!args.provider) {
            // If no provider injected but RL_COMPLEXITY_JUDGE_MOCK is set, use mock stub
            if (process.env.RL_COMPLEXITY_JUDGE_MOCK === '1') {
                providerResponse = { tiers: [{ tier: 'unit', confidence: 'high', auto_required: true, reason: 'mock-llm stub', evidence: { source_kind: 'mock', source_locator: 'env=RL_COMPLEXITY_JUDGE_MOCK' } }], recommendations: [], evidence: [], warnings: ['mock LLM provider'] };
            }
            else {
                throw new Error('complexity-judge: mode=llm requires `provider` arg (or set RL_COMPLEXITY_JUDGE_MOCK=1 for mock)');
            }
        }
        else {
            const { content: promptTemplate } = loadPromptTemplate(args.promptTemplatePath);
            providerResponse = await args.provider({ prompt: promptTemplate + '\n\n' + args.planBody, model_id: modelId });
        }
    }
    const output = {
        schema_version: 1,
        model_id: modelId,
        prompt_template_hash: promptTemplateHash,
        input_hash: inputHash,
        mode,
        tiers: providerResponse.tiers,
        recommendations: providerResponse.recommendations,
        evidence: providerResponse.evidence,
        warnings: providerResponse.warnings,
    };
    // §128 R3 Q7 路径 C: --extended → produce extension block
    if (args.extended === true) {
        output.extension = computeExtension(args.planBody, providerResponse.tiers);
    }
    writeCache(cp, output);
    return output;
}
/**
 * §128 R3 — heuristic computation of complexity_class + 6 dimensions for extension block.
 * Real LLM judgement will replace this; for now uses heuristic signals.
 */
function computeExtension(planBody, tiers) {
    const body = (planBody || '').toLowerCase();
    // Dimension scoring (heuristic; LLM-primary upgrade later)
    const dims = {
        scope_breadth: /cross.{0,5}(stack|module)|跨.{0,5}(包|module)/.test(body) ? 'cross-stack'
            : /multi-?file|>3.?file|跨.{0,3}文件/.test(body) ? 'wide'
                : /single.?file|few.?file/.test(body) ? 'few-files' : 'medium',
        external_data_fetch: /scraping|crawl|fetch.{0,10}data|抓取|爬取|external.{0,5}api/.test(body) ? 'high'
            : /api|webhook|http\b/.test(body) ? 'medium' : 'none',
        domain_expertise_required: /运营|商业|平台规则|法律|合规|医疗|金融/.test(body) ? 'high'
            : /design|architecture|spec/.test(body) ? 'medium' : 'generic',
        audit_stakes: /business.{0,5}critical|customer.{0,5}data|financial|legal|compliance/.test(body) ? 'medium-high'
            : /release|deploy|migration/.test(body) ? 'medium' : 'low',
        iteration_volume_expected: /complex|reformat|reframe|iteration|review.{0,5}rounds/.test(body) ? '6-10' : '3-5',
        knowledge_freshness_dependency: /latest|recent|2026|新版本|最新|policy|政策/.test(body) ? 'high'
            : /version|update|sdk/.test(body) ? 'medium' : 'none',
    };
    // Class: complex if any high; expert if multiple high; standard if mostly low/medium; simple else
    const highCount = Object.values(dims).filter((v) => typeof v === 'string' && (v === 'high' || v === 'medium-high' || v === 'wide' || v === 'cross-stack' || v === '6-10')).length;
    const class_ = highCount >= 4 ? 'expert' :
        highCount >= 2 ? 'complex' :
            highCount >= 1 ? 'standard' : 'simple';
    const evidence = [];
    for (const [k, v] of Object.entries(dims)) {
        if (typeof v === 'string' && (v === 'high' || v === 'medium-high' || v === 'wide' || v === 'cross-stack')) {
            evidence.push(`${k}=${v}`);
        }
    }
    if (tiers.length > 0)
        evidence.push(`tier_signals=${tiers.map((t) => t.tier).join(',')}`);
    return {
        schema_version: 1,
        task_complexity_class: class_,
        complexity_confidence: highCount >= 2 ? 'high' : 'medium',
        complexity_dimensions: dims,
        complexity_evidence: evidence,
    };
}
/**
 * Cli sub-cmd dispatch: `ralph-lisa task complexity-judge ...`
 */
async function cmdComplexityJudge(args, cwd = process.cwd()) {
    if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
        process.stdout.write('Usage: ralph-lisa task complexity-judge --slice <slug> [--mode llm|heuristic|off] [--json]\n');
        process.stdout.write('\n');
        process.stdout.write('  --slice <slug>   Slice slug (required)\n');
        process.stdout.write('  --mode <m>       llm | heuristic | off (default: llm — set RL_COMPLEXITY_JUDGE_MOCK=1 in tests or provide --provider; use --mode heuristic for offline)\n');
        process.stdout.write('  --json           Emit strict JSON to stdout\n');
        process.stdout.write('\n');
        process.stdout.write('Layer 1 LLM-primary judgement artifact. Output cached at\n');
        process.stdout.write('.dual-agent/complexity-judge/<slice>.json. canonical_tier_ids whitelist\n');
        process.stdout.write('enforced via gate-manifest.json (see also: ralph-lisa task complexity-verify).\n');
        return args.length === 0 ? 2 : 0;
    }
    const slice = getFlag(args, '--slice');
    if (!slice) {
        process.stderr.write('complexity-judge: --slice required\n');
        return 2;
    }
    // §123 R3.2 B13 lock: default mode is `llm` per PLAN.md §123 "Mode semantics"
    // + module-level docstring. LLM-primary is the contract; default mode must
    // exercise that path. Tests/CI use --mode heuristic OR RL_COMPLEXITY_JUDGE_MOCK=1.
    const modeArg = (getFlag(args, '--mode') ?? 'llm');
    const json = args.includes('--json');
    const extended = args.includes('--extended');
    const stateRoot = (0, node_path_1.join)(cwd, '.dual-agent');
    const { planBody, taskCapability, manifest } = loadComplexityInputBundle(cwd, slice);
    try {
        const output = await complexityJudge({
            slice,
            mode: modeArg,
            planBody,
            taskCapability,
            manifest,
            stateRoot,
            extended,
        });
        if (json) {
            process.stdout.write(JSON.stringify(output, null, 2) + '\n');
        }
        else {
            process.stdout.write(`complexity-judge: slice=${slice} mode=${modeArg} tiers=${output.tiers.length}\n`);
        }
        return 0;
    }
    catch (e) {
        process.stderr.write(`complexity-judge: ${e.message}\n`);
        return 1;
    }
}
function getFlag(args, flag) {
    const idx = args.indexOf(flag);
    if (idx < 0)
        return undefined;
    return args[idx + 1];
}
