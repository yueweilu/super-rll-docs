"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTaskStateArgs = parseTaskStateArgs;
exports.cmdTaskState = cmdTaskState;
/**
 * §60 task-state-wecom-bridge — cli sub-cmd `ralph-lisa task-state <kind> [--note <text>]`.
 * Fires a `task_state_change` event through the existing wecom-hook seam.
 * Manual invoke only; auto-detection deferred to §61+.
 */
const node_fs_1 = require("node:fs");
const path = __importStar(require("node:path"));
const state_js_1 = require("./state.js");
const wecom_hook_js_1 = require("./wecom-hook.js");
const KIND_MAP = {
    done: "task_done",
    failed: "task_failed",
    "pending-user": "task_pending_user",
};
/**
 * Pure: argv → { kind, note, error }. First arg is the required kind name
 * (`done` / `failed` / `pending-user`); `--note <text>` is optional.
 */
function parseTaskStateArgs(argv) {
    if (argv.length === 0) {
        return { kind: null, note: undefined, error: "kind is required (done | failed | pending-user)" };
    }
    const rawKind = argv[0];
    const kind = KIND_MAP[rawKind];
    if (kind === undefined) {
        return { kind: null, note: undefined, error: `invalid kind "${rawKind}" (must be done | failed | pending-user)` };
    }
    let note;
    for (let i = 1; i < argv.length; i++) {
        if (argv[i] === "--note") {
            note = argv[i + 1];
            i++;
        }
    }
    return { kind, note, error: null };
}
function readContextFile(dir, filename, readFileFn) {
    try {
        return readFileFn(path.join(dir, filename)).trim();
    }
    catch {
        return "";
    }
}
function cmdTaskState(opts = {}) {
    const argv = opts.argv ?? process.argv.slice(3);
    const writeStderr = opts.writeStderrFn ?? ((s) => process.stderr.write(s));
    const write = opts.writeFn ?? ((s) => process.stdout.write(s));
    const parsed = parseTaskStateArgs(argv);
    if (parsed.kind === null || parsed.error !== null) {
        writeStderr(`task-state: ${parsed.error}\n`);
        return 1;
    }
    const dir = opts.dir ?? (() => {
        try {
            return (0, state_js_1.stateDir)();
        }
        catch {
            return path.join(".dual-agent");
        }
    })();
    const readFile = opts.readFileFn ?? ((p) => (0, node_fs_1.readFileSync)(p, "utf8"));
    const step = readContextFile(dir, "step.txt", readFile) || "(unknown)";
    const roundRaw = readContextFile(dir, "round.txt", readFile);
    const round = roundRaw ? Number(roundRaw) || roundRaw : 0;
    const changeExtra = {
        kind: parsed.kind,
        step,
        round,
        note: parsed.note,
    };
    try {
        (0, wecom_hook_js_1.pushTaskStateChange)(dir, changeExtra, opts.pushFn);
        write(`task-state: emitted ${parsed.kind} event\n`);
        return 0;
    }
    catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        writeStderr(`task-state: hook failed (${msg}); local state unchanged\n`);
        return 0; // never-fatal; the local turn-state is untouched anyway
    }
}
