# Skill Fixtures (§172)

JSON fixtures expressing macro/spec shapes for §171 wezterm-test-skill and §173 playwright-test-skill, based on `docs/§159-3cli-macro-dev-tasks-design.md` D1+D3 dev tasks.

## Files

- `d1-todo-app.macro.json` — wezterm macro for D1 full-stack todo-app build (drives a CLI agent to scaffold server.js + index.html + test.sh)
- `d1-todo-app.spec.json` — playwright spec verifying the D1 todo-app's HTTP+frontend (assumes running server on PORT=3001)
- `d3-codebase-extend.macro.json` — wezterm macro for D3 codebase-extend feature (drives a CLI agent to add a new `GET /health` endpoint returning `{status:'ok', uptime_sec:<process.uptime() integer>}` plus a `test/server.test.js` assertion to a pre-seeded Express server). Per `docs/§159-3cli-macro-dev-tasks-design.md:216-237`.

## Usage

List all available fixtures:

```
ralph-lisa skill list-fixtures
```

Run a fixture (example — wezterm macro):

```
ralph-lisa skill wezterm-test --macro $(ralph-lisa skill list-fixtures --json | jq -r '.[] | select(.name=="d1-todo-app-build") | .path')
```

Or directly:

```
ralph-lisa skill wezterm-test --macro cli/templates/skill-fixtures/d1-todo-app.macro.json
```

## SCOPE — out-of-scope vs in-scope (§172 explicit Lisa R1 B2 decision)

**In scope (§172)**:
- Fixtures express macro/spec SHAPE conforming to §171 / §173 6-step schemas
- parseMacro + parseSpec accept them without throwing
- CLI `list-fixtures` enumerates them

**Out of scope (§172)**:
- **Full runnable D1/D3 execution**: actually running the CLI agent (claude / codex / aider) against the macro, enforcing the §159 D1 PORT contract (`process.env.PORT` from `docs/§159-3cli-macro-dev-tasks-design.md:72,81,90`), executing the resulting test.sh + curl-verifying the running server.
- **Full D2 bug-debug-fix macro** (separate dogfood slice)
- **Multi-CLI orchestration** (claude/codex/aider parallel comparison)
- **PORT injection mechanism**: §171 wezterm-test-skill's `spawn` step currently accepts only `cwd` (cli/src/wezterm-test-skill.ts:14). Real D1 execution would need a `spawn.env` field; defer to follow-up slice when D1 dogfood is budgeted.

Full runnable validation requires a dedicated `§159 D1 dogfood` slice with explicit cost budget (5-15 min wall-clock per cli + LLM token cost).
