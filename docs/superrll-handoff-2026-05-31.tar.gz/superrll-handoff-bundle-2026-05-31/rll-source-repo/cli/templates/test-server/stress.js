import http from "k6/http";
import { check, sleep } from "k6";

export const options = {
  stages: [
    { duration: "10s", target: 10 },    // warm up
    { duration: "10s", target: 100 },   // spike
    { duration: "30s", target: 100 },   // hold at spike
    { duration: "10s", target: 10 },    // recover
    { duration: "10s", target: 0 },     // ramp down
  ],
  thresholds: {
    http_req_duration: ["p(95)<2000"],
    http_req_failed: ["rate<0.05"],
  },
};

const BASE_URL = __ENV.BASE_URL || "http://localhost:3000";

export default function () {
  const res = http.get(`${BASE_URL}/api/health`);
  check(res, {
    "status is 200": (r) => r.status === 200,
  });
  sleep(0.1);
}
