#!/usr/bin/env node
/**
 * Visual/UX Test Runner — captures screenshots and evaluates them.
 *
 * Usage: node visual-check.js [--screenshots <dir>] [--criteria <file>]
 *
 * This script:
 * 1. Reads screenshot files from the specified directory
 * 2. For each screenshot, evaluates against criteria (if provided)
 * 3. Outputs JSON results to stdout
 *
 * To integrate with Claude Vision or other visual AI:
 * - Set VISUAL_EVAL_CMD env var to a command that accepts image path as $1
 *   and outputs a JSON assessment to stdout
 * - Example: VISUAL_EVAL_CMD="python eval_screenshot.py"
 *
 * Without VISUAL_EVAL_CMD, this performs basic file-existence checks only.
 */

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const args = process.argv.slice(2);
const screenshotsDir = args.includes("--screenshots")
  ? args[args.indexOf("--screenshots") + 1]
  : path.join(__dirname, "screenshots");

const criteriaFile = args.includes("--criteria")
  ? args[args.indexOf("--criteria") + 1]
  : path.join(__dirname, "criteria.json");

const evalCmd = process.env.VISUAL_EVAL_CMD || null;

// Load criteria if available
let criteria = {};
if (fs.existsSync(criteriaFile)) {
  criteria = JSON.parse(fs.readFileSync(criteriaFile, "utf-8"));
}

// Find screenshot files
if (!fs.existsSync(screenshotsDir)) {
  console.error(`Screenshots directory not found: ${screenshotsDir}`);
  console.error("Capture screenshots first, then run visual checks.");
  console.log(JSON.stringify({ cases: [], total: 0, passed: 0, failed: 0, skipped: 0 }));
  process.exit(0);
}

const imageExts = [".png", ".jpg", ".jpeg", ".webp"];
const files = fs.readdirSync(screenshotsDir)
  .filter((f) => imageExts.includes(path.extname(f).toLowerCase()));

if (files.length === 0) {
  console.log(JSON.stringify({ cases: [], total: 0, passed: 0, failed: 0, skipped: 0 }));
  process.exit(0);
}

const results = [];

for (const file of files) {
  const filePath = path.join(screenshotsDir, file);
  const name = path.basename(file, path.extname(file));
  const fileCriteria = criteria[name] || {};

  const hasCriteria = fileCriteria.checks && fileCriteria.checks.length > 0;

  if (!evalCmd) {
    // Without vision eval command: file-existence + criteria presence check
    const stats = fs.statSync(filePath);
    const fileOk = stats.size > 0;
    results.push({
      name,
      file,
      passed: fileOk,
      reason: fileOk
        ? `file exists (${stats.size} bytes)` + (hasCriteria ? ` — ${fileCriteria.checks.length} criteria defined (needs VISUAL_EVAL_CMD to evaluate)` : "")
        : "empty file",
      criteria: hasCriteria ? fileCriteria.checks : [],
      evaluated: false,
    });
    continue;
  }

  // Run visual evaluation command — pass criteria as VISUAL_CRITERIA env var
  try {
    const evalEnv = { ...process.env };
    if (hasCriteria) {
      evalEnv.VISUAL_CRITERIA = JSON.stringify(fileCriteria.checks);
      evalEnv.VISUAL_DESCRIPTION = fileCriteria.description || name;
    }
    const output = execSync(`${evalCmd} "${filePath}"`, {
      encoding: "utf-8",
      timeout: 60000,
      stdio: ["pipe", "pipe", "pipe"],
      env: evalEnv,
    }).trim();

    try {
      const assessment = JSON.parse(output);
      results.push({
        name,
        file,
        passed: assessment.passed !== false,
        score: assessment.score,
        issues: assessment.issues || [],
        reason: assessment.reason || "evaluated",
        evaluated: true,
      });
    } catch {
      // Non-JSON output — treat as pass if exit code was 0
      results.push({
        name,
        file,
        passed: true,
        reason: output.slice(0, 200),
        evaluated: true,
      });
    }
  } catch (e) {
    results.push({
      name,
      file,
      passed: false,
      reason: `eval command failed: ${e.message || "unknown error"}`,
      evaluated: true,
    });
  }
}

const total = results.length;
const passed = results.filter((r) => r.passed).length;
const failed = total - passed;
const evaluated = results.filter((r) => r.evaluated).length;

console.log(JSON.stringify({ cases: results, total, passed, failed, evaluated }, null, 2));
process.exit(failed > 0 ? 1 : 0);
