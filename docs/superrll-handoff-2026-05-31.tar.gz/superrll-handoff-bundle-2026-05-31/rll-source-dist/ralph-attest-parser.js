"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseRalphAttest = parseRalphAttest;
exports.verifyRalphAttest = verifyRalphAttest;
/**
 * §149 P2-ralph-attest — Ralph-side attest block parser + verifier.
 *
 * Pure functions + git-diff cite (sole shell exec via spawnSync git rev-parse argv-style).
 * Parse Test-Process / Test-Cases / Test-Results from Ralph [CODE]/[FIX] body.
 * Verify file-path containment (repoRoot/stateRoot per §144 B13); git-diff argv safety
 * (reject `-` prefix; spawn argv-style without shell option); log-cite via §137 verifier.
 */
const fs = __importStar(require("node:fs"));
const path = __importStar(require("node:path"));
const node_child_process_1 = require("node:child_process");
function parseRalphAttest(body) {
    if (!body)
        return null;
    const lines = body.split('\n');
    let test_process;
    let test_cases = [];
    let test_results;
    for (const line of lines) {
        const procFileM = line.match(/^Test-Process-File:\s*(.+)$/);
        if (procFileM) {
            test_process = { kind: 'file-path', value: procFileM[1].trim() };
            continue;
        }
        const procM = line.match(/^Test-Process:\s*(.+)$/);
        if (procM) {
            const v = procM[1].trim();
            if (v.startsWith('git-diff ')) {
                test_process = { kind: 'git-diff', value: v.slice(9).trim() };
            }
            else if (v.startsWith('file://') || v.startsWith('file:')) {
                test_process = { kind: 'file-path', value: v.replace(/^file:\/\/|^file:/, '') };
            }
            else if (/^Test-Process-File/.test(v)) {
                // edge case
            }
            else {
                test_process = { kind: 'inline', value: v };
            }
            continue;
        }
        const casesM = line.match(/^Test-Cases:\s*(.+)$/);
        if (casesM) {
            test_cases = [...casesM[1].matchAll(/C\d+/g)].map((m) => m[0]);
            continue;
        }
        const resFileM = line.match(/^Test-Results-File:\s*(.+)$/);
        if (resFileM) {
            test_results = { kind: 'file-path', cmd: resFileM[1].trim() };
            continue;
        }
        const resM = line.match(/^Test-Results:\s*(.+)$/);
        if (resM) {
            const v = resM[1];
            const cmdM = v.match(/cmd="([^"]+)"|cmd=(\S+)/);
            const cmd = cmdM ? (cmdM[1] ?? cmdM[2]) : undefined;
            const passed = v.match(/passed=(\d+)/);
            const failed = v.match(/failed=(\d+)/);
            const total = v.match(/total=(\d+)/);
            const counts = {};
            if (passed)
                counts.passed = Number(passed[1]);
            if (failed)
                counts.failed = Number(failed[1]);
            if (total)
                counts.total = Number(total[1]);
            // log-cite kind detection: has cmd + counts (without inline log path)
            const kind = cmd ? 'log-cite' : 'inline';
            test_results = { kind: kind, ...(cmd && { cmd }), counts };
        }
    }
    if (!test_process && test_cases.length === 0 && !test_results)
        return null;
    return {
        test_process: test_process ?? { kind: 'inline', value: '' },
        test_cases,
        test_results: test_results ?? { kind: 'inline', counts: {} },
    };
}
function isContained(absPath, containerAbs) {
    return absPath === containerAbs || absPath.startsWith(containerAbs + path.sep);
}
function verifyRalphAttest(attest, opts) {
    const missing = [];
    const unverified = [];
    const repoRootAbs = path.resolve(opts.repoRoot);
    const stateRootAbs = path.resolve(opts.stateRoot);
    // test_process verify
    if (attest.test_process.kind === 'file-path') {
        const value = attest.test_process.value;
        // file://, file:/, scheme detection
        if (/^file:/.test(value)) {
            unverified.push({ kind: 'test-process', reason: `file:// URL scheme not allowed; use plain path within repo/state trust boundary` });
        }
        else {
            const abs = path.isAbsolute(value) ? path.resolve(value) : path.resolve(repoRootAbs, value);
            if (!isContained(abs, repoRootAbs) && !isContained(abs, stateRootAbs)) {
                unverified.push({ kind: 'test-process', reason: `file path outside trust-boundary (resolved=${abs}; must be under repoRoot=${repoRootAbs} OR stateRoot=${stateRootAbs}); containment check failed` });
            }
            else if (!fs.existsSync(abs)) {
                unverified.push({ kind: 'test-process', reason: `file path does not exist: ${abs}` });
            }
        }
    }
    else if (attest.test_process.kind === 'git-diff') {
        const range = attest.test_process.value;
        if (range.startsWith('-')) {
            unverified.push({ kind: 'test-process', reason: `git-diff range starting with '-' rejected (option-injection prevention); got "${range}"` });
        }
        else {
            // argv-style spawn — NO shell exec; shell metachars passed as literal arg string
            try {
                // Note: `--verify` requires single rev, doesn't accept ranges. Plain `rev-parse <range>`
                // succeeds for both single SHAs and `A..B` ranges; argv-style spawn keeps metachars inert.
                const r = (0, node_child_process_1.spawnSync)('git', ['rev-parse', range], { cwd: repoRootAbs, encoding: 'utf8', timeout: 5000 });
                if (r.status !== 0) {
                    unverified.push({ kind: 'test-process', reason: `git-diff range "${range}" failed rev-parse (invalid range)` });
                }
            }
            catch {
                unverified.push({ kind: 'test-process', reason: `git-diff verification error for range "${range}"` });
            }
        }
    }
    // test_results verify
    if (attest.test_results.kind === 'log-cite' && attest.test_results.cmd) {
        try {
            const verifier = require('./test-results-claim-verifier.js');
            const claims = [{ cmd: attest.test_results.cmd, ...(attest.test_results.counts ?? {}) }];
            const r = verifier.verifyTestResultsClaims(claims, { stateRoot: opts.stateRoot, maxAgeMin: 10 });
            if (r.unverified.length > 0) {
                unverified.push({ kind: 'test-results', reason: `log-cite mismatch: ${JSON.stringify(r.unverified[0])}` });
            }
        }
        catch { /* never fatal */ }
    }
    else if (attest.test_results.kind === 'file-path') {
        const value = attest.test_results.cmd ?? '';
        const abs = path.isAbsolute(value) ? path.resolve(value) : path.resolve(repoRootAbs, value);
        if (!isContained(abs, repoRootAbs) && !isContained(abs, stateRootAbs)) {
            unverified.push({ kind: 'test-results', reason: `file path outside trust-boundary: ${abs}` });
        }
        else if (!fs.existsSync(abs)) {
            unverified.push({ kind: 'test-results', reason: `file path does not exist: ${abs}` });
        }
    }
    return { missing, unverified };
}
