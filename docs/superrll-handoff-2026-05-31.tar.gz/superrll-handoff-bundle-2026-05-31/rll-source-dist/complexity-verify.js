"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.complexityVerify = complexityVerify;
exports.compareLisaRerun = compareLisaRerun;
exports.cmdComplexityVerify = cmdComplexityVerify;
/**
 * §123 Layer 2 — complexity-verify (deterministic HARD GATE).
 *
 * Submit-time policy + plan-keeper Rule 9 BLOCK on verify failure.
 *
 * Verify checks:
 *   1. schema validates (judge artifact has all required fields)
 *   2. input_hash freshness (recomputed from current PLAN+capability+manifest matches)
 *   3. canonical tier IDs enforced (no drift, all tier values in whitelist)
 *   4. each high-conf tier accepted-or-acked-rejected (in planTable Required OR explicit reject ledger)
 *   5. Required table coverage (expected_required = L1∪L2∪L3∪L4_high - downgrades)
 *   6. heuristic sanity-flag on obvious PLAN-keyword-miss (warning, optionally upgradeable)
 *
 * Per Lisa R6 B8 + R2 #1 lock: deterministic ownership; LLM doesn't gate.
 */
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const complexity_judge_js_1 = require("./complexity-judge.js");
const REQUIRED_JUDGE_FIELDS = ['schema_version', 'model_id', 'prompt_template_hash', 'input_hash', 'mode', 'tiers', 'recommendations', 'evidence', 'warnings'];
function complexityVerify(args) {
    const errors = [];
    const warnings = [];
    const j = args.judge;
    // 1. schema valid
    for (const field of REQUIRED_JUDGE_FIELDS) {
        if (!(field in j)) {
            errors.push({ rule: 'complexity-verify-schema-missing-field', detail: `judge artifact missing required field: ${field}` });
        }
    }
    // 2. freshness
    if (j.input_hash !== args.currentInputHash) {
        errors.push({ rule: 'complexity-verify-freshness-stale', detail: `judge input_hash=${j.input_hash.slice(0, 16)}... but current=${args.currentInputHash.slice(0, 16)}... — re-run complexity-judge` });
    }
    // 3. canonical tier IDs
    const canonical = new Set(args.manifest.canonical_tier_ids);
    for (const t of j.tiers || []) {
        if (!canonical.has(t.tier)) {
            errors.push({ rule: 'complexity-verify-tier-id-drift', detail: `tier "${t.tier}" not in canonical_tier_ids whitelist (drift); allowed: ${[...canonical].join(', ')}` });
        }
    }
    // 4. high-conf accepted-or-acked-rejected
    const acceptedTiers = new Set(args.planTable.filter((r) => r.required).map((r) => r.tier));
    const rejected = new Set(args.rejectedTiers ?? []);
    for (const t of j.tiers || []) {
        if (t.confidence === 'high' && !acceptedTiers.has(t.tier) && !rejected.has(t.tier)) {
            errors.push({ rule: 'complexity-verify-high-confidence-not-accepted', detail: `high-confidence tier "${t.tier}" neither accepted (in planTable Required) nor explicitly rejected (with ack-downgrade ledger)` });
        }
    }
    // 5. Required table coverage
    const expectedRequired = new Set();
    for (const tier of args.manifest.default_baseline)
        expectedRequired.add(tier);
    for (const t of j.tiers || []) {
        if (t.auto_required && t.confidence === 'high' && !rejected.has(t.tier)) {
            expectedRequired.add(t.tier);
        }
    }
    for (const tier of expectedRequired) {
        if (!acceptedTiers.has(tier)) {
            errors.push({ rule: 'complexity-verify-coverage-missing', detail: `expected required tier "${tier}" not in planTable Required` });
        }
    }
    // 6. heuristic sanity-flag (warning-level)
    if (args.planBody) {
        const body = args.planBody;
        const sanityRules = [
            { pattern: /\bAPI\b|\bendpoint\b/i, expectTier: 'integration', signal: 'API/endpoint' },
            { pattern: /\bIPC\b|\bsocket\b|\bdaemon\b/i, expectTier: 'integration', signal: 'IPC/socket/daemon' },
            { pattern: /\bauth\b|\btoken\b|\bsecret\b/i, expectTier: 'security', signal: 'auth/token/secret' },
        ];
        for (const rule of sanityRules) {
            if (rule.pattern.test(body) && !acceptedTiers.has(rule.expectTier)) {
                warnings.push({ rule: 'complexity-verify-sanity-keyword-miss', detail: `PLAN mentions ${rule.signal} but tier "${rule.expectTier}" not in planTable Required` });
            }
        }
    }
    return {
        ok: errors.length === 0,
        exitCode: errors.length === 0 ? 0 : 1,
        errors,
        warnings,
    };
}
function compareLisaRerun(args) {
    const narrows = [];
    const warnings = [];
    if (args.lisaRerunStatus === 'unavailable' || args.lisa === null) {
        return { block: false, rerun_unavailable: true, narrows, warnings };
    }
    const ralphAccepted = new Set(args.ralphAcceptedTiers);
    const ralphRejected = new Set(args.ralphRejectedTiers);
    for (const lisaTier of args.lisa.tiers || []) {
        if (lisaTier.confidence === 'high') {
            if (!ralphAccepted.has(lisaTier.tier) && !ralphRejected.has(lisaTier.tier)) {
                narrows.push({
                    rule: 'lisa-rerun-high-confidence-missing',
                    severity: 'narrow',
                    detail: `Lisa rerun found high-confidence tier "${lisaTier.tier}" not in Ralph's accepted+rejected set`,
                });
            }
        }
        else {
            // medium/low — audit warning only
            if (!ralphAccepted.has(lisaTier.tier)) {
                warnings.push({
                    rule: 'lisa-rerun-medium-low-divergence',
                    detail: `Lisa rerun has ${lisaTier.confidence}-confidence tier "${lisaTier.tier}" not in Ralph's plan (audit warning, not block)`,
                });
            }
        }
    }
    return { block: narrows.length > 0, rerun_unavailable: false, narrows, warnings };
}
/**
 * Cli sub-cmd dispatch: `ralph-lisa task complexity-verify ...`
 */
async function cmdComplexityVerify(args, cwd = process.cwd()) {
    if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
        process.stdout.write('Usage: ralph-lisa task complexity-verify --slice <slug> [--json]\n');
        process.stdout.write('\n');
        process.stdout.write('Layer 2 deterministic hard gate. Verifies complexity-judge artifact:\n');
        process.stdout.write('  - schema valid\n');
        process.stdout.write('  - input_hash freshness\n');
        process.stdout.write('  - canonical tier IDs enforced (no drift)\n');
        process.stdout.write('  - high-conf tier accepted-or-acked-rejected\n');
        process.stdout.write('  - Required table coverage\n');
        process.stdout.write('  - heuristic sanity-flag (warning)\n');
        process.stdout.write('\n');
        process.stdout.write('Exit 0 on consistent; exit 1 on any error. canonical_tier_ids whitelist\n');
        process.stdout.write('enforced via gate-manifest.json.\n');
        return args.length === 0 ? 2 : 0;
    }
    const slice = getFlag(args, '--slice');
    if (!slice) {
        process.stderr.write('complexity-verify: --slice required\n');
        return 2;
    }
    const json = args.includes('--json');
    const stateRoot = (0, node_path_1.join)(cwd, '.dual-agent');
    const judgePath = (0, node_path_1.join)(stateRoot, 'complexity-judge', `${slice}.json`);
    if (!(0, node_fs_1.existsSync)(judgePath)) {
        process.stderr.write(`complexity-verify: judge artifact missing at ${judgePath}; run complexity-judge first\n`);
        return 1;
    }
    let judge;
    try {
        judge = JSON.parse((0, node_fs_1.readFileSync)(judgePath, 'utf8'));
    }
    catch (e) {
        process.stderr.write(`complexity-verify: invalid judge artifact: ${e.message}\n`);
        return 1;
    }
    const manifestPath = (0, node_path_1.join)(cwd, 'gate-manifest.json');
    if (!(0, node_fs_1.existsSync)(manifestPath)) {
        process.stderr.write(`complexity-verify: gate-manifest.json missing at ${manifestPath}\n`);
        return 1;
    }
    const manifest = JSON.parse((0, node_fs_1.readFileSync)(manifestPath, 'utf8'));
    // Extract planTable from PLAN.md §N section matching slice
    const planPath = (0, node_path_1.join)(cwd, '.rll', 'PLAN.md');
    const planContent = (0, node_fs_1.existsSync)(planPath) ? (0, node_fs_1.readFileSync)(planPath, 'utf8') : '';
    const planTable = extractPlanTable(planContent, slice);
    const { planBody, taskCapability } = (0, complexity_judge_js_1.loadComplexityInputBundle)(cwd, slice);
    // Per Lisa R8 B10: recompute via shared computeInputHash helper (avoids
    // duplicated hash logic; matches complexity-judge's serialization exactly).
    const currentHash = (0, complexity_judge_js_1.computeInputHash)({
        slice,
        planBody,
        taskCapability,
        manifest,
    });
    // §157 — load the explicitly-rejected tiers from the ack-downgrade ledger so
    // an `ack-downgrade`d false-positive tier is honored by the verifier.
    let rejectedTiers = [];
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const tc = require('./task-capability.js');
        rejectedTiers = tc.loadRejectedTiersFromLedger(slice, (0, node_path_1.join)(cwd, '.dual-agent'));
    }
    catch { /* never fatal — absent ledger → no rejections */ }
    const result = complexityVerify({
        judge,
        planTable,
        manifest: {
            canonical_tier_ids: manifest.canonical_tier_ids ?? [],
            default_baseline: manifest.default_baseline ?? [],
        },
        currentInputHash: currentHash,
        planBody,
        rejectedTiers,
    });
    if (json) {
        process.stdout.write(JSON.stringify(result, null, 2) + '\n');
    }
    else {
        if (result.ok) {
            process.stdout.write(`complexity-verify: slice=${slice} ok (warnings=${result.warnings.length})\n`);
        }
        else {
            process.stdout.write(`complexity-verify: slice=${slice} FAILED (errors=${result.errors.length})\n`);
            for (const e of result.errors)
                process.stdout.write(`  - ${e.rule}: ${e.detail}\n`);
        }
    }
    return result.exitCode;
}
function extractPlanTable(content, slice) {
    if (!content || !slice)
        return [];
    const lines = content.split('\n');
    // Find section heading matching slice
    const headingRe = new RegExp(`^##\\s+.*\`${slice.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')}\``);
    let start = -1;
    for (let i = 0; i < lines.length; i++) {
        if (headingRe.test(lines[i] ?? '')) {
            start = i;
            break;
        }
    }
    if (start < 0)
        return [];
    let end = lines.length;
    for (let i = start + 1; i < lines.length; i++) {
        if (/^##\s/.test(lines[i] ?? '')) {
            end = i;
            break;
        }
    }
    const section = lines.slice(start, end);
    const rows = [];
    for (let i = 0; i < section.length; i++) {
        const line = section[i] ?? '';
        if (!/^\|\s*C\d+\s*\|/.test(line))
            continue;
        const cells = line.split('|').map((c) => c.trim());
        if (cells.length < 6)
            continue;
        // §145 P1-parser-schema: 6-col Phase table support; backward-compat with 5-col.
        // 5-col row → cells.length===7 (incl 2 boundary empties); 6-col → cells.length===8.
        const is6Col = cells.length >= 8;
        const tierIdx = is6Col ? 3 : 2;
        const requiredIdx = is6Col ? 6 : 5;
        const tier = (cells[tierIdx] ?? '').split(/\s+/)[0]?.toLowerCase() ?? '';
        const required = (cells[requiredIdx] ?? '').includes('✓');
        if (tier)
            rows.push({ tier, required });
    }
    return rows;
}
function getFlag(args, flag) {
    const idx = args.indexOf(flag);
    if (idx < 0)
        return undefined;
    return args[idx + 1];
}
