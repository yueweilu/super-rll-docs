# 微信小程序测试

## 四种测试方式

| 方式 | 工具 | 适用场景 |
|------|------|---------|
| 1. 开发者工具自动化 | miniprogram-automator | 精确、稳定，CI 友好 |
| 2. 视觉驱动 (开发者工具) | Midscene Bridge Mode | AI 驱动，无需 selector |
| 3. 视觉驱动 (真机) | Midscene + Android/iOS | 真实环境测试 |
| 4. H5 版本测试 | Playwright | 最简单，不覆盖原生能力 |

## 方式 1: miniprogram-automator

```bash
npm install miniprogram-automator --save-dev
# 开发者工具 → 设置 → 安全 → 开启服务端口
node tests/miniprogram/smoke.automator.js
```

Harness 配置:
```json
{
  "testHarness": {
    "setup": {
      "command": "开发者工具cli auto --project ./miniprogram --auto-port 9420",
      "waitFor": "http://localhost:9420",
      "timeout": 60000
    },
    "tests": {
      "mp-smoke": {
        "command": "node tests/miniprogram/smoke.automator.js"
      }
    }
  }
}
```

## 方式 2: Midscene Bridge Mode

```bash
npm install @midscene/cli --save-dev
# 安装 Midscene Chrome 扩展
# 配置 VLM provider (OpenAI, Qwen-VL, Doubao — Claude 不支持)
npx midscene tests/miniprogram/smoke.midscene.yaml
```

## 方式 3: Midscene 真机

```bash
# Android
npx midscene tests/mobile/smoke-android.yaml
# iOS
npx midscene tests/mobile/smoke-ios.yaml
```

## 方式 4: H5 版本

如果小程序有对应的 H5 版本:
```bash
ralph-lisa test init web
# 修改 BASE_URL 指向 H5 版本
npx playwright test tests/web/
```

## Case 文件生成

```bash
# 分析项目结构
ralph-lisa test analyze

# 生成 automator 脚本 (需要 locator)
ralph-lisa test gen automator TC_MINI_001

# 生成 Midscene YAML (使用自然语言)
ralph-lisa test gen midscene TC_MINI_001

# 直接用 Case 意图执行
ralph-lisa test run-case TC_MINI_001
```
