#!/bin/bash
# rll-voice-hook.sh — Swabble hook wrapper for super-rll local-voice-io-skill.
#
# Invoked by Swabble's HookExecutor on every committed (post-isFinal, post-wake-strip)
# utterance. Reads $SWABBLE_TEXT from env and forwards it as a typed command to
# the ralph tmux pane via `tmux send-keys`.
#
# Pane resolution: $RLL_RALPH_PANE env, populated by `ralph-lisa voice setup`
# into the launchd plist EnvironmentVariables block. Format: "<session>:<window>.<pane>".
#
# Note: relies on Swabble local-voice-io-skill upstream patch — Swabble's Serve
# loop must gate hook firing on `seg.isFinal`, otherwise this script will be
# called per partial transcript and ralph's pane will fill with junk.

set -e

# Empty utterance — Swabble hook fired with no text. Skip.
if [ -z "$SWABBLE_TEXT" ]; then
  exit 0
fi

# RLL_RALPH_PANE is required. Surface a stderr line on launchd log so the user
# knows setup is incomplete instead of silently dropping the voice input.
if [ -z "$RLL_RALPH_PANE" ]; then
  echo "[rll-voice-hook] error: RLL_RALPH_PANE env not set; run 'ralph-lisa voice setup' to populate" >&2
  exit 1
fi

# Forward to ralph: tmux types each character of SWABBLE_TEXT into the pane,
# then presses Enter to submit.
tmux send-keys -t "$RLL_RALPH_PANE" -- "$SWABBLE_TEXT" Enter
