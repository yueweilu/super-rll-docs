"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readPhaseState = readPhaseState;
exports.writePhaseState = writePhaseState;
/**
 * §125 R3 — runtime phase state (Lisa R1 B4 SOR split).
 *
 * Tracked manifest (`gate-manifest.json`) holds declarative phase definitions ONLY.
 * Runtime current_phase pointer lives here in state dir (`.dual-agent/phase-state.json`).
 *
 * Atomic update: write to temp file, rename.
 */
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const STATE_FILENAME = 'phase-state.json';
function statePath(projectRoot) {
    return (0, node_path_1.join)(projectRoot, '.dual-agent', STATE_FILENAME);
}
function readPhaseState(projectRoot) {
    const p = statePath(projectRoot);
    if (!(0, node_fs_1.existsSync)(p))
        return { current_phase: null };
    try {
        const parsed = JSON.parse((0, node_fs_1.readFileSync)(p, 'utf8'));
        if (parsed && typeof parsed === 'object' && 'current_phase' in parsed) {
            const cp = parsed.current_phase;
            if (cp === null || typeof cp === 'string')
                return { current_phase: cp };
        }
    }
    catch { /* fall through to default */ }
    return { current_phase: null };
}
function writePhaseState(projectRoot, state) {
    const p = statePath(projectRoot);
    (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(p), { recursive: true });
    const tmp = `${p}.tmp.${process.pid}`;
    (0, node_fs_1.writeFileSync)(tmp, JSON.stringify(state, null, 2) + '\n', 'utf8');
    (0, node_fs_1.renameSync)(tmp, p);
}
