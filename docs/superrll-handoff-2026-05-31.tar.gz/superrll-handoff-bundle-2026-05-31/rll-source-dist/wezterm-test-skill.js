"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefaultWezTermRunner = void 0;
exports.assertWezTermAvailable = assertWezTermAvailable;
exports.parseMacro = parseMacro;
exports.runMacro = runMacro;
exports.cmdWeztermTestSkill = cmdWeztermTestSkill;
exports.captureWezTermL1 = captureWezTermL1;
/**
 * §171 wezterm-test-skill MVP — local cli/src module.
 *
 * Provides parseMacro + runMacro + WezTermRunner contract for the
 * `ralph-lisa skill wezterm-test --macro <path>` sub-cmd.
 *
 * Stays inside cli/src (no cli-e2e import per Lisa R1 B2 boundary fix).
 * JSON macro format only (Lisa R1 B3 — js-yaml dev-only; YAML deferred).
 */
const node_child_process_1 = require("node:child_process");
/** Default PATH probe — `which` (POSIX) / `where` (Windows). Returns the resolved path or null. */
function defaultWhich(bin) {
    const cmd = process.platform === 'win32' ? 'where' : 'which';
    const r = (0, node_child_process_1.spawnSync)(cmd, [bin], { encoding: 'utf8' });
    if (r.status === 0) {
        const first = (r.stdout || '').trim().split(/\r?\n/)[0];
        if (first)
            return first;
    }
    return null;
}
/**
 * §187 P3: fail fast with an actionable message when the `wezterm` binary is
 * absent — instead of the cryptic late `DefaultWezTermRunner.spawnPane`
 * `status=null` failure. `whichFn` defaults to a real PATH probe.
 */
function assertWezTermAvailable(whichFn) {
    const probe = whichFn ?? defaultWhich;
    if (!probe('wezterm')) {
        throw new Error('wezterm not found on PATH — the wezterm-test harness needs the WezTerm CLI. ' +
            'Install it: `brew install wezterm` (macOS) or see https://wezterm.org/install/ . ' +
            'Then `ralph-lisa doctor` will confirm it is available.');
    }
}
const KNOWN_STEP_TYPES = new Set(['spawn', 'send', 'wait-for', 'assert-contains', 'assert-not-contains', 'kill']);
/**
 * Parse a macro JSON string. JSON ONLY — YAML EXPLICITLY rejected per
 * Lisa R1 B3 (js-yaml dev-only in cli/package.json). Throws on:
 *   - non-JSON content (incl. YAML — `name: foo` style fails JSON.parse)
 *   - missing `steps` field
 *   - unknown step type
 */
function parseMacro(content, path) {
    const where = path ? ` (path: ${path})` : '';
    let parsed;
    try {
        parsed = JSON.parse(content);
    }
    catch (e) {
        throw new Error(`parseMacro: invalid JSON${where} — ${e.message}. YAML input is not supported (JSON only per §171 MVP scope).`);
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error(`parseMacro: root must be an object${where}`);
    }
    const obj = parsed;
    if (!('steps' in obj) || !Array.isArray(obj.steps)) {
        throw new Error(`parseMacro: missing required \`steps\` array${where}`);
    }
    const name = typeof obj.name === 'string' ? obj.name : 'unnamed';
    const steps = [];
    for (let i = 0; i < obj.steps.length; i++) {
        const raw = obj.steps[i];
        if (!raw || typeof raw !== 'object') {
            throw new Error(`parseMacro: step[${i}] must be an object${where}`);
        }
        const stepType = raw.type;
        if (typeof stepType !== 'string' || !KNOWN_STEP_TYPES.has(stepType)) {
            throw new Error(`parseMacro: unknown step type "${String(stepType)}" at step[${i}]${where}. Valid: ${[...KNOWN_STEP_TYPES].join(', ')}`);
        }
        steps.push(raw);
    }
    return { name, steps };
}
/**
 * Run a parsed macro against a WezTermRunner. Cleans up every spawned pane
 * via try/finally regardless of step outcome (Lisa R3 cleanup-invariant pin).
 */
function runMacro(macro, runner, opts = {}) {
    const stepResults = [];
    // §190-followup — each spawned pane's RAW text, captured before teardown.
    const rawParts = [];
    // name → pane-id (from spawn steps)
    const panes = new Map();
    const spawnedPaneIds = [];
    let failedStep = undefined;
    let runError;
    try {
        for (let i = 0; i < macro.steps.length; i++) {
            const step = macro.steps[i];
            const startedAt = Date.now();
            try {
                if (step.type === 'spawn') {
                    const paneId = runner.spawnPane({ cwd: step.cwd });
                    panes.set(step.name, paneId);
                    spawnedPaneIds.push(paneId);
                    stepResults.push({ idx: i, type: step.type, pass: true, elapsed_ms: Date.now() - startedAt });
                }
                else if (step.type === 'send') {
                    const paneId = panes.get(step.target);
                    if (paneId === undefined) {
                        const reason = `send: unknown target "${step.target}" (spawn it first)`;
                        stepResults.push({ idx: i, type: step.type, pass: false, reason, elapsed_ms: Date.now() - startedAt });
                        failedStep = { idx: i, type: step.type, reason };
                        break;
                    }
                    runner.sendText(paneId, step.text);
                    stepResults.push({ idx: i, type: step.type, pass: true, elapsed_ms: Date.now() - startedAt });
                }
                else if (step.type === 'wait-for') {
                    const paneId = panes.get(step.target);
                    if (paneId === undefined) {
                        const reason = `wait-for: unknown target "${step.target}"`;
                        stepResults.push({ idx: i, type: step.type, pass: false, reason, elapsed_ms: Date.now() - startedAt });
                        failedStep = { idx: i, type: step.type, reason };
                        break;
                    }
                    const timeoutMs = step.timeout_ms ?? 3000;
                    const pollMs = 50;
                    let found = false;
                    while (Date.now() - startedAt < timeoutMs) {
                        const text = runner.getText(paneId);
                        if (text.includes(step.text)) {
                            found = true;
                            break;
                        }
                        // Synchronous-ish sleep — busy-loop but bounded by timeoutMs.
                        // Use deasync-free approach: spawnSync small sleep would add 50ms × N.
                        // Use a tight loop with a date check; tests use mock backend where getText
                        // either returns target immediately or never — short poll keeps CPU bounded.
                        const sleepEnd = Date.now() + pollMs;
                        while (Date.now() < sleepEnd) { /* busy-wait */ }
                    }
                    if (found) {
                        stepResults.push({ idx: i, type: step.type, pass: true, elapsed_ms: Date.now() - startedAt });
                    }
                    else {
                        const reason = `wait-for: timed out after ${timeoutMs}ms waiting for "${step.text}" on "${step.target}"`;
                        stepResults.push({ idx: i, type: step.type, pass: false, reason, elapsed_ms: Date.now() - startedAt });
                        failedStep = { idx: i, type: step.type, reason };
                        break;
                    }
                }
                else if (step.type === 'assert-contains') {
                    const paneId = panes.get(step.target);
                    if (paneId === undefined) {
                        const reason = `assert-contains: unknown target "${step.target}"`;
                        stepResults.push({ idx: i, type: step.type, pass: false, reason, elapsed_ms: Date.now() - startedAt });
                        failedStep = { idx: i, type: step.type, reason };
                        break;
                    }
                    const text = runner.getText(paneId);
                    if (text.includes(step.text)) {
                        stepResults.push({ idx: i, type: step.type, pass: true, elapsed_ms: Date.now() - startedAt });
                    }
                    else {
                        const reason = `assert-contains: expected "${step.text}" in pane "${step.target}" — actual text does not contain it`;
                        stepResults.push({ idx: i, type: step.type, pass: false, reason, elapsed_ms: Date.now() - startedAt });
                        failedStep = { idx: i, type: step.type, reason };
                        break;
                    }
                }
                else if (step.type === 'assert-not-contains') {
                    // §195 — the inverted predicate of `assert-contains`: PASS when the
                    // forbidden string is ABSENT from the pane; FAIL when it appears.
                    const paneId = panes.get(step.target);
                    if (paneId === undefined) {
                        const reason = `assert-not-contains: unknown target "${step.target}"`;
                        stepResults.push({ idx: i, type: step.type, pass: false, reason, elapsed_ms: Date.now() - startedAt });
                        failedStep = { idx: i, type: step.type, reason };
                        break;
                    }
                    const text = runner.getText(paneId);
                    if (!text.includes(step.text)) {
                        stepResults.push({ idx: i, type: step.type, pass: true, elapsed_ms: Date.now() - startedAt });
                    }
                    else {
                        const reason = `assert-not-contains: forbidden "${step.text}" found in pane "${step.target}"`;
                        stepResults.push({ idx: i, type: step.type, pass: false, reason, elapsed_ms: Date.now() - startedAt });
                        failedStep = { idx: i, type: step.type, reason };
                        break;
                    }
                }
                else if (step.type === 'kill') {
                    const paneId = panes.get(step.target);
                    if (paneId !== undefined) {
                        try {
                            runner.killPane(paneId);
                        }
                        catch { /* tolerate */ }
                        // Remove from spawnedPaneIds so cleanup doesn't double-kill
                        const idx = spawnedPaneIds.indexOf(paneId);
                        if (idx >= 0)
                            spawnedPaneIds.splice(idx, 1);
                        panes.delete(step.target);
                    }
                    stepResults.push({ idx: i, type: step.type, pass: true, elapsed_ms: Date.now() - startedAt });
                }
            }
            catch (e) {
                runError = e.message;
                stepResults.push({ idx: i, type: step.type, pass: false, reason: runError, elapsed_ms: Date.now() - startedAt });
                failedStep = { idx: i, type: step.type, reason: runError };
                break;
            }
        }
    }
    finally {
        // §190-followup — capture each still-live pane's RAW text BEFORE the kill
        // (capture-then-kill; runs on every path incl. failures).
        for (const paneId of spawnedPaneIds) {
            try {
                rawParts.push(`=== pane ${paneId} ===\n${runner.getText(paneId)}`);
            }
            catch { /* tolerate */ }
        }
        // §171 cleanup invariant (Lisa-aligned): kill every spawned pane regardless of outcome.
        if (!opts.keepPane) {
            for (const paneId of spawnedPaneIds) {
                try {
                    runner.killPane(paneId);
                }
                catch { /* tolerate */ }
            }
        }
    }
    const ok = !failedStep && !runError;
    const out = { ok, steps: stepResults };
    if (failedStep)
        out.failedStep = failedStep;
    if (runError)
        out.error = runError;
    if (rawParts.length > 0)
        out.rawL1 = rawParts.join('\n\n');
    return out;
}
/**
 * Default WezTermRunner: shells `wezterm cli --prefer-mux spawn --new-window`
 * + send-text / get-text / kill-pane. Local thin wrapper (no cli-e2e import).
 */
class DefaultWezTermRunner {
    whichFn;
    /** §190-followup — injectable spawn seam (tests record argv; prod uses nodeSpawnSync). */
    spawn;
    /**
     * §187 P3: optional injected which-probe for the wezterm preflight.
     * §190-followup: optional `spawnFn` seam. Accepts BOTH the legacy positional
     * `whichFn` (a function) AND the options object — back-compat for §187 C8.
     */
    constructor(arg) {
        const opts = typeof arg === 'function' ? { whichFn: arg } : (arg ?? {});
        this.whichFn = opts.whichFn;
        this.spawn = opts.spawnFn ?? node_child_process_1.spawnSync;
    }
    spawnPane(opts) {
        // §187 P3: fail fast with an actionable message when wezterm is absent,
        // before the cryptic late nodeSpawnSync `status=null` failure.
        assertWezTermAvailable(this.whichFn);
        const args = ['cli', '--prefer-mux', 'spawn', '--new-window'];
        if (opts.cwd) {
            args.push('--cwd', opts.cwd);
        }
        const r = this.spawn('wezterm', args, { encoding: 'utf8' });
        if (r.status !== 0) {
            throw new Error(`DefaultWezTermRunner.spawnPane: wezterm cli spawn failed (status=${r.status}): ${r.stderr || '(no stderr)'}`);
        }
        const paneId = parseInt((r.stdout || '').trim(), 10);
        if (!Number.isInteger(paneId)) {
            throw new Error(`DefaultWezTermRunner.spawnPane: non-numeric pane id from wezterm cli: "${r.stdout}"`);
        }
        return paneId;
    }
    sendText(paneId, text) {
        // Lisa R6 narrow: thread --prefer-mux to ALL cli calls so subsequent ops target
        // the same mux server as spawn. Without it, ops route to the default (GUI) target
        // and pane-id lookup fails with "no such pane N".
        const r = this.spawn('wezterm', ['cli', '--prefer-mux', 'send-text', '--pane-id', String(paneId), '--no-paste'], {
            encoding: 'utf8',
            input: text,
        });
        if (r.status !== 0) {
            throw new Error(`DefaultWezTermRunner.sendText: failed (status=${r.status}): ${r.stderr || '(no stderr)'}`);
        }
    }
    getText(paneId) {
        // §190-followup — `--start-line -1000` makes get-text scrollback-inclusive.
        const r = this.spawn('wezterm', ['cli', '--prefer-mux', 'get-text', '--pane-id', String(paneId), '--start-line', '-1000'], { encoding: 'utf8' });
        if (r.status !== 0) {
            throw new Error(`DefaultWezTermRunner.getText: failed (status=${r.status}): ${r.stderr || '(no stderr)'}`);
        }
        return r.stdout || '';
    }
    killPane(paneId) {
        const r = this.spawn('wezterm', ['cli', '--prefer-mux', 'kill-pane', '--pane-id', String(paneId)], { encoding: 'utf8' });
        if (r.status !== 0) {
            // Tolerate — pane may already be gone (idempotent cleanup invariant).
        }
    }
}
exports.DefaultWezTermRunner = DefaultWezTermRunner;
/**
 * CLI entrypoint: `ralph-lisa skill wezterm-test --macro <path> [--json] [--keep-pane]`
 * Returns exit code (0 ok / 1 fail / 2 usage error).
 */
function cmdWeztermTestSkill(args, deps = {}) {
    let macroPath;
    let outputJson = false;
    let keepPane = false;
    for (let i = 0; i < args.length; i++) {
        const a = args[i];
        if (a === '--macro') {
            macroPath = args[++i];
        }
        else if (a === '--json') {
            outputJson = true;
        }
        else if (a === '--keep-pane') {
            keepPane = true;
        }
        else if (a === '--help' || a === '-h') {
            console.log('Usage: ralph-lisa skill wezterm-test --macro <path> [--json] [--keep-pane]');
            console.log('  Run a wezterm-test-skill macro (JSON format) and report per-step pass/fail.');
            return 0;
        }
    }
    if (!macroPath) {
        console.error('skill wezterm-test: --macro <path> required. Try --help.');
        return 2;
    }
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const fs = require('node:fs');
    let content;
    try {
        content = fs.readFileSync(macroPath, 'utf8');
    }
    catch (e) {
        console.error(`skill wezterm-test: macro file not readable at "${macroPath}": ${e.message}`);
        return 1;
    }
    let macro;
    try {
        macro = parseMacro(content, macroPath);
    }
    catch (e) {
        console.error(`skill wezterm-test: parseMacro error: ${e.message}`);
        return 1;
    }
    const runner = deps.runner ?? new DefaultWezTermRunner();
    const result = runMacro(macro, runner, { keepPane });
    // §190 P2 — capture the macro run (steps + pane snippets + failure reasons)
    // into L1-debug for post-mortem; resolves the run-id from the gate handoff.
    // §190-followup — write the RAW pane text when captured; else the summary.
    captureWezTermL1({ paneText: result.rawL1 ?? JSON.stringify(result, null, 2) });
    if (outputJson) {
        console.log(JSON.stringify(result, null, 2));
    }
    else {
        console.log(`Macro: ${macro.name} — ${result.ok ? 'OK' : 'FAIL'}`);
        for (const s of result.steps) {
            console.log(`  [${s.idx}] ${s.type} — ${s.pass ? 'pass' : 'fail'}${s.reason ? ': ' + s.reason : ''}`);
        }
        if (result.failedStep) {
            console.error(`Failed at step ${result.failedStep.idx} (${result.failedStep.type}): ${result.failedStep.reason}`);
        }
    }
    return result.ok ? 0 : 1;
}
/**
 * §190 P2 — capture the wezterm macro RUN RESULT (steps + per-step pane
 * snippets + failure reasons) into L1-debug. Resolves the run-id/root from the
 * RL_TEST_LOG_* handoff (or self-generates). Best-effort.
 *
 * NOTE: this is run-result-level capture. Capturing the driven pane's FULL raw
 * scrollback needs DefaultWezTermRunner instrumentation → §190-followup
 * `harness-runner-raw-capture`.
 */
function captureWezTermL1(opts) {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const tl = require('./test-logs.js');
        const root = opts.logRoot ?? process.env.RL_TEST_LOG_ROOT;
        if (!root)
            return;
        const runId = opts.runId ?? tl.resolveRunId(process.env);
        tl.captureL1({ root, runId, label: 'wezterm-pane.txt', content: opts.paneText });
    }
    catch { /* never fatal */ }
}
