"use strict";
/**
 * Policy layer for Ralph-Lisa Loop.
 * Checks submissions for required content (warn or block mode).
 *
 * Modes (RL_POLICY_MODE env):
 *   block - print warnings AND exit(1) if violations found (DEFAULT since §133 2026-05-16)
 *   warn  - print warnings, don't block (explicit dev mode escape)
 *   off   - no checks
 *
 * §133 (2026-05-16): default flipped from warn to block per
 * docs/gate-bypass-diagnostic-2026-05-16.md G4. Invalid env value
 * falls back to 'block' (NOT silently warn).
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPolicyMode = getPolicyMode;
exports.checkRalph = checkRalph;
exports.checkLisa = checkLisa;
exports.checkNeedsWorkResponse = checkNeedsWorkResponse;
exports.runPolicyCheck = runPolicyCheck;
exports.parseTierEvidence = parseTierEvidence;
exports.validateTierCoverage = validateTierCoverage;
exports.checkClarifyGate = checkClarifyGate;
exports.checkLisaNarrowScopeExpansion = checkLisaNarrowScopeExpansion;
exports.checkScopeExpansionPending = checkScopeExpansionPending;
exports.checkDocOracleSpecRequired = checkDocOracleSpecRequired;
/**
 * §133 (2026-05-16): default mode flipped from 'warn' to 'block'.
 * Dev escape: `RL_POLICY_MODE=warn ralph-lisa ...` for interactive dev mode.
 * Invalid env value → falls back to 'block' (not silently 'warn').
 */
function getPolicyMode() {
    const mode = process.env.RL_POLICY_MODE || "block";
    if (mode === "warn" || mode === "block" || mode === "off")
        return mode;
    return "block";
}
function checkRalph(tag, content, ctx) {
    const violations = [];
    // §149 P2-ralph-attest: [CODE]/[FIX] body must include Test-Process / Test-Cases / Test-Results
    // Default-block per CF32 pattern; opt-out via RL_RALPH_ATTEST_OFF=1.
    if ((tag === "CODE" || tag === "FIX") && process.env.RL_RALPH_ATTEST_OFF !== "1") {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const rap = require("./ralph-attest-parser.js");
            const attest = rap.parseRalphAttest(content);
            if (!attest || !content.match(/^Test-Process(?:-File)?:/m)) {
                violations.push({ rule: "ralph-test-process-missing", message: `[${tag}] §149: must include Test-Process: <inline|file-path|git-diff>` });
            }
            if (!attest || !content.match(/^Test-Cases:/m)) {
                violations.push({ rule: "ralph-test-cases-missing", message: `[${tag}] §149: must include Test-Cases: C1, C2, ...` });
            }
            if (!attest || !content.match(/^Test-Results(?:-File)?:/m)) {
                violations.push({ rule: "ralph-test-results-missing", message: `[${tag}] §149: must include Test-Results: counts|file-path|log-cite` });
            }
            // Lisa R7 B1: actually VERIFY the cites (containment + git-diff safety + log-cite §137 cross-check),
            // not just presence. Without verify-call, /etc/passwd + --upload-pack=evil were accepted.
            if (attest && ctx?.stateRoot && ctx?.repoRoot) {
                const verifyR = rap.verifyRalphAttest(attest, { stateRoot: ctx.stateRoot, repoRoot: ctx.repoRoot });
                for (const u of (verifyR.unverified ?? [])) {
                    violations.push({
                        rule: `ralph-attest-${u.kind}-unverified`,
                        message: `[${tag}] §149: ${u.reason}`,
                    });
                }
            }
        }
        catch { /* never fatal */ }
    }
    // §149 P3-counter-attest: [CONSENSUS] must read latest Lisa PASS and verify quality
    if (tag === "CONSENSUS" && process.env.RL_RALPH_ATTEST_OFF !== "1" && ctx?.stateRoot && ctx?.step) {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const lap = require("./lisa-attest-parser.js");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const fsMod = require("node:fs");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const pathMod = require("node:path");
            const reviewPath = pathMod.join(ctx.stateRoot, "review.md");
            if (fsMod.existsSync(reviewPath)) {
                const reviewContent = fsMod.readFileSync(reviewPath, "utf8");
                const lisaPassBody = lap.extractLatestLisaPass(reviewContent, ctx.step);
                if (lisaPassBody) {
                    const lisaAttest = lap.parseLisaAttest(lisaPassBody);
                    if (lisaAttest) {
                        const r = lap.verifyLisaAttest(lisaAttest, { stateRoot: ctx.stateRoot, step: ctx.step, repoRoot: ctx.repoRoot });
                        if (!r.quality_score) {
                            violations.push({
                                rule: "ralph-must-challenge-rubber-stamp-pass",
                                message: `[${tag}] §149: latest Lisa PASS quality_score=false (rationale <${process.env.RL_ATTEST_RATIONALE_MIN_CHARS ?? '40'} chars OR no cite). Ralph MUST [CHALLENGE] not [CONSENSUS].`,
                            });
                        }
                    }
                    else {
                        // No attest block at all → also insufficient
                        violations.push({
                            rule: "ralph-must-challenge-rubber-stamp-pass",
                            message: `[${tag}] §149: latest Lisa PASS has NO §149 attest block. Ralph MUST [CHALLENGE].`,
                        });
                    }
                }
            }
        }
        catch { /* never fatal */ }
    }
    // §202 Phase B — first-tag enforcement (Lisa R1 Q4 lock).
    // For a NEW step (no prior non-QUESTION Ralph submission in history.md),
    // the first round-starting tag MUST be one of {PLAN, RESEARCH, CLARIFY}.
    // [QUESTION] allowed but non-round-starting.
    // Opt-out: RL_R1_FIRST_TAG_OFF=1.
    if (process.env.RL_R1_FIRST_TAG_OFF !== "1" &&
        ctx?.stateRoot && ctx?.step) {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const fsMod = require("node:fs");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const pathMod = require("node:path");
            const historyPath = pathMod.join(ctx.stateRoot, "history.md");
            let hasPriorNonQuestion = false;
            if (fsMod.existsSync(historyPath)) {
                const content = fsMod.readFileSync(historyPath, "utf8");
                // Find any non-QUESTION Ralph submission on the current step
                // (matches `## [Ralph] [TAG] Round N | Step: <step>` headers).
                const headerRe = new RegExp(`^##\\s+\\[Ralph\\]\\s+\\[([A-Z_]+)\\]\\s+Round\\s+\\d+\\s+\\|\\s+Step:\\s+${ctx.step.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gm");
                let m;
                while ((m = headerRe.exec(content)) !== null) {
                    if (m[1] !== "QUESTION") {
                        hasPriorNonQuestion = true;
                        break;
                    }
                }
            }
            if (!hasPriorNonQuestion) {
                // NEW step — first-tag allowlist applies.
                const FIRST_TAG_ALLOWLIST = new Set(["PLAN", "RESEARCH", "CLARIFY", "QUESTION"]);
                if (!FIRST_TAG_ALLOWLIST.has(tag)) {
                    violations.push({
                        rule: "r1-first-tag-not-allowed",
                        message: `[${tag}] §202: first Ralph submission on step "${ctx.step}" must be [PLAN]/[RESEARCH]/[CLARIFY]; [QUESTION] allowed but non-round-starting. Opt-out: RL_R1_FIRST_TAG_OFF=1.`,
                    });
                }
            }
        }
        catch { /* never fatal */ }
    }
    // §202 Phase B — shape-change-pending-not-acked block at [CODE]/[FIX]
    // (Lisa R1 narrow: checker stays pure, no writes here; the pending file is
    // written in cmdSubmitLisa). Mirrors §128 scope-expansion-pending-not-acked
    // at `cli/src/policy.ts:1138-1167`.
    if ((tag === "CODE" || tag === "FIX") &&
        ctx?.stateRoot && ctx?.step) {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const fsMod = require("node:fs");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const pathMod = require("node:path");
            const pendingPath = pathMod.join(ctx.stateRoot, `non-tdd-shape-change-pending-${ctx.step}.json`);
            if (fsMod.existsSync(pendingPath)) {
                violations.push({
                    rule: "shape-change-pending-not-acked",
                    message: `[${tag}] §202: shape-change pending — Lisa requested a non-TDD shape change (see ${pendingPath}). Run \`ralph-lisa ack-shape-change --slice ${ctx.step} --reason "<context>"\` to ack, OR have Lisa retract.`,
                });
            }
        }
        catch { /* never fatal */ }
    }
    // §201 Phase A — Ralph mutual-gate at [CODE]/[FIX] (warn-severity).
    // §200 design Fix #3 + Lisa R1 Q2: extend §149 P3-counter-attest from
    // CONSENSUS-only (block) to also fire on [CODE]/[FIX] with warn-severity
    // (printed via console.log per §188 B4 channel-split; NOT pushed to
    // violations[] — does not block submission). [CHALLENGE] never fires
    // (escape route). [CONSENSUS] continues to block via existing rule above.
    // Opt-out: RL_RALPH_MUTUAL_GATE_OFF=1 (audit-named per Lisa R1 Q5;
    // orthogonal to RL_RALPH_ATTEST_OFF).
    if ((tag === "CODE" || tag === "FIX") &&
        process.env.RL_RALPH_MUTUAL_GATE_OFF !== "1" &&
        ctx?.stateRoot && ctx?.step) {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const lap = require("./lisa-attest-parser.js");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const fsMod = require("node:fs");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const pathMod = require("node:path");
            const reviewPath = pathMod.join(ctx.stateRoot, "review.md");
            if (fsMod.existsSync(reviewPath)) {
                const reviewContent = fsMod.readFileSync(reviewPath, "utf8");
                const lisaPassBody = lap.extractLatestLisaPass(reviewContent, ctx.step);
                if (lisaPassBody) {
                    const lisaAttest = lap.parseLisaAttest(lisaPassBody);
                    if (!lisaAttest) {
                        // No attest block in latest Lisa PASS → process gap.
                        // eslint-disable-next-line no-console
                        console.log(`[warn] ralph-must-cite-process-gap: [${tag}] §201: latest Lisa PASS has NO §149 attest block. Ralph should [CHALLENGE] to demand Lisa cite her process (Reviewed-test-files / Reviewed-test-log / Pass-Rationale).`);
                    }
                    else {
                        const r = lap.verifyLisaAttest(lisaAttest, {
                            stateRoot: ctx.stateRoot,
                            step: ctx.step,
                            repoRoot: ctx.repoRoot,
                        });
                        if (!r.quality_score) {
                            // eslint-disable-next-line no-console
                            console.log(`[warn] ralph-must-cite-process-gap: [${tag}] §201: latest Lisa PASS quality_score=false (rationale <${process.env.RL_ATTEST_RATIONALE_MIN_CHARS ?? '40'} chars OR no cite). Ralph should [CHALLENGE] to demand substantive review process.`);
                        }
                    }
                }
            }
        }
        catch { /* never fatal — warn-severity only */ }
    }
    // [PLAN] must include test plan (step42: mandatory test execution)
    if (tag === "PLAN") {
        if (!content.match(/测试计划|[Tt]est [Pp]lan|测试命令|[Tt]est [Cc]ommand/)) {
            violations.push({
                rule: "plan-test-plan",
                message: `[PLAN] submission missing test plan (test command + coverage scope).`,
            });
        }
    }
    // [CODE] or [FIX] must include Test Results and file:line references
    if (tag === "CODE" || tag === "FIX") {
        if (!content.includes("Test Results") &&
            !content.includes("test results") &&
            !content.includes("Test results")) {
            violations.push({
                rule: "test-results",
                message: `[${tag}] submission missing "Test Results" section.`,
            });
        }
        // step42: Test Results must include concrete execution evidence (exit code or pass/fail count)
        // Exception: explicit "Skipped:" line inside the Test Results section only
        // Section is bounded: from "Test Results" heading to next heading (## or blank-line-then-heading) or EOF
        const testResultsMatch = content.match(/[Tt]est [Rr]esults[^\n]*\n([\s\S]*?)(?=\n##\s|\n\n[A-Z]|\n\n\*\*[A-Z]|$)/);
        if (testResultsMatch) {
            const testResultsBody = testResultsMatch[1];
            const hasSkipLine = /^[\s\-*]*[Ss]kip(ped)?\s*:.*\S/m.test(testResultsBody);
            const hasExecutionEvidence = /[Ee]xit code|退出码|\d+\/\d+\s*(pass|通过|passed)|(\d+)\s*tests?\s*pass/i.test(testResultsBody);
            if (!hasSkipLine && !hasExecutionEvidence) {
                violations.push({
                    rule: "test-results-detail",
                    message: `[${tag}] Test Results must include exit code or pass/fail count (e.g., "Exit code: 0" or "42/42 passed"), or explicit "Skipped:" with justification.`,
                });
            }
        }
        if (!/\w+\.\w+:\d+/.test(content)) {
            violations.push({
                rule: "file-line-ref",
                message: `[${tag}] submission must include at least one file:line reference (e.g., commands.ts:42).`,
            });
        }
        // §137 — verify Test Results claims against test-execution-log.jsonl
        // Default ON per Lisa R7 B11 lock (PLAN.md fail-closed contract).
        // Explicit opt-out via RL_TEST_RESULTS_VERIFY_OFF=1 (audit-named).
        try {
            const verifyOff = process.env.RL_TEST_RESULTS_VERIFY_OFF === "1";
            if (verifyOff)
                throw new Error("opt-out");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const verifier = require("./test-results-claim-verifier.js");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const stateMod = require("./state.js");
            const stateRoot = stateMod.stateDir();
            const claims = verifier.parseTestResultClaims(content);
            if (claims.length > 0) {
                const result = verifier.verifyTestResultsClaims(claims, { stateRoot, maxAgeMin: 10 });
                if (result.unverified && result.unverified.length > 0) {
                    const unverifiedSummary = result.unverified.map((c) => `\`${c.cmd}\``).join(", ");
                    violations.push({
                        rule: "test-results-unverified",
                        message: `[${tag}] Test Results contains unverified claims (no matching execution log entry in last 10min): ${unverifiedSummary}. Run test before submitting or cite Skipped: with justification.`,
                    });
                }
            }
        }
        catch { /* never fatal */ }
        // §151 — visual-evidence-missing for UI/web slice [CODE]/[FIX]
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const ve = require("./visual-evidence-tier.js");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const stateMod = require("./state.js");
            const stateRoot = stateMod.stateDir();
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const pathMod = require("node:path");
            // §188: ctx.isUiSlice override — the stateDir()-derived detection is not
            // test-controllable inside the RLL tmux (resolveStateDir prefers the tmux
            // state dir). When the caller supplies isUiSlice, use it verbatim.
            const isUi = ctx?.isUiSlice !== undefined
                ? ctx.isUiSlice
                : ve.detectUiSlice(ve.readPlanForSliceDetection(stateRoot));
            const result = ve.checkVisualEvidence({
                tag,
                body: content,
                isUiSlice: isUi,
                env: process.env,
                repoRoot: pathMod.dirname(stateRoot),
                stateRoot,
            });
            // §188 B4: honor per-violation severity. A 'warn'-severity violation
            // (e.g. the RL_VISUAL_EVIDENCE_OFF=1 downgrade) is surfaced as a warning,
            // NOT pushed into the blocking violations[]. Anything not explicitly
            // 'warn' blocks (fail-closed).
            for (const v of result.violations) {
                if (v.severity === "warn") {
                    // eslint-disable-next-line no-console
                    console.log(`[warn] ${v.message}`);
                }
                else {
                    violations.push({ rule: v.rule, message: v.message });
                }
            }
        }
        catch { /* never fatal */ }
        // §152 project-type-tiers — warn-only baseline-mismatch hint (printed to
        // stdout; NOT added to violations[] since the policy framework lacks a
        // per-violation severity field; project-type-tier mismatch is informational
        // and must never block submit).
        if (process.env.RL_PROJECT_TYPE_TIERS_OFF !== "1") {
            try {
                // eslint-disable-next-line @typescript-eslint/no-require-imports
                const ptt = require("./project-type-tiers.js");
                // eslint-disable-next-line @typescript-eslint/no-require-imports
                const stateMod = require("./state.js");
                // eslint-disable-next-line @typescript-eslint/no-require-imports
                const pathMod = require("node:path");
                // eslint-disable-next-line @typescript-eslint/no-require-imports
                const fsMod = require("node:fs");
                const stateRoot = stateMod.stateDir();
                const repoRoot = pathMod.dirname(stateRoot);
                const manifestPath = pathMod.join(repoRoot, "gate-manifest.json");
                if (fsMod.existsSync(manifestPath)) {
                    const manifest = JSON.parse(fsMod.readFileSync(manifestPath, "utf8"));
                    const v = ptt.validateBaselineForType(manifest);
                    if (!v.ok && v.warnings.length > 0) {
                        // eslint-disable-next-line no-console
                        console.log(`[warn] project-type-tier-mismatch (§152): ${v.warnings.join("; ")}. Update gate-manifest.json default_baseline or set RL_PROJECT_TYPE_TIERS_OFF=1.`);
                    }
                }
            }
            catch { /* never fatal */ }
        }
        // New tests count check (Proposal §3.6)
        // Warn if "New tests: 0" without valid justification
        const lc = content.toLowerCase();
        const hasNewTests = /new tests?:\s*[1-9]/i.test(content);
        const hasZeroTests = /new tests?:\s*0/i.test(content);
        if (hasZeroTests && !hasNewTests) {
            // Check for valid justification keywords
            const hasJustification = /\b(ui.only|layout.only|config.only|no.testable.logic|template.only|documentation)\b/i.test(content);
            if (!hasJustification) {
                violations.push({
                    rule: "new-tests-required",
                    message: `[${tag}] reports 0 new tests without valid justification. Add unit tests or explain why (e.g., "config-only change").`,
                });
            }
        }
    }
    // [RESEARCH] must have substance
    if (tag === "RESEARCH") {
        const fieldGroups = [
            ["reference", "reference implementation"],
            ["key type", "key types"],
            ["data format", "data structure"],
            ["verification", "verified"],
        ];
        const lc = content.toLowerCase();
        const matchedFields = fieldGroups.filter((variants) => variants.some((v) => lc.includes(v.toLowerCase()))).length;
        const hasSubstantialContent = content.split("\n").length > 3;
        if (matchedFields < 2 && !hasSubstantialContent) {
            violations.push({
                rule: "research-content",
                message: "[RESEARCH] submission needs at least 2 fields (reference/key types/data structure/verification) or equivalent summary with evidence.",
            });
        }
        // RESEARCH verification markers (Proposal §3.9)
        // Checks for at least one global Verified:/Evidence: marker per submission.
        // Per-claim enforcement is not mechanically feasible — Lisa reviews claim-level rigor.
        const hasVerifiedMarker = /\bverified\s*:/i.test(content);
        const hasEvidenceMarker = /\bevidence\s*:/i.test(content);
        if (!hasVerifiedMarker && !hasEvidenceMarker) {
            violations.push({
                rule: "research-verification",
                message: '[RESEARCH] submission should include at least one "Verified:" or "Evidence:" marker to support factual claims.',
            });
        }
    }
    // §194 — tier-assertion-strength: every [CODE]/[FIX] is linted against the
    // §193 contract for the active slice only (never retroactive on historical
    // PLAN rows). `RL_TIER_ASSERTION_LINT_OFF=1` downgrades all block → warn.
    if (tag === "CODE" || tag === "FIX") {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const lint = require("./tier-assertion-lint.js");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const tac = require("./tier-assertion-contract.js");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const state = require("./state.js");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const fs = require("node:fs");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const path = require("node:path");
            const cwd = process.cwd();
            const planPath = path.join(cwd, ".rll", "PLAN.md");
            if (fs.existsSync(planPath)) {
                const planMd = fs.readFileSync(planPath, "utf8");
                const stateRoot = state.stateDir();
                const stepPath = path.join(stateRoot, "step.txt");
                const activeStep = fs.existsSync(stepPath) ? fs.readFileSync(stepPath, "utf8").trim() : null;
                const contract = tac.loadTierAssertionContract();
                const result = lint.lintTierAssertions({
                    planMd,
                    projectRoot: cwd,
                    contract,
                    scopeSlice: activeStep ?? "all",
                });
                const optOff = process.env.RL_TIER_ASSERTION_LINT_OFF === "1";
                for (const v of result.violations) {
                    const severity = optOff ? "warn" : v.severity;
                    const msg = `[${tag}] §194: tier "${v.tier}" in ${v.slice}/${v.id} is missing qualifying kind(s) [${v.missing_kinds.join(", ")}]${v.skipReason ? ` (skip: ${v.skipReason})` : ""}`;
                    if (severity === "warn") {
                        // §188 B4 pattern — warn-severity violations are surfaced as warnings,
                        // NOT pushed into the blocking `violations[]` (e.g. unit/smoke/functional
                        // tier violations + the RL_TIER_ASSERTION_LINT_OFF=1 global downgrade).
                        // eslint-disable-next-line no-console
                        console.log(`[warn] tier-assertion-strength: ${msg}`);
                    }
                    else {
                        violations.push({ rule: "tier-assertion-strength", severity, message: msg });
                    }
                }
            }
        }
        catch { /* never fatal — §194 lint failure must not break the loop */ }
    }
    return violations;
}
function checkLisa(tag, content, ctx) {
    const violations = [];
    // §201 Phase A — Lisa submit-time cross-check (§200 design Fix #2).
    // Wires verifyLisaAttest into checkLisa so Lisa's own submission is
    // cross-checked at submit-time (today only Ralph counter-attest path at
    // CONSENSUS uses verifyLisaAttest).
    // Opt-out: RL_LISA_ATTEST_CROSS_CHECK_OFF=1 (audit-named per Lisa R1 Q5).
    if ((tag === "PASS" || tag === "NEEDS_WORK" || tag === "CONSENSUS") &&
        ctx?.stateRoot && ctx?.step &&
        process.env.RL_LISA_ATTEST_CROSS_CHECK_OFF !== "1") {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const lap = require("./lisa-attest-parser.js");
            const attest = lap.parseLisaAttest(content);
            if (attest) {
                const r = lap.verifyLisaAttest(attest, {
                    stateRoot: ctx.stateRoot,
                    step: ctx.step,
                    repoRoot: ctx.repoRoot,
                });
                if (Array.isArray(r.unverified) && r.unverified.length > 0) {
                    for (const u of r.unverified) {
                        violations.push({
                            rule: "lisa-attest-cross-check",
                            message: `[${tag}] §201: ${u.kind} unverified — ${u.reason}`,
                        });
                    }
                }
            }
        }
        catch { /* never fatal */ }
    }
    // §149 P1-lisa-attest: [PASS]/[CONSENSUS]/[NEEDS_WORK] must include full attest block:
    // Reviewed-PLAN-rows + Reviewed-test-files + Reviewed-test-log + Pass/NeedsWork-Rationale.
    // Default-block; opt-out RL_LISA_ATTEST_OFF=1.
    if ((tag === "PASS" || tag === "CONSENSUS" || tag === "NEEDS_WORK") && process.env.RL_LISA_ATTEST_OFF !== "1") {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const lap = require("./lisa-attest-parser.js");
            const attest = lap.parseLisaAttest(content);
            // Lisa R7 B2: enforce Reviewed-* attest block presence (not just rationale)
            const hasAttestBlock = !!attest && !!(content.match(/^Reviewed-PLAN-rows:/m) || content.match(/^Reviewed-test-files:/m) || content.match(/^Reviewed-test-log:/m));
            if (!attest || !hasAttestBlock) {
                violations.push({
                    rule: "lisa-attest-missing",
                    message: `[${tag}] §149: must include attest block (Reviewed-PLAN-rows / Reviewed-test-files / Reviewed-test-log)`,
                });
            }
            else {
                // Incomplete: at least 1 of 3 Reviewed-* fields missing
                const missingFields = [];
                if (!content.match(/^Reviewed-PLAN-rows:/m))
                    missingFields.push("Reviewed-PLAN-rows");
                if (!content.match(/^Reviewed-test-files:/m))
                    missingFields.push("Reviewed-test-files");
                if (!content.match(/^Reviewed-test-log:/m))
                    missingFields.push("Reviewed-test-log");
                if (missingFields.length > 0) {
                    violations.push({
                        rule: "lisa-attest-incomplete",
                        message: `[${tag}] §149: attest block missing field(s): ${missingFields.join(", ")}`,
                    });
                }
            }
            const expectedField = (tag === "NEEDS_WORK") ? "NeedsWork-Rationale" : "Pass-Rationale";
            const rationale = (tag === "NEEDS_WORK") ? attest?.needs_work_rationale : attest?.pass_rationale;
            if (!rationale) {
                violations.push({
                    rule: "lisa-rationale-missing",
                    message: `[${tag}] §149: must include ${expectedField}: <reasoning text + file:line cite>`,
                });
            }
            else {
                const minChars = Number(process.env.RL_ATTEST_RATIONALE_MIN_CHARS ?? "40");
                if (rationale.text.length < minChars) {
                    violations.push({
                        rule: "lisa-rationale-insufficient",
                        message: `[${tag}] §149: ${expectedField} text length ${rationale.text.length} < ${minChars} min chars`,
                    });
                }
                else if (rationale.file_line_cites.length === 0 && rationale.artifact_cites.length === 0) {
                    violations.push({
                        rule: "lisa-rationale-insufficient",
                        message: `[${tag}] §149: ${expectedField} must include ≥1 file:line OR trusted-artifact cite`,
                    });
                }
            }
        }
        catch { /* never fatal */ }
    }
    // [PASS] or [NEEDS_WORK] must include at least 1 reason and file:line references
    if (tag === "PASS" || tag === "NEEDS_WORK") {
        // Content after the first line (tag+summary) should have substance
        const lines = content.split("\n");
        const bodyLines = lines.slice(1).filter((l) => l.trim().length > 0);
        if (bodyLines.length === 0) {
            violations.push({
                rule: "reason-required",
                message: `[${tag}] submission must include at least 1 reason.`,
            });
        }
        if (!/\w+\.\w+:\d+/.test(content)) {
            violations.push({
                rule: "file-line-ref",
                message: `[${tag}] submission must include at least one file:line reference (e.g., commands.ts:42).`,
            });
        }
    }
    // §144 — Lisa [PASS]/[CONSENSUS] must cite Verified: <trusted-artifact-path> mtime ≤ 5min
    // Default ON per Lisa R7 B11 lock (PLAN.md fail-closed); explicit opt-out RL_LISA_VERIFIED_OFF=1.
    if ((tag === "PASS" || tag === "CONSENSUS") && process.env.RL_LISA_VERIFIED_OFF !== "1") {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const fsMod = require("node:fs");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const pathMod = require("node:path");
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const stateMod = require("./state.js");
            const stateRoot = stateMod.stateDir();
            const verifiedMatch = content.match(/Verified:\s*([^\s\n]+)/);
            if (!verifiedMatch) {
                violations.push({
                    rule: "lisa-rerun-not-verified",
                    message: `[${tag}] Lisa must cite \`Verified: <trusted-artifact-path>\` (mtime ≤ 5min). Trusted paths: .dual-agent/gate-results.{md,json}, .dual-agent/harness-results/*, .dual-agent/auto-tdd-plan-*.json. §144`,
                });
            }
            else {
                const citedPath = verifiedMatch[1];
                // §144 B13 — normalize/resolve first, then verify containment under current stateRoot.
                const absPath = pathMod.isAbsolute(citedPath)
                    ? pathMod.resolve(citedPath)
                    : pathMod.resolve(pathMod.dirname(stateRoot), citedPath);
                const stateRootAbs = pathMod.resolve(stateRoot);
                const harnessDirAbs = pathMod.resolve(stateRoot, "harness-results");
                const gateResultsMd = pathMod.resolve(stateRoot, "gate-results.md");
                const gateResultsJson = pathMod.resolve(stateRoot, "gate-results.json");
                const isUnderHarness = absPath === harnessDirAbs ||
                    absPath.startsWith(harnessDirAbs + pathMod.sep);
                const isAutoTddPlan = pathMod.dirname(absPath) === stateRootAbs &&
                    /^auto-tdd-plan-[^/]+\.json$/.test(pathMod.basename(absPath));
                const isGateResult = absPath === gateResultsMd || absPath === gateResultsJson;
                // §202 Phase B — extend trusted-path whitelist with the non-tdd
                // agreement artifact (written by Ralph R1 [CONSENSUS] transition).
                const isNonTddAgreement = pathMod.dirname(absPath) === stateRootAbs &&
                    /^non-tdd-agreement-[^/]+\.json$/.test(pathMod.basename(absPath));
                const isTrusted = isUnderHarness || isAutoTddPlan || isGateResult || isNonTddAgreement;
                if (!isTrusted) {
                    violations.push({
                        rule: "lisa-rerun-untrusted-path",
                        message: `[${tag}] Verified: path "${citedPath}" not in trusted allowlist after normalization (resolved=${absPath}). Trusted: .dual-agent/gate-results.{md,json} / .dual-agent/harness-results/** / .dual-agent/auto-tdd-plan-*.json. §144 B13 prevents traversal bypass.`,
                    });
                }
                else {
                    if (!fsMod.existsSync(absPath)) {
                        violations.push({
                            rule: "lisa-rerun-missing-artifact",
                            message: `[${tag}] Verified: path "${citedPath}" does not exist at ${absPath}. §144 lite`,
                        });
                    }
                    else {
                        const mtime = fsMod.statSync(absPath).mtimeMs;
                        const ageMin = (Date.now() - mtime) / 60000;
                        if (ageMin > 5) {
                            violations.push({
                                rule: "lisa-rerun-stale-artifact",
                                message: `[${tag}] Verified: artifact "${citedPath}" mtime ${ageMin.toFixed(1)}min old (>5min). Re-run gate before cite. §144 lite`,
                            });
                        }
                    }
                }
            }
        }
        catch { /* never fatal */ }
    }
    return violations;
}
/**
 * NEEDS_WORK response enforcement (Proposal §3.2).
 * When Lisa's last review was [NEEDS_WORK], Ralph must respond with
 * [FIX], [CHALLENGE], [DISCUSS], or [QUESTION] — not unrelated [CODE]/[RESEARCH]/[PLAN].
 */
const NEEDS_WORK_ALLOWED_TAGS = new Set(["FIX", "CHALLENGE", "DISCUSS", "QUESTION"]);
const NEEDS_WORK_BLOCKED_TAGS = new Set(["CODE", "RESEARCH", "PLAN", "CONSENSUS"]);
function checkNeedsWorkResponse(ralphTag, lastLisaTag) {
    if (lastLisaTag !== "NEEDS_WORK")
        return [];
    if (NEEDS_WORK_ALLOWED_TAGS.has(ralphTag))
        return [];
    if (NEEDS_WORK_BLOCKED_TAGS.has(ralphTag)) {
        return [{
                rule: "needs-work-response",
                message: `[${ralphTag}] submitted after Lisa's [NEEDS_WORK]. You must respond with [FIX], [CHALLENGE], [DISCUSS], or [QUESTION] first. If the task scope changed, run: ralph-lisa scope-update "new scope"`,
            }];
    }
    return [];
}
/**
 * Run policy checks based on mode.
 * Returns { proceed, violations } so callers can format output clearly (IMP-4).
 *
 * §102 (Lisa R8 B1 lock): when `ctx` is provided with `tddMode` etc, additionally
 * invoke `validateAutoTddProtocol` to enforce auto-TDD requirements (Estimate,
 * tests-only marker, test table or escape). Backward-compatible: omitting `ctx`
 * keeps pre-§102 behavior.
 */
function runPolicyCheck(role, tag, content, ctx) {
    const mode = getPolicyMode();
    // §122 task-capability gate — runs FIRST, BEFORE mode-off early return.
    // Per Lisa R3 B19+B20 locks: this is mechanical enforcement that cannot
    // be bypassed by `RL_POLICY_MODE=off`. Only fires at submit-time
    // (ctx.submitTime === true) so pre-§122 unit-test callers without ctx
    // remain backwards compatible.
    //
    // Missing-artifact enforcement is gated on `RL_TASK_CAPABILITY_GATE`:
    //   - `auto` (default): auto-promotes to strict when the project has
    //     opted into §122 (sticky marker `.task-capability-active` present —
    //     `ctx.taskCapabilityActive===true`). Legacy projects without the
    //     marker skip enforcement. Per Lisa R3.2 B21 lock: this satisfies the
    //     mechanical guarantee — once `task new` runs, deleting the artifact
    //     does NOT silently bypass; the sticky marker forces strict mode.
    //   - `block`: missing artifact → fire `task-capability-missing` (strict
    //     mode regardless of marker; useful for tests + super-strict CI)
    //   - `off`: bypass §122 entirely (escape hatch for tests that legitimately
    //     don't exercise §122)
    // Unacked + unsupported-no-consent violations ALWAYS fire when artifact
    // is present (regardless of RL_TASK_CAPABILITY_GATE) — those represent an
    // explicit project that opted into §122 by running `task new`.
    const taskCapMode = (process.env.RL_TASK_CAPABILITY_GATE ?? "auto").toLowerCase();
    // Per B21: auto + active-marker present → effective strict mode.
    const effectivelyStrict = taskCapMode === "block" ||
        (taskCapMode === "auto" && ctx?.taskCapabilityActive === true);
    const taskCapViolations = [];
    if (role === "ralph" &&
        ctx?.submitTime === true &&
        (tag === "CODE" || tag === "CONSENSUS") &&
        taskCapMode !== "off") {
        const cap = ctx.taskCapability;
        if (!cap) {
            // B19/B21: missing/unreadable capability artifact at submit-time.
            // Blocks when effectivelyStrict — either explicit `block` mode OR
            // `auto` mode with the sticky `.task-capability-active` marker (project
            // has previously opted into §122 via `task new`). Default 'auto'
            // without marker = legacy compat (no fire).
            if (effectivelyStrict) {
                const cause = taskCapMode === "block"
                    ? "RL_TASK_CAPABILITY_GATE=block"
                    : "this project has opted into §122 (`.dual-agent/.task-capability-active` marker present); deleting the artifact does NOT bypass enforcement";
                taskCapViolations.push({
                    rule: "task-capability-missing",
                    message: `[${tag}] task-capability-missing: §122 capability artifact .dual-agent/task-harness-capability.json is missing or unreadable (${cause}). Run \`ralph-lisa task new <slug>\` then \`ralph-lisa task capability ack-user --signature "<token>"\` before R2 [CODE] (or [CONSENSUS]).`,
                });
            }
        }
        else if (!cap.acked) {
            taskCapViolations.push({
                rule: "task-capability-unacked",
                message: `[${tag}] task-capability-unacked: §122 acked=false — user must run \`ralph-lisa task capability ack-user --signature "<token>"\` before R2 [CODE] (or [CONSENSUS]).`,
            });
        }
        else {
            const combos = Array.isArray(cap.requested_combos) ? cap.requested_combos : [];
            for (const c of combos) {
                if (!c.supported && c.install_plan === null && c.downgrade_consent === null) {
                    taskCapViolations.push({
                        rule: "unsupported-tier-no-consent",
                        message: `[${tag}] unsupported-tier-no-consent: §122 tier "${c.tier}" is unsupported but has no install_plan or downgrade_consent. Run \`ralph-lisa task capability ack-install --tier ${c.tier}\` OR \`ack-downgrade --tier ${c.tier} --consent "<≥10 char with 'downgrade' + ISO date>"\`.`,
                    });
                }
            }
        }
    }
    const violations = role === "ralph"
        ? checkRalph(tag, content, ctx ? { stateRoot: ctx.stateDir, step: ctx.step, repoRoot: ctx.stateDir ? require("node:path").dirname(ctx.stateDir) : undefined, isUiSlice: ctx.isUiSlice } : undefined)
        : checkLisa(tag, content, ctx ? { stateRoot: ctx.stateDir, step: ctx.step, repoRoot: ctx.stateDir ? require("node:path").dirname(ctx.stateDir) : undefined } : undefined);
    // Prepend §122 violations (already computed above)
    for (const v of taskCapViolations)
        violations.push(v);
    // §123 R3 lock: R1 [PLAN] block paths — only fire when slice is set
    // (indicates §123-managed slice).
    if (role === "ralph" && tag === "PLAN" && ctx?.slice) {
        // Check complexity-judge JSON in PLAN body (heuristic: look for `mode` key
        // in a json block or top-level prose mentioning complexity-judge artifact)
        const hasJudgeJson = /"mode"\s*:\s*"(llm|heuristic|off)"/.test(content) || /complexity-judge/.test(content);
        if (!hasJudgeJson) {
            violations.push({
                rule: "complexity-judge-missing",
                message: `[PLAN] complexity-judge-missing: §123 R1 PLAN body must include complexity-judge JSON artifact (slice=${ctx.slice}). Run \`ralph-lisa task complexity-judge --slice ${ctx.slice}\` and paste the JSON.`,
            });
        }
        // complexity-verify hard gate
        if (ctx.complexityVerifyResult && !ctx.complexityVerifyResult.ok) {
            const errs = ctx.complexityVerifyResult.errors?.map((e) => e.rule).join(', ') ?? 'unknown';
            violations.push({
                rule: "complexity-verify-failed",
                message: `[PLAN] complexity-verify-failed: §123 hard gate exit non-zero (errors: ${errs}). Run \`ralph-lisa task complexity-verify --slice ${ctx.slice}\` and fix the cited issues.`,
            });
        }
        // mode=off on code-bearing slice without user ack
        const modeOffMatch = content.match(/"mode"\s*:\s*"off"/);
        if (modeOffMatch && ctx.codeBearing === true && ctx.userAckedOffMode !== true) {
            violations.push({
                rule: "mode-off-without-user-ack",
                message: `[PLAN] mode-off-without-user-ack: §123 mode=off on code-bearing slice (${ctx.slice}) requires explicit user ack. Set userAckedOffMode=true via consent ledger or change mode to heuristic/llm.`,
            });
        }
        // Lisa rerun high-confidence missing
        if (ctx.lisaRerunFound && ctx.lisaRerunFound.length > 0) {
            const accepted = new Set(ctx.ralphAcceptedTiers ?? []);
            const rejected = new Set(ctx.ralphRejectedTiers ?? []);
            for (const lisaTier of ctx.lisaRerunFound) {
                if (lisaTier.confidence === 'high' && !accepted.has(lisaTier.tier) && !rejected.has(lisaTier.tier)) {
                    violations.push({
                        rule: "lisa-rerun-high-confidence-missing",
                        message: `[PLAN] lisa-rerun-high-confidence-missing: §123 Lisa rerun found high-confidence tier "${lisaTier.tier}" not in Ralph's accept+reject set. Either add to 5-col Required table or explicitly reject with ack-downgrade.`,
                    });
                }
            }
        }
        // expected-tier-not-in-required (per Lisa R2: union-coverage check)
        if (ctx.expectedRequired && ctx.actualRequired) {
            const actual = new Set(ctx.actualRequired);
            for (const tier of ctx.expectedRequired) {
                if (!actual.has(tier)) {
                    violations.push({
                        rule: "expected-tier-not-in-required",
                        message: `[PLAN] expected-tier-not-in-required: §123 manifest+judge expected tier "${tier}" missing from PLAN 5-col Required table.`,
                    });
                }
            }
        }
    }
    // §122/§123 violations BYPASS mode-off early return. Keep this after §123
    // collection so RL_POLICY_MODE=off cannot skip mechanical complexity gates.
    if (mode === "off") {
        const mechanical = violations.filter((v) => v.rule === "task-capability-missing" ||
            v.rule === "task-capability-unacked" ||
            v.rule === "unsupported-tier-no-consent" ||
            v.rule === "complexity-judge-missing" ||
            v.rule === "complexity-verify-failed" ||
            v.rule === "mode-off-without-user-ack" ||
            v.rule === "lisa-rerun-high-confidence-missing" ||
            v.rule === "expected-tier-not-in-required");
        if (mechanical.length > 0) {
            return { proceed: false, violations: mechanical };
        }
        return { proceed: true, violations: [] };
    }
    // §102: auto-TDD protocol enforcement (additive — only when ctx provided and Ralph)
    if (role === "ralph" && ctx && ctx.tddMode && ctx.tddMode !== "off") {
        try {
            // eslint-disable-next-line @typescript-eslint/no-require-imports
            const autoTdd = require("./auto-tdd.js");
            const result = autoTdd.validateAutoTddProtocol(tag, content, {
                tddMode: ctx.tddMode,
                persistedPlan: ctx.persistedPlan,
                hasPriorTestsOnlyRound: ctx.hasPriorTestsOnlyRound,
                step: ctx.step,
                stateDir: ctx.stateDir,
            });
            if (!result.ok) {
                violations.push({
                    rule: "auto-tdd-protocol",
                    message: `[${tag}] auto-TDD protocol violation: ${result.error}`,
                });
            }
        }
        catch { /* never fatal */ }
    }
    if (violations.length === 0)
        return { proceed: true, violations: [] };
    // §102 (Lisa R9 B2 lock): auto-TDD violations always block, regardless of RL_POLICY_MODE.
    // §122 (Lisa R1.2 B8 + R3 B19+B20 lock): task-capability violations (missing,
    // unacked, unsupported-no-consent) are mechanical enforcement — always block
    // regardless of RL_POLICY_MODE.
    const hasAutoTddViolation = violations.some((v) => v.rule === "auto-tdd-protocol");
    const hasTaskCapViolation = violations.some((v) => v.rule === "task-capability-missing" ||
        v.rule === "task-capability-unacked" ||
        v.rule === "unsupported-tier-no-consent");
    // §123 R3 lock: all 5 §123 violations are mechanical hard gates, bypass-immune to RL_POLICY_MODE
    const hasComplexityViolation = violations.some((v) => v.rule === "complexity-judge-missing" ||
        v.rule === "complexity-verify-failed" ||
        v.rule === "mode-off-without-user-ack" ||
        v.rule === "lisa-rerun-high-confidence-missing" ||
        v.rule === "expected-tier-not-in-required");
    if (mode === "block" || hasAutoTddViolation || hasTaskCapViolation || hasComplexityViolation) {
        return { proceed: false, violations };
    }
    // warn mode: proceed but pass violations to caller
    return { proceed: true, violations };
}
/**
 * §92 C5: parse `## Test Results` section for per-tier evidence blocks.
 * Format: `- <tier>: <cmd> → <result>` (per §90 design doc + Lisa R3 contract).
 * Returns object with one entry per tier present; missing tiers absent (not null entry).
 */
function parseTierEvidence(submissionBody) {
    const result = {};
    const tierNames = ["unit", "smoke", "functional", "integration", "e2e", "perf", "stability", "security"];
    // Match `- <tier>: <cmd> → <result>` (allow → or -> as separator)
    const lineRe = /^[-*]\s+(unit|smoke|functional|integration|e2e|perf|stability|security):\s*(.+?)\s*(?:→|->)\s*(.+?)\s*$/gim;
    let match;
    while ((match = lineRe.exec(submissionBody)) !== null) {
        const tier = match[1];
        if (!tierNames.includes(tier))
            continue;
        result[tier] = { cmd: match[2].trim(), result: match[3].trim() };
    }
    return result;
}
/**
 * §92 C6: validate per-tier evidence covers preset.requiredTiers.
 *   - presetEnabled=false → bypass entirely (returns valid=true; per Q2 Lisa lock — true no-op)
 *   - requireAll=true (strict-enforcing default) → every requiredTier must have non-empty cmd+result
 *   - requireAll=false (warn-only) → still checks but caller handles warning vs blocking
 */
function validateTierCoverage(evidence, preset, opts) {
    if (!opts.presetEnabled) {
        return { valid: true };
    }
    const missing = [];
    for (const tier of preset.requiredTiers) {
        const e = evidence[tier];
        if (!e || !e.cmd || !e.result || e.cmd.trim() === "" || e.result.trim() === "") {
            missing.push(tier);
        }
    }
    if (missing.length === 0) {
        return { valid: true };
    }
    // requireAll=true → strict reject; requireAll=false → caller warns but we still return valid=false
    // so caller can decide. Lisa Q2 lock: warn-only means parse+report, don't auto-invoke.
    return {
        valid: false,
        reason: `missing or empty evidence for required tier(s): ${missing.join(", ")}`,
        missingTiers: missing,
    };
}
// ─── §128 R3 — clarify gate + negative-scope guard + scope-expansion-pending ────────────
/**
 * §128 R3 — `clarify-not-completed` policy gate.
 * Reads §123 complexity-judge .extension to determine complexity_class:
 *   - simple/standard → escape pass
 *   - complex/expert → must have clarify-locked-<step>.json + (committed OR skip_clarify)
 *
 * Returns { proceed, reason?, warning? }.
 */
function checkClarifyGate(ctx) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const fs = require('node:fs');
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const pathMod = require('node:path');
    // Lisa R6 B11 + R9 B18: prefer explicit stateRoot (engine path); fallback to cwd-join (CLI test);
    // last resort canonical stateDir() (RL_STATE_DIR / tmux / upward search).
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { stateDir: canonicalStateDir } = require('./state.js');
    const stateRoot = ctx.stateRoot
        ?? (ctx.cwd ? pathMod.join(ctx.cwd, '.dual-agent') : canonicalStateDir());
    // 1. Read §123 artifact for complexity_class
    const judgePath = pathMod.join(stateRoot, 'complexity-judge', `${ctx.step}.json`);
    let complexityClass = null;
    if (fs.existsSync(judgePath)) {
        try {
            const judge = JSON.parse(fs.readFileSync(judgePath, 'utf8'));
            complexityClass = judge?.extension?.task_complexity_class ?? null;
        }
        catch { /* fallthrough */ }
    }
    if (!complexityClass) {
        // No extension yet → not a §128-eligible task; pass
        return { proceed: true };
    }
    if (complexityClass === 'simple' || complexityClass === 'standard') {
        return { proceed: true };
    }
    // complex/expert: must have clarify-locked artifact
    const lockedPath = pathMod.join(stateRoot, `clarify-locked-${ctx.step}.json`);
    if (!fs.existsSync(lockedPath)) {
        return {
            proceed: false,
            reason: `clarify-not-completed: complex/expert task requires R0 [CLARIFY] complete first; run 'ralph-lisa clarify --start' (or 'clarify --skip' for explicit escape)`,
        };
    }
    try {
        const locked = JSON.parse(fs.readFileSync(lockedPath, 'utf8'));
        if (locked.skip_clarify === true) {
            return {
                proceed: true,
                warning: 'clarify-skip: 没提清楚需求就进入下一步, 可能只是验证思路, 结果不一定正式可用',
                warnings: ['clarify-skip: explicit user escape (skip_clarify=true)'],
            };
        }
        if (locked.committed === true) {
            return { proceed: true };
        }
        return {
            proceed: false,
            reason: `clarify-not-completed: artifact exists but not committed; run 'ralph-lisa clarify --commit'`,
        };
    }
    catch (e) {
        return {
            proceed: false,
            reason: `clarify-not-completed: failed to parse artifact: ${e.message}`,
        };
    }
}
/**
 * §128 R3 — Lisa narrow negative-scope guard.
 * Given a Lisa narrow text, checks if it would expand R0 negative_scope.
 * Returns suggested_tag: 'NEEDS_USER_ACK' if scope expansion detected, else 'NEEDS_WORK'.
 *
 * Heuristic: tokenized keyword overlap with negative_scope items. Conservative bias.
 * LLM-semantic match (Lisa rerun) is the upgrade path; for R3 ship, heuristic suffices.
 */
function checkLisaNarrowScopeExpansion(ctx) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const fs = require('node:fs');
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const pathMod = require('node:path');
    // Lisa R6 B11 + R9 B18: prefer explicit stateRoot, fallback to cwd-join, last resort canonical
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { stateDir: canonicalStateDir2 } = require('./state.js');
    const stateRootLisa = ctx.stateRoot
        ?? (ctx.cwd ? pathMod.join(ctx.cwd, '.dual-agent') : canonicalStateDir2());
    const lockedPath = pathMod.join(stateRootLisa, `clarify-locked-${ctx.step}.json`);
    if (!fs.existsSync(lockedPath)) {
        return { suggested_tag: 'NEEDS_WORK', scope_expansion_detected: false };
    }
    let negativeScope = [];
    try {
        const locked = JSON.parse(fs.readFileSync(lockedPath, 'utf8'));
        negativeScope = locked.negative_scope ?? [];
    }
    catch {
        return { suggested_tag: 'NEEDS_WORK', scope_expansion_detected: false };
    }
    if (negativeScope.length === 0) {
        return { suggested_tag: 'NEEDS_WORK', scope_expansion_detected: false };
    }
    const narrowLower = ctx.narrowText.toLowerCase();
    for (const item of negativeScope) {
        const itemTokens = item.toLowerCase().split(/[\s\-_,]+/).filter((t) => t.length > 2);
        let hits = 0;
        for (const t of itemTokens) {
            if (narrowLower.includes(t))
                hits++;
        }
        // ≥2 tokens or ≥50% of tokens overlap → match
        if (hits >= 2 || (itemTokens.length > 0 && hits / itemTokens.length >= 0.5)) {
            return {
                suggested_tag: 'NEEDS_USER_ACK',
                scope_expansion_detected: true,
                matched_negative_scope_item: item,
            };
        }
    }
    return { suggested_tag: 'NEEDS_WORK', scope_expansion_detected: false };
}
/**
 * §128 R3 — scope-expansion-pending-not-acked policy gate.
 * If .dual-agent/scope-expansion-pending.json exists, block Ralph submit until ack.
 */
function checkScopeExpansionPending(opts) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const fs = require('node:fs');
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const pathMod = require('node:path');
    // Lisa R6 B11 + R9 B19: accept either positional cwd string (legacy) or {cwd, stateRoot} object.
    // Prefer explicit stateRoot (engine TurnCoordinator path), fallback to cwd-join, last resort canonical.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { stateDir: canonicalStateDir3 } = require('./state.js');
    let stateRoot;
    if (typeof opts === 'string') {
        stateRoot = pathMod.join(opts, '.dual-agent');
    }
    else if (opts?.stateRoot) {
        stateRoot = opts.stateRoot;
    }
    else if (opts?.cwd) {
        stateRoot = pathMod.join(opts.cwd, '.dual-agent');
    }
    else {
        stateRoot = canonicalStateDir3();
    }
    const pendingPath = pathMod.join(stateRoot, 'scope-expansion-pending.json');
    if (!fs.existsSync(pendingPath)) {
        return { proceed: true };
    }
    return {
        proceed: false,
        reason: `scope-expansion-pending-not-acked: Lisa narrow proposed scope expansion (see ${pendingPath}). Run 'ralph-lisa ack-scope-expansion --reason "..."' to ack, OR have Lisa find within-scope solution.`,
    };
}
/**
 * §129 — checkDocOracleSpecRequired.
 * Doc-task [PLAN]/[FIX] body must contain a parseable doc-oracle-spec table with ≥1 Required ✓ row.
 * Non-doc-task bypasses.
 */
async function checkDocOracleSpecRequired(ctx) {
    if (!ctx.isDocTask)
        return { proceed: true };
    if (ctx.tag !== "PLAN" && ctx.tag !== "FIX")
        return { proceed: true };
    const { tryParseDocOracleTable, validateDocOracleRow } = await import("./doc-oracle-spec.js");
    const rows = tryParseDocOracleTable(ctx.body);
    if (!rows || rows.length === 0) {
        return {
            proceed: false,
            reason: "doc-oracle-spec table missing — doc-task [PLAN] must include a 5-col table (| ID | Dimension | Verification Method | Pass Criteria | Required |) with >=1 Required row",
        };
    }
    const requiredRows = rows.filter((r) => r.required);
    if (requiredRows.length === 0) {
        return {
            proceed: false,
            reason: "doc-oracle-spec has no Required rows — at least one dimension must be Required for §70 cascade",
        };
    }
    for (const r of rows) {
        const v = validateDocOracleRow(r);
        if (!v.ok) {
            return { proceed: false, reason: `doc-oracle-spec invalid row ${r.id}: ${v.error}` };
        }
    }
    return { proceed: true };
}
