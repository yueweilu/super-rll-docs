- 复用现有 `ToolSearchTool` 实现 (schema 已定义), 主要改 `utils/toolSearch.ts:modelSupportsToolReference` 决策 + `query.ts` tool array dynamic 扩展机制

**复杂度**: 中等 (1 slice, 3-4 phase)
**依赖**: slice 9 (provider-health-monitoring) 跑完

## 43. Active sub-slice: `wezterm-test-recording-infra`

**Trigger** (2026-05-31): 用户要求所有 wezterm-test 走 headed 模式 + 记录测试过程, 给后续 wezterm 测试系列 (slice 14-19) 做基础. 默认 wezterm-test 没有统一录制机制 — 各 macro 各写 ad-hoc 输出, 失败时复盘困难.

**根因**: 现有 `ralph-lisa skill wezterm-test --macro <path>` 只输出 per-step pass/fail JSON, 没有 (a) 完整 pane 文本 dump, (b) 视觉截图, (c) ccl 自身 debug log. 用户排查问题需要 4 件套.

### In-scope: 一键 wrapper + 目录约定 (4 REQUIRED + 1 best-effort) — **scope-updated 2026-06-01**

**Scope update reason** (per Lisa R4 / docs/superrll-handoff-2026-05-31.md B7/B8): 经实测发现 screencapture 受 macOS active-tab 限制无法可靠捕捉 spawned pane 内容. 用户接受 pane.cast (ANSI cast) 为主视觉证据, screenshot.png 降为 best-effort. 加 process-cleanup + timeline.txt 满足用户「进程回收 + 时序审计 + 可复现」要求.

**New 4 REQUIRED artifacts**: run.json + pane-raw.txt + pane.cast + ccl-debug.log
**Best-effort (not failure-causing)**: screenshot.png

- `tests/wezctl/run-macro.sh` (NEW, ~140 lines): 接 `<test-id> <macro.json|sh>` 参数, 自动:
  1. 创建 `tests/wezctl/recordings/$(date +%Y-%m-%d)/<test-id>/` 目录 + `timeline.txt` (ISO 8601 ts log)
  2. 通过 env `CCL_TEST_DEBUG_LOG` / `CCL_TEST_SCREENSHOT` / `CCL_TEST_PANE_CAST` 传 deterministic 路径给 macro
  3. Sed 处理 macro JSON 替换 env literal (因 wezterm spawn 子 pane 不继承 wrapper env)
  4. 跑 macro (`ralph-lisa skill wezterm-test --macro <path> --json --keep-pane > run.json`)
  5. `wezctl read <pane>` → `pane-raw.txt`
  6. pane.cast 由 macro 自己写 (内 `wezterm cli get-text --escapes --pane-id $WEZTERM_PANE`)
  7. screenshot.png best-effort (无 `-l` flag, full-screen, 失败 INFO 不退)
  8. **Cleanup**: 追踪所有 spawn 的 pane_id, 在 wrapper exit 前 `wezctl kill <pid>` 每个, 失败容错
  9. 写 timeline.txt 各步骤 ISO timestamp (audit trail)
  10. 4 件齐全 → exit 0; pane.cast 缺失 → exit 4; ccl-debug.log 缺失 → exit 3

- `tests/wezctl/macros/T0-smoke-version.macro.json` (NEW, 3-step):
  - Step 1 `--version` smoke: `node dist/cli.js --version` → wait for `(CCL)`
  - Step 2 debug log producer: `node dist/cli.js --debug --debug-file $CCL_TEST_DEBUG_LOG mcp list` → wait for `MCP`
  - Step 3 ANSI cast capture: `wezterm cli get-text --escapes --pane-id "$WEZTERM_PANE" > $CCL_TEST_PANE_CAST` → wait for `CAST-DONE`

- `tests/wezctl/replay.sh` (NEW, ~30 lines): 人肉视觉化 — spawn 新 wezterm pane + cat ANSI cast 重渲染. 满足「可复现」.
- 调用约定: `bash tests/wezctl/run-macro.sh T0-smoke-version tests/wezctl/macros/T0-smoke-version.macro.json`

### Negative scope (out — 留给 slice 14+)

- 实际 happy-path 测试 macro (T1-T8 各类)
- 长跑 + negative test (TC.1-TC.5)
- video 录制 (静态截图够用)

**改动文件**:
- `tests/wezctl/run-macro.sh` (NEW, ~80 lines)
- `tests/wezctl/macros/T0-smoke-version.macro.json` (NEW)
- `__tests__/unit/run-macro-wrapper.test.ts` (NEW, ~5 cases): mock-spawn 验路径解析 / dir 创建 / 4 件套文件名约定

**§155 self-check**: gate-manifest project_type=cli, default_baseline=[unit, integration]. **baseline matches project_type=cli**.

complexity-judge: standard/medium with high-conf unit+integration tiers (artifact `.dual-agent/complexity-judge/wezterm-test-recording-infra.json`).

| ID | Tier | Command | Oracle | Required |
|----|------|---------|--------|----------|
| C1 | unit | npx vitest run __tests__/unit/run-macro-wrapper.test.ts | 12 vitest cases (4 groups): (a) arg validation [4 cases]: `../` + missing macro + bad ext + no-args → exit 10; (b) dir schema + timeline + cleanup [4 cases]: `recordings/YYYY-MM-DD/<id>/` created on macro failure / timeline.txt ISO 8601 format with wrapper-start + cleanup-start markers / cleanup trap fires on EXIT (cleanup-end in timeline) / sh-branch passthrough does not enforce pane.cast contract; (c) JSON-branch degraded via stub `ralph-lisa` script in PATH [4 cases]: ok:true + empty rawL1 (no pane id) → exit 6 (pane-raw empty); ok:false → exit 5 (schema fail); ok:true + pane-raw pre-created but pane.cast empty → exit 4; ok:true + pane-raw + pane.cast pre-created but ccl-debug.log empty → exit 3. | ✓ |
| C2 | unit | npx vitest run __tests__/unit/ --testTimeout=60000 | regression: 51 test files, 694 cases all pass / 0 fail (baseline 682 + 12 NEW from C1 = 694). No existing test breaks. | ✓ |
| C3 | integration | bash tests/wezctl/run-macro.sh T0-smoke-version tests/wezctl/macros/T0-smoke-version.macro.json | end-to-end on real headed wezterm: 3-step macro + 4 REQUIRED + 1 best-effort artifacts. **Assertions** (Lisa primary review reads pane.cast): (1) recordings/<date>/T0-smoke-version/run.json contains `"ok": true` (skill schema, NOT exit_code field); (2) pane-raw.txt exists non-empty; (3) **pane.cast** contains `(CCL)` (from step1) + `MCP` (from step2); (4) ccl-debug.log size > 0; (5) timeline.txt contains ≥3 ISO 8601 timestamp entries (steps `wrapper-start` / `macro-start` / `macro-end`); (6) screenshot.png best-effort (info-warn if empty). **Cleanup**: post-test `wezctl list` must show no leaked spawned panes (wrapper-tracked pane_ids all killed). **Reproducibility**: `bash tests/wezctl/replay.sh <cast-path>` reproduces visual state in new wezterm pane. | ✓ |

baseline matches project_type=cli

## 42. Active sub-slice: `enable-feature-gates-batch`

**Trigger** (2026-05-31): Feature-gate audit found 90 distinct `feature('...')` callsites; only 25 are enabled by `enableCCLFeatures()` (20 FULLY_IMPLEMENTED + 5 STUB). Of the remaining 65, **18 are fully implemented locally** (modules present, no external Anthropic infra dependency) but not yet flipped to ON. User wants all available gates opened.

**根因**: `compat/enabledFeatures.ts:21-44 FULLY_IMPLEMENTED_FEATURES` list was incomplete after migration — flags that work standalone (UI tweaks, classifiers, history picker, MCP rich output, verification agent, etc.) were left off, while their guard sites still check them. Result: dead user-facing features.

### In-scope: enable 18 gates (16 fully-implemented + 2 stub-class)

**Add to `FULLY_IMPLEMENTED_FEATURES` (16)**:
- AGENT_MEMORY_SNAPSHOT, AUTO_THEME, BASH_CLASSIFIER, BREAK_CACHE_COMMAND, CONNECTOR_TEXT, FILE_PERSISTENCE, HISTORY_PICKER, MCP_RICH_OUTPUT, NEW_INIT, PERFETTO_TRACING, POWERSHELL_AUTO_MODE, SLOW_OPERATION_LOGGING, STREAMLINED_OUTPUT, ULTRATHINK, UNATTENDED_RETRY, VERIFICATION_AGENT

Each is locally implemented — module file exists, NOT prefixed by `// Stub:` marker, no external Anthropic dep.

**Add to `STUB_FEATURES` (2)**:
- MONITOR_TOOL — `tools/MonitorTool/MonitorTool.ts` is explicitly `// Stub:` marked, `isEnabled() { return false }`. Gate ON is safe (no crash) but the tool itself stays disabled at the Tool layer until real impl lands.
- REVIEW_ARTIFACT — same pattern: `tools/ReviewArtifactTool/ReviewArtifactTool.ts` `// Stub:` + `isEnabled() { return false }`.

Why open the stub gates too: the gate guards initialization paths (`tools.ts`, `commands.ts`); flipping ON ensures the surrounding code wires the (stub) tool through registration, which is the documented `STUB_FEATURES` pattern at `compat/enabledFeatures.ts:48-56`.

### Negative scope (out — separate sub-slice)

- 5 potential-issue flags (TORCH, UDS_INBOX, TREE_SITTER_BASH/SHADOW, TEMPLATES, WEB_BROWSER_TOOL) — these have missing module files or runtime-dep gaps; need dead-code-clean or dep-install sub-slice
- External Anthropic infra flags (KAIROS*, BRIDGE_MODE, DAEMON, BYOC, SELF_HOSTED_RUNNER, CCR_*, LODESTONE, SSH_REMOTE, VOICE_MODE, etc.) — correctly off, no action

**改动文件 (in-scope only)**:
- `compat/enabledFeatures.ts` (+16 to FULLY_IMPLEMENTED_FEATURES, +2 to STUB_FEATURES)
- `dist/cli.js` (regenerate via `bun run build`)
- `__tests__/unit/feature-flags.test.ts` (EXTEND existing — adds the 18 NEW flags into assertion blocks using existing `feature(flag)` API at compat/bunBundle.ts:20)
- `tests/wezctl/06-feature-gates-bundle-audit.sh` (NEW) — differential bundle audit (mutate-and-fail proof)

**§155 self-check**: gate-manifest project_type=cli, default_baseline=[unit, integration]. **baseline matches project_type=cli**.

complexity-judge: **standard / medium with high-conf unit+integration tiers** (artifact `.dual-agent/complexity-judge/enable-feature-gates-batch.json`).

| ID | Tier | Command | Oracle | Required |
|----|------|---------|--------|----------|
| C1 | unit | npx vitest run __tests__/unit/feature-flags.test.ts | EXTENDED file: existing 8 fully-impl cases + add 18 NEW (16 FULLY_IMPLEMENTED + 2 STUB_FEATURES). Uses real `feature(flag)` API from compat/bunBundle.ts:20 after `enableCCLFeatures()` runs. Anti-vacuous: per-flag `expect(feature('AGENT_MEMORY_SNAPSHOT')).toBe(true)` would fail if the literal flag string is missing from the const arrays. | ✓ |
| C2 | unit | npx vitest run __tests__/unit/ --testTimeout=60000 | regression baseline 664 → 664+18=682 pass / 0 fail. No existing test breaks from flipping the 18 flags (key risk: BASH_CLASSIFIER / NEW_INIT / VERIFICATION_AGENT change observable behavior in many code paths). | ✓ |
| C3 | integration | bash tests/wezctl/06-feature-gates-bundle-audit.sh | differential bundle audit: (1) `bun run build` → dist/cli.js; (2) for each of the 18 flag literal strings, the dist count is **≥1 (esbuild const-folds callsite, only the const-array entry survives)**; (3) **neighbor adjacency** check — within ±1 line of the FLAG occurrence in dist, a **different** known FULLY_IMPLEMENTED / STUB flag literal must appear, proving the FLAG is inside the bundled enabled-features array (the FLAG's own line is excluded from the neighbor regex). Anti-vacuous proof: drop one flag from FULLY_IMPLEMENTED_FEATURES, rebuild, rerun → dist count for that flag drops to 0, script fails for that flag. Lisa R3 caught the prior self-match bug; fix excludes current FLAG from neighbor regex. | ✓ |

