"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseLisaAttest = parseLisaAttest;
exports.verifyLisaAttest = verifyLisaAttest;
exports.extractLatestLisaPass = extractLatestLisaPass;
exports.parseAgreement = parseAgreement;
exports.parseShapeChangeRequest = parseShapeChangeRequest;
/**
 * §149 P1-lisa-attest — Lisa-side attest block parser + verifier.
 *
 * Pure functions (no shell exec). Parse Reviewed-PLAN-rows / Reviewed-test-files /
 * Reviewed-test-log / Pass-Rationale / NeedsWork-Rationale / Verified lines from
 * Lisa [PASS]/[CONSENSUS]/[NEEDS_WORK] body. Verify against §123 auto-tdd-plan
 * artifact + filesystem + §137 test-execution-log.
 */
const fs = __importStar(require("node:fs"));
const path = __importStar(require("node:path"));
const RATIONALE_MIN_CHARS = Number(process.env.RL_ATTEST_RATIONALE_MIN_CHARS ?? '40');
function parseRationale(line) {
    const text = line.replace(/^[A-Za-z-]+\s*:\s*/, '').trim();
    const fileLineCites = [...text.matchAll(/[\w./-]+\.\w+:\d+(?:-\d+)?/g)].map((m) => m[0]);
    const artifactCites = [...text.matchAll(/\.dual-agent\/[\w./-]+|gate-results\.\w+|harness-results\/[\w./-]+|auto-tdd-plan-[\w./-]+\.json/g)].map((m) => m[0]);
    return { text, file_line_cites: fileLineCites, artifact_cites: artifactCites };
}
function parseLisaAttest(body) {
    if (!body)
        return null;
    const lines = body.split('\n');
    let plan_rows = [];
    let test_files = [];
    let test_log_claim = null;
    let pass_rationale;
    let needs_work_rationale;
    let verified_cite;
    let sawAny = false;
    for (const line of lines) {
        const planM = line.match(/^Reviewed-PLAN-rows:\s*(.+)$/);
        if (planM) {
            plan_rows = planM[1].split(',').map((s) => s.trim()).filter(Boolean);
            sawAny = true;
            continue;
        }
        const filesM = line.match(/^Reviewed-test-files:\s*(.+)$/);
        if (filesM) {
            const items = filesM[1].split(',').map((s) => s.trim()).filter(Boolean);
            for (const it of items) {
                const m = it.match(/^([\w./-]+):(\d+)(?:-(\d+))?/);
                if (m) {
                    test_files.push({ path: m[1], line_from: Number(m[2]), line_to: Number(m[3] ?? m[2]) });
                }
            }
            sawAny = true;
            continue;
        }
        const logM = line.match(/^Reviewed-test-log:\s*(.+)$/);
        if (logM) {
            const cmdMatch = logM[1].match(/cmd="([^"]+)"|cmd=([^\s]+)/);
            const cmd = cmdMatch ? (cmdMatch[1] ?? cmdMatch[2]) : '?';
            const passed = logM[1].match(/passed=(\d+)/);
            const failed = logM[1].match(/failed=(\d+)/);
            const total = logM[1].match(/total=(\d+)/);
            test_log_claim = {
                cmd,
                ...(passed && { passed: Number(passed[1]) }),
                ...(failed && { failed: Number(failed[1]) }),
                ...(total && { total: Number(total[1]) }),
            };
            sawAny = true;
            continue;
        }
        if (/^Pass-Rationale:/.test(line)) {
            pass_rationale = parseRationale(line);
            sawAny = true;
            continue;
        }
        if (/^NeedsWork-Rationale:/.test(line)) {
            needs_work_rationale = parseRationale(line);
            sawAny = true;
            continue;
        }
        const verM = line.match(/^Verified:\s*(\S+)/);
        if (verM) {
            verified_cite = verM[1];
            sawAny = true;
        }
    }
    if (!sawAny)
        return null;
    return { plan_rows, test_files, test_log_claim, pass_rationale, needs_work_rationale, verified_cite };
}
function verifyLisaAttest(attest, opts) {
    const missing = [];
    const unverified = [];
    const repoRoot = opts.repoRoot ?? path.dirname(opts.stateRoot);
    // PLAN row cross-check
    if (attest.plan_rows.length > 0) {
        const artifactPath = path.join(opts.stateRoot, `auto-tdd-plan-${opts.step}.json`);
        if (fs.existsSync(artifactPath)) {
            try {
                const a = JSON.parse(fs.readFileSync(artifactPath, 'utf8'));
                const ids = new Set((a.rows ?? []).map((r) => r.id));
                for (const row of attest.plan_rows) {
                    if (!ids.has(row))
                        unverified.push({ kind: 'plan-row', reason: `PLAN row "${row}" not in auto-tdd-plan-${opts.step}.json` });
                }
            }
            catch { /* malformed */ }
        }
    }
    // Test file existence
    for (const tf of attest.test_files) {
        const abs = path.isAbsolute(tf.path) ? tf.path : path.resolve(repoRoot, tf.path);
        if (!fs.existsSync(abs))
            unverified.push({ kind: 'test-file', reason: `test file ${tf.path} does not exist` });
    }
    // Test log claim via §137 verifier
    if (attest.test_log_claim) {
        try {
            const verifier = require('./test-results-claim-verifier.js');
            const claims = [{ ...attest.test_log_claim }];
            const r = verifier.verifyTestResultsClaims(claims, { stateRoot: opts.stateRoot, maxAgeMin: 10 });
            if (r.unverified.length > 0) {
                unverified.push({ kind: 'test-log', reason: `test-log claim mismatch: ${JSON.stringify(r.unverified[0])}` });
            }
        }
        catch { /* never fatal */ }
    }
    // Rationale quality_score
    const rat = attest.pass_rationale ?? attest.needs_work_rationale;
    const quality_score = !!rat && rat.text.length >= RATIONALE_MIN_CHARS &&
        (rat.file_line_cites.length >= 1 || rat.artifact_cites.length >= 1);
    return { missing, unverified, quality_score };
}
/**
 * §149 P3-counter-attest: extract latest canonical Lisa PASS body from review.md.
 * Returns null if:
 *  - No PASS for current step
 *  - Latest PASS superseded by later NEEDS_WORK/CHALLENGE
 *  - PASS body is compact-history placeholder
 *  - PASS is for a previous step
 */
function extractLatestLisaPass(reviewContent, currentStep) {
    if (!reviewContent || !currentStep)
        return null;
    // Find all canonical tag-headed sections: `## [TAG] Round N | Step: <step>`
    const sectionRe = /^##\s+\[(PASS|NEEDS_WORK|CHALLENGE|CONSENSUS)\]\s+Round\s+(\d+)\s+\|\s+Step:\s+(\S+)/gm;
    const sections = [];
    let m;
    while ((m = sectionRe.exec(reviewContent)) !== null) {
        sections.push({ tag: m[1], round: Number(m[2]), step: m[3], bodyStart: m.index + m[0].length });
    }
    // Filter to current step only; find latest PASS not followed by NEEDS_WORK/CHALLENGE for same step
    const currentStepSections = sections.filter((s) => s.step === currentStep);
    if (currentStepSections.length === 0)
        return null;
    // Find latest PASS index
    let latestPassIdx = -1;
    for (let i = currentStepSections.length - 1; i >= 0; i--) {
        if (currentStepSections[i].tag === 'PASS') {
            latestPassIdx = i;
            break;
        }
    }
    if (latestPassIdx < 0)
        return null;
    // Check no later NEEDS_WORK/CHALLENGE after latest PASS
    for (let i = latestPassIdx + 1; i < currentStepSections.length; i++) {
        if (currentStepSections[i].tag === 'NEEDS_WORK' || currentStepSections[i].tag === 'CHALLENGE') {
            return null;
        }
    }
    // Extract body (from bodyStart to next section header or end)
    const passSection = currentStepSections[latestPassIdx];
    const nextIdx = sections.findIndex((s) => s.bodyStart > passSection.bodyStart);
    let body;
    if (nextIdx >= 0) {
        // Body ends before next `## [`
        const nextHeaderStart = reviewContent.lastIndexOf('\n## [', sections[nextIdx].bodyStart);
        body = reviewContent.slice(passSection.bodyStart, nextHeaderStart >= 0 ? nextHeaderStart : sections[nextIdx].bodyStart);
    }
    else {
        body = reviewContent.slice(passSection.bodyStart);
    }
    // Reject compact-history placeholder
    if (/\(Full content in review\.md\)/.test(body))
        return null;
    return body.trim();
}
/** §202 Phase B — parse a Lisa [PASS]/[NEEDS_WORK] body for the non-TDD
 * agreement fields. Returns `{agreed_shape, rationale, rationale_hash}` when
 * both fields are present, else fields are undefined. Pure function. */
function parseAgreement(body) {
    if (!body)
        return {};
    const shapeMatch = body.match(/Agreed-Shape:\s*([a-z][a-z0-9-]*)/i);
    const ratMatch = body.match(/Shape-Rationale:\s*([^\n]+(?:\n(?!Reviewed-|Pass-|NeedsWork-|Verified:|Agreed-|Shape-Change-|##|$)[^\n]+)*)/i);
    const out = {};
    if (shapeMatch)
        out.agreed_shape = shapeMatch[1].toLowerCase();
    if (ratMatch) {
        const r = ratMatch[1].trim();
        out.rationale = r;
        // §202 C13 security: secret-scrub via §197 SECRET_PATTERNS BEFORE hashing.
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const { SECRET_PATTERNS } = require('./test-logs.js');
        let scrubbed = r;
        for (const [re, repl] of SECRET_PATTERNS) {
            scrubbed = scrubbed.replace(re, repl);
        }
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const crypto = require('node:crypto');
        out.rationale_hash = crypto.createHash('sha256').update(scrubbed).digest('hex');
    }
    return out;
}
/** §202 Phase B — parse a Lisa [NEEDS_WORK] body for the shape-change request. */
function parseShapeChangeRequest(body) {
    if (!body)
        return {};
    const m = body.match(/Shape-Change-Requested:\s*([a-z][a-z0-9-]*)/i);
    return m ? { requested_shape: m[1].toLowerCase() } : {};
}
