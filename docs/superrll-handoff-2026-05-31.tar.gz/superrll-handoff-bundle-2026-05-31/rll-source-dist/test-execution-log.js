"use strict";
/**
 * §137 lite — test-execution-log: append-only jsonl recording each runGate runner.
 *
 * Per Lisa R1 B1 lock: includes parsed counts {passed, failed, total} when available.
 * Per Lisa R4 B6: empty cmd → no-write; rotation exact-at-N preserves newest.
 * Per Lisa R5 B9: secret redaction at write boundary.
 *
 * RL_TEST_EXECUTION_LOG_OFF=1 disables.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.logTestExecution = logTestExecution;
exports.readTestExecutionLog = readTestExecutionLog;
exports.rotateTestExecutionLog = rotateTestExecutionLog;
const fs = __importStar(require("node:fs"));
const path = __importStar(require("node:path"));
const SECRET_PATTERNS = [
    /\bsk-[a-zA-Z0-9_-]{8,}\b/g,
    /\b(?:api[_-]?key|token|secret|bearer)\s*[:=]\s*\S+/gi,
];
function redact(s) {
    let out = s;
    for (const re of SECRET_PATTERNS)
        out = out.replace(re, '[REDACTED]');
    return out;
}
function logPath(stateRoot) {
    return path.join(stateRoot, 'test-execution-log.jsonl');
}
function logTestExecution(entry, opts) {
    if (process.env.RL_TEST_EXECUTION_LOG_OFF === '1')
        return;
    if (!entry.cmd || entry.cmd.trim().length === 0)
        return; // empty cmd no-write
    try {
        fs.mkdirSync(opts.stateRoot, { recursive: true });
        const safe = {
            cmd: redact(entry.cmd),
            exit_code: entry.exit_code,
            started_at: entry.started_at,
            duration_ms: entry.duration_ms,
        };
        if (entry.passed !== undefined)
            safe.passed = entry.passed;
        if (entry.failed !== undefined)
            safe.failed = entry.failed;
        if (entry.total !== undefined)
            safe.total = entry.total;
        fs.appendFileSync(logPath(opts.stateRoot), JSON.stringify(safe) + '\n', 'utf8');
    }
    catch { /* never fatal */ }
}
function readTestExecutionLog(opts) {
    const p = logPath(opts.stateRoot);
    if (!fs.existsSync(p))
        return [];
    try {
        return fs.readFileSync(p, 'utf8').trim().split('\n').filter((l) => l.length > 0).map((l) => JSON.parse(l));
    }
    catch {
        return [];
    }
}
function rotateTestExecutionLog(opts) {
    const all = readTestExecutionLog(opts);
    if (all.length <= opts.maxEntries)
        return;
    const trimmed = all.slice(-opts.maxEntries);
    try {
        fs.writeFileSync(logPath(opts.stateRoot), trimmed.map((e) => JSON.stringify(e)).join('\n') + '\n');
    }
    catch { /* never fatal */ }
}
