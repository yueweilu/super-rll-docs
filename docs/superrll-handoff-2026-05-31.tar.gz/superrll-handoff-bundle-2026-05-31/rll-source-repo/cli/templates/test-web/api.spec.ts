import { test, expect } from "@playwright/test";

test.describe("API Tests @func", () => {
  test("health endpoint returns 200", async ({ request }) => {
    const response = await request.get("/api/health");
    expect(response.status()).toBe(200);
  });

  test("API returns valid JSON", async ({ request }) => {
    // Adjust endpoint to match your API
    const response = await request.get("/api/health");
    expect(response.headers()["content-type"]).toContain("application/json");
    const body = await response.json();
    expect(body).toBeDefined();
  });
});
