---
name: lisa-review
description: "Let Lisa review your code via MCP. Lisa is a persistent AI code reviewer with cross-round context."
triggers:
  - "review"
  - "lisa review"
  - "code review"
  - "审查"
  - "审核"
---

# Lisa Code Review

## What This Skill Does

Calls the `rll_lisa_review` MCP tool to get a code review from Lisa. Lisa is a persistent reviewer who remembers previous reviews in the same session (cross-round context).

## How to Use

When the user asks for a code review, call the MCP tool `rll_lisa_review` with these parameters:

- `content`: The code or submission to review. Should start with a tag like `[CODE]`, `[PLAN]`, or `[FIX]`.
- `lisa_backend`: Which AI model Lisa uses. Default: `"codex"`. Can also be `"claude"`.
- `auto_approve`: Whether to auto-approve Lisa's tool use. Default: `true`.

## Example

When the user says "review my code" or "审查代码":

1. Collect the relevant code changes (use `git diff` or read the files the user is working on)
2. Call the MCP tool:

```
Tool: rll_lisa_review
Parameters:
  content: "[CODE] <paste the code changes here, with file paths>"
  lisa_backend: "codex"
  auto_approve: true
```

3. Show Lisa's review to the user. Lisa will respond with:
   - `[PASS]` — code looks good
   - `[NEEDS_WORK]` — issues found, with file:line references

## Important

- **Always use the MCP tool `rll_lisa_review`**, not CLI commands like `ralph-lisa review`
- **Include file paths and line numbers** in the content so Lisa can give precise feedback
- **Lisa remembers previous reviews** — if this is a follow-up, she'll reference earlier feedback
- If the MCP tool is not available, fall back to `ralph-lisa review --auto-approve` in the terminal
