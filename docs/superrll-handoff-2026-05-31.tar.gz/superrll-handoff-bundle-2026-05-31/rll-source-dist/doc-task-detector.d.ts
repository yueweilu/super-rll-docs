/**
 * §129 doc-task detector — Hybrid: --shape override > Ralph PLAN explicit > heuristic > default.
 */
export interface DetectInput {
    planBody: string;
    shape?: 'doc' | 'code' | 'mixed';
}
export interface DetectResult {
    is_doc_task: boolean;
    confidence: 'low' | 'medium' | 'high';
    signal: string;
}
export declare function detectDocTask(input: DetectInput): DetectResult;
