# Desktop Testing with Midscene

## Prerequisites

1. Install Midscene CLI: `npm install @midscene/cli --save-dev`
2. Configure a VLM provider (one of):
   - OpenAI: `export OPENAI_API_KEY="your-key"`
   - Qwen-VL: see https://midscenejs.com/model-common-config.html
   - Doubao Seed: see https://midscenejs.com/model-common-config.html

> Note: Anthropic Claude is NOT officially supported by Midscene.

## Usage

```bash
# Run desktop smoke test
npx midscene tests/desktop/smoke.yaml

# Add to .ralph-lisa.json for harness integration:
# {
#   "testHarness": {
#     "tests": {
#       "desktop-smoke": {
#         "adapter": "midscene",
#         "command": "npx midscene tests/desktop/smoke.yaml"
#       }
#     }
#   }
# }
```

## Test Types

- `computer: {}` — Native desktop automation (mouse + keyboard control)
- `web: { bridgeMode: newTabWithUrl }` — Desktop Chrome browser via extension

## Writing Tests

Tests use natural language descriptions:

```yaml
tasks:
  - name: Open settings
    flow:
      - aiAct: Click the Settings icon or menu
      - aiWaitFor: Settings panel is visible
      - aiAssert: Settings options are displayed
```

See: https://midscenejs.com/automate-with-scripts-in-yaml.html
