# Mobile Testing with Midscene

## Android Prerequisites

1. Install Midscene: `npm install @midscene/cli --save-dev`
2. Install adb (Android Debug Bridge)
3. Enable USB debugging on device
4. Connect device: `adb devices` should list your device
5. Configure a VLM provider (one of):
   - OpenAI: `export OPENAI_API_KEY="your-key"`
   - Qwen-VL: see https://midscenejs.com/model-common-config.html
   - Doubao Seed: see https://midscenejs.com/model-common-config.html
   > Note: Anthropic Claude is NOT officially supported by Midscene.

## iOS Prerequisites

1. Install Midscene: `npm install @midscene/cli @midscene/ios --save-dev`
2. Set up WebDriverAgent (version >= 7.0.0)
3. Verify WDA running: `curl http://localhost:8100/status`
4. Configure VLM provider

## Usage

```bash
# Android
npx midscene tests/mobile/smoke-android.yaml

# iOS
npx midscene tests/mobile/smoke-ios.yaml
```

## Harness Integration

```json
{
  "testHarness": {
    "tests": {
      "mobile-android": {
        "adapter": "midscene",
        "command": "npx midscene tests/mobile/smoke-android.yaml"
      },
      "mobile-ios": {
        "adapter": "midscene",
        "command": "npx midscene tests/mobile/smoke-ios.yaml"
      }
    }
  }
}
```

See: https://midscenejs.com/automate-with-scripts-in-yaml.html
