#!/usr/bin/env bash
# Replay a pane.cast (ANSI-preserving pane dump) into a wezterm pane.
#
# Usage: bash tests/wezctl/replay.sh <pane.cast>
#
# Opens a NEW wezterm pane and cats the cast into it, re-rendering the
# original colors/styles. Compared to opening the file in $EDITOR (which
# shows raw escape codes), this gives true visual reproduction.
#
# Requirements: wezterm CLI must be available; wezterm-gui should be running
# (script will start it if not).
set -u

CAST="${1:-}"
if [ -z "$CAST" ] || [ ! -f "$CAST" ]; then
  echo "usage: bash replay.sh <pane.cast>" >&2
  exit 1
fi

if ! command -v wezterm >/dev/null; then
  echo "[ERR] wezterm CLI not found" >&2
  exit 1
fi

# Ensure GUI is up so the spawned pane is visible.
if ! pgrep -x wezterm-gui >/dev/null 2>&1; then
  open -a WezTerm 2>/dev/null && sleep 2
fi

# Spawn a new pane and cat the cast into it. The pane stays open after the
# cat so you can inspect; close with `exit` or `kill`.
ABS_CAST="$(cd "$(dirname "$CAST")" && pwd)/$(basename "$CAST")"
wezterm cli spawn -- /bin/sh -c "cat '$ABS_CAST'; echo; echo '[replay done — press Enter to exit]'; read"
